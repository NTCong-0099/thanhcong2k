-- NUKEVIET 3.0
-- Module: Database
-- http://www.nukeviet.vn
--
-- Host: localhost
-- Generation Time: October 28, 2012, 11:59 AM GMT
-- Server version: 5.5.25
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET SESSION `character_set_client`='utf8';
SET SESSION `character_set_results`='utf8';
SET SESSION `character_set_connection`='utf8';
SET SESSION `collation_connection`='utf8_general_ci';
SET NAMES 'utf8';
ALTER DATABASE DEFAULT CHARACTER SET `utf8` COLLATE `utf8_general_ci`;

--
-- Database: `db_phapluat2`
--


-- ---------------------------------------


--
-- Table structure for table `nv3_authors`
--

DROP TABLE IF EXISTS `nv3_authors`;
CREATE TABLE `nv3_authors` (
  `admin_id` mediumint(8) unsigned NOT NULL,
  `editor` varchar(100) NOT NULL,
  `lev` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `susp_reason` mediumtext NOT NULL,
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_authors`
--

INSERT INTO `nv3_authors` VALUES
(1, 'ckeditor', 1, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', '643c9b49796370babc92db9f63b19ae9927f62d1', 1351419913, '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; rv:16.0) Gecko/20100101 Firefox/16.0');


-- ---------------------------------------


--
-- Table structure for table `nv3_authors_config`
--

DROP TABLE IF EXISTS `nv3_authors_config`;
CREATE TABLE `nv3_authors_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyname` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_banip`
--

DROP TABLE IF EXISTS `nv3_banip`;
CREATE TABLE `nv3_banip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_banners_click`
--

DROP TABLE IF EXISTS `nv3_banners_click`;
CREATE TABLE `nv3_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) unsigned NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15) NOT NULL,
  `click_country` varchar(10) NOT NULL,
  `click_browse_key` varchar(100) NOT NULL,
  `click_browse_name` varchar(100) NOT NULL,
  `click_os_key` varchar(100) NOT NULL,
  `click_os_name` varchar(100) NOT NULL,
  `click_ref` varchar(255) NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_banners_clients`
--

DROP TABLE IF EXISTS `nv3_banners_clients`;
CREATE TABLE `nv3_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(60) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  `uploadtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_banners_plans`
--

DROP TABLE IF EXISTS `nv3_banners_plans`;
CREATE TABLE `nv3_banners_plans` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `form` varchar(100) NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_banners_plans`
--

INSERT INTO `nv3_banners_plans` VALUES
(1, '', 'Quang cao giua trang', '', 'sequential', 510, 100, 1), 
(2, '', 'Quang cao trai', '', 'sequential', 190, 500, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_banners_rows`
--

DROP TABLE IF EXISTS `nv3_banners_rows`;
CREATE TABLE `nv3_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255) NOT NULL,
  `file_ext` varchar(100) NOT NULL,
  `file_mime` varchar(100) NOT NULL,
  `width` int(4) unsigned NOT NULL DEFAULT '0',
  `height` int(4) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255) NOT NULL,
  `click_url` varchar(255) NOT NULL,
  `file_name_tmp` varchar(255) NOT NULL,
  `file_alt_tmp` varchar(255) NOT NULL,
  `click_url_tmp` varchar(255) NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_banners_rows`
--

INSERT INTO `nv3_banners_rows` VALUES
(1, 'Bo ngoai giao', 2, 0, 'bongoaigiao.jpg', 'jpg', 'image/jpeg', 160, 54, '', 'http://www.mofa.gov.vn', '', '', '', 1351249594, 1351249594, 0, 0, 1, 1), 
(2, 'vinades', 2, 0, 'vinades.jpg', 'jpg', 'image/jpeg', 190, 454, '', 'http://vinades.vn', '', '', '', 1351249594, 1351249594, 0, 0, 1, 2), 
(3, 'Quang cao giua trang', 1, 0, 'webnhanh_vn.gif', 'gif', 'image/gif', 510, 65, '', 'http://webnhanh.vn', '', '', '', 1351249594, 1351249594, 0, 0, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_config`
--

DROP TABLE IF EXISTS `nv3_config`;
CREATE TABLE `nv3_config` (
  `lang` char(3) NOT NULL DEFAULT 'sys',
  `module` varchar(25) NOT NULL DEFAULT 'global',
  `config_name` varchar(30) NOT NULL DEFAULT '',
  `config_value` mediumtext NOT NULL,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_config`
--

INSERT INTO `nv3_config` VALUES
('sys', 'global', 'closed_site', '0'), 
('sys', 'global', 'site_keywords', 'NukeViet, portal, mysql, php'), 
('sys', 'global', 'site_phone', ''), 
('sys', 'global', 'site_lang', 'vi'), 
('sys', 'global', 'admin_theme', 'admin_full'), 
('sys', 'global', 'date_pattern', 'l, d-m-Y'), 
('sys', 'global', 'time_pattern', 'H&#x3A;i'), 
('sys', 'global', 'block_admin_ip', '0'), 
('sys', 'global', 'admfirewall', '0'), 
('sys', 'global', 'online_upd', '1'), 
('sys', 'global', 'statistic', '1'), 
('sys', 'global', 'dump_autobackup', '1'), 
('sys', 'global', 'dump_backup_ext', 'gz'), 
('sys', 'global', 'dump_backup_day', '30'), 
('sys', 'global', 'gfx_chk', '7'), 
('sys', 'global', 'file_allowed_ext', 'adobe,application,archives,audio,documents,flash,images,real,text,video,xml'), 
('sys', 'global', 'forbid_extensions', 'php,php3,php4,php5,phtml,inc'), 
('sys', 'global', 'forbid_mimes', ''), 
('sys', 'global', 'nv_max_size', '2097152'), 
('sys', 'global', 'upload_checking_mode', 'lite'), 
('sys', 'global', 'upload_logo', 'images/logo.png'), 
('sys', 'global', 'str_referer_blocker', '0'), 
('sys', 'global', 'getloadavg', '0'), 
('sys', 'global', 'mailer_mode', ''), 
('sys', 'global', 'smtp_host', 'smtp.gmail.com'), 
('sys', 'global', 'smtp_ssl', '1'), 
('sys', 'global', 'smtp_port', '465'), 
('sys', 'global', 'smtp_username', 'user@gmail.com'), 
('sys', 'global', 'smtp_password', 'userpass'), 
('sys', 'global', 'allowuserreg', '1'), 
('sys', 'global', 'allowuserlogin', '1'), 
('sys', 'global', 'allowloginchange', '0'), 
('sys', 'global', 'allowquestion', '1'), 
('sys', 'global', 'allowuserpublic', '0'), 
('sys', 'global', 'useactivate', '2'), 
('sys', 'global', 'allowmailchange', '1'), 
('sys', 'global', 'allow_sitelangs', 'vi'), 
('sys', 'global', 'allow_adminlangs', 'en,vi'), 
('sys', 'global', 'read_type', '0'), 
('sys', 'global', 'is_url_rewrite', '1'), 
('sys', 'global', 'rewrite_optional', '0'), 
('sys', 'global', 'rewrite_endurl', '/'), 
('sys', 'global', 'rewrite_exturl', '.html'), 
('sys', 'global', 'autocheckupdate', '1'), 
('sys', 'global', 'autologomod', ''), 
('sys', 'global', 'autologosize1', '50'), 
('sys', 'global', 'autologosize2', '40'), 
('sys', 'global', 'autologosize3', '30'), 
('sys', 'global', 'autoupdatetime', '24'), 
('sys', 'global', 'gzip_method', '1'), 
('sys', 'global', 'is_user_forum', '0'), 
('sys', 'global', 'openid_mode', '1'), 
('sys', 'global', 'authors_detail_main', '0'), 
('sys', 'global', 'spadmin_add_admin', '1'), 
('sys', 'global', 'openid_servers', 'yahoo,google,myopenid'), 
('sys', 'global', 'optActive', '0'), 
('sys', 'global', 'googleAnalyticsID', ''), 
('sys', 'global', 'googleAnalyticsSetDomainName', '0'), 
('sys', 'global', 'searchEngineUniqueID', ''), 
('sys', 'global', 'captcha_type', '0'), 
('sys', 'global', 'revision', '1758'), 
('sys', 'global', 'version', '3.4.01'), 
('vi', 'global', 'site_name', 'Pháp Luật'), 
('vi', 'global', 'site_logo', 'images/logo.png'), 
('vi', 'global', 'site_description', 'NukeViet CMS 3.x Developed by VINADES.,JSC'), 
('vi', 'global', 'site_keywords', ''), 
('vi', 'global', 'site_theme', 'phapluat2'), 
('vi', 'global', 'site_home_module', 'news'), 
('vi', 'global', 'switch_mobi_des', '1'), 
('vi', 'global', 'disable_site_content', 'Vì lý do kỹ thuật website tạm ngưng hoạt động. Thành thật xin lỗi các bạn vì sự bất tiện này!'), 
('vi', 'news', 'indexfile', 'viewcat_main_right'), 
('vi', 'news', 'per_page', '20'), 
('vi', 'news', 'st_links', '10'), 
('vi', 'news', 'auto_postcomm', '1'), 
('vi', 'news', 'homewidth', '100'), 
('vi', 'news', 'homeheight', '150'), 
('vi', 'news', 'blockwidth', '52'), 
('vi', 'news', 'blockheight', '75'), 
('vi', 'news', 'imagefull', '460'), 
('vi', 'news', 'setcomm', '2'), 
('vi', 'news', 'copyright', 'Chú ý: Việc đăng lại bài viết trên ở website hoặc các phương tiện truyền thông khác mà không ghi rõ nguồn http://nukeviet.vn là vi phạm bản quyền'), 
('vi', 'news', 'showhometext', '1'), 
('vi', 'news', 'activecomm', '1'), 
('vi', 'news', 'emailcomm', '1'), 
('vi', 'news', 'timecheckstatus', '0'), 
('vi', 'news', 'config_source', '0'), 
('sys', 'global', 'site_email', 'tvthanh88hp@gmail.com'), 
('sys', 'global', 'error_send_email', 'tvthanh88hp@gmail.com'), 
('sys', 'global', 'my_domains', 'localhost'), 
('sys', 'global', 'cookie_prefix', 'nv3c_Bxxcg'), 
('sys', 'global', 'session_prefix', 'nv3s_Ef1qcy'), 
('sys', 'global', 'site_timezone', 'byCountry'), 
('sys', 'global', 'statistics_timezone', 'Asia/Bangkok'), 
('sys', 'global', 'proxy_blocker', '0'), 
('sys', 'global', 'lang_multi', '1'), 
('sys', 'global', 'lang_geo', '0'), 
('sys', 'global', 'ftp_server', 'localhost'), 
('sys', 'global', 'ftp_port', '21'), 
('sys', 'global', 'ftp_user_name', ''), 
('sys', 'global', 'ftp_user_pass', ''), 
('sys', 'global', 'ftp_path', '/'), 
('sys', 'global', 'ftp_check_login', '0'), 
('vi', 'thu-vien-van-ban', 'homewidth', '100'), 
('vi', 'thu-vien-van-ban', 'auto_postcomm', '1'), 
('vi', 'thu-vien-van-ban', 'st_links', '10'), 
('vi', 'thu-vien-van-ban', 'indexfile', 'viewcat_main_right'), 
('vi', 'thu-vien-van-ban', 'per_page', '20'), 
('vi', 'thu-vien-van-ban', 'homeheight', '150'), 
('vi', 'thu-vien-van-ban', 'blockwidth', '52'), 
('vi', 'thu-vien-van-ban', 'blockheight', '75'), 
('vi', 'thu-vien-van-ban', 'imagefull', '460'), 
('vi', 'thu-vien-van-ban', 'setcomm', '2'), 
('vi', 'thu-vien-van-ban', 'copyright', ''), 
('vi', 'thu-vien-van-ban', 'showhometext', '1'), 
('vi', 'thu-vien-van-ban', 'activecomm', '1'), 
('vi', 'thu-vien-van-ban', 'emailcomm', '1'), 
('vi', 'thu-vien-van-ban', 'timecheckstatus', '0'), 
('vi', 'thu-vien-van-ban', 'config_source', '0');


-- ---------------------------------------


--
-- Table structure for table `nv3_cronjobs`
--

DROP TABLE IF EXISTS `nv3_cronjobs`;
CREATE TABLE `nv3_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `interval` int(11) unsigned NOT NULL DEFAULT '0',
  `run_file` varchar(255) NOT NULL,
  `run_func` varchar(255) NOT NULL,
  `params` varchar(255) NOT NULL,
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vi_cron_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_cronjobs`
--

INSERT INTO `nv3_cronjobs` VALUES
(1, 1351249594, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1351425561, 1, 'Xóa các dòng ghi trạng thái online đã cũ trong CSDL'), 
(2, 1351249594, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1351336027, 1, 'Tự động lưu CSDL'), 
(3, 1351249594, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1351419162, 1, 'Xóa các file tạm trong thư mục tmp'), 
(4, 1351249594, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1351420890, 1, 'Xóa IP log files Xóa các file logo truy cập'), 
(5, 1351249594, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1351336027, 1, 'Xóa các file error_log quá hạn'), 
(6, 1351249594, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Gửi email các thông báo lỗi cho admin'), 
(7, 1351249594, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1351419162, 1, 'Xóa các referer quá hạn'), 
(8, 1351249594, 1440, 'siteDiagnostic_update.php', 'cron_siteDiagnostic_update', '', 0, 1, 1, 1351336027, 1, 'Cập nhật đánh giá site từ các máy chủ tìm kiếm'), 
(9, 1351249594, 60, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 1351419162, 1, 'Kiểm tra phiên bản NukeViet');


-- ---------------------------------------


--
-- Table structure for table `nv3_groups`
--

DROP TABLE IF EXISTS `nv3_groups`;
CREATE TABLE `nv3_groups` (
  `group_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `users` mediumtext NOT NULL,
  `public` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `title` (`title`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_ipcountry`
--

DROP TABLE IF EXISTS `nv3_ipcountry`;
CREATE TABLE `nv3_ipcountry` (
  `ip_from` int(11) unsigned NOT NULL,
  `ip_to` int(11) unsigned NOT NULL,
  `country` char(2) NOT NULL,
  `ip_file` smallint(5) unsigned NOT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `ip_from` (`ip_from`,`ip_to`),
  KEY `ip_file` (`ip_file`),
  KEY `country` (`country`),
  KEY `time` (`time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_ipcountry`
--

INSERT INTO `nv3_ipcountry` VALUES
(2130706432, 2130771967, 'ZZ', 127, 1351249640);


-- ---------------------------------------


--
-- Table structure for table `nv3_language`
--

DROP TABLE IF EXISTS `nv3_language`;
CREATE TABLE `nv3_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lang_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_language_file`
--

DROP TABLE IF EXISTS `nv3_language_file`;
CREATE TABLE `nv3_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `admin_file` varchar(255) NOT NULL DEFAULT '0',
  `langtype` varchar(50) NOT NULL,
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_logs`
--

DROP TABLE IF EXISTS `nv3_logs`;
CREATE TABLE `nv3_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10) NOT NULL,
  `module_name` varchar(150) NOT NULL,
  `name_key` varchar(255) NOT NULL,
  `note_action` text NOT NULL,
  `link_acess` varchar(255) NOT NULL,
  `userid` int(11) NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=180  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_logs`
--

INSERT INTO `nv3_logs` VALUES
(1, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351249645), 
(2, 'vi', 'themes', 'Thiết lập layout theme: \"phapluat2\"', '', '', 1, 1351249716), 
(3, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351249727), 
(4, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351263515), 
(5, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351263557), 
(6, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351263626), 
(7, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351263627), 
(8, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351263662), 
(9, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351264083), 
(10, 'vi', 'themes', 'Thêm block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1351264321), 
(11, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1351264340), 
(12, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351264350), 
(13, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1351264417), 
(14, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351264434), 
(15, 'vi', 'themes', 'Sửa block', 'Name : Menu', 'Name : Menu', 1, 1351264498), 
(16, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351264758), 
(17, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351264868), 
(18, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351265067), 
(19, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351265389), 
(20, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351267347), 
(21, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351267377), 
(22, 'vi', 'themes', 'Thêm block', 'Name : module block headline', 'Name : module block headline', 1, 1351267429), 
(23, 'vi', 'themes', 'Sửa block', 'Name : module block headline', 'Name : module block headline', 1, 1351267659), 
(24, 'vi', 'themes', 'Thêm block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1351270349), 
(25, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1351270362), 
(26, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351304992), 
(27, 'vi', 'themes', 'Sửa block', 'Name : Menu', 'Name : Menu', 1, 1351305051), 
(28, 'vi', 'themes', 'Thêm block', 'Name : global block category', 'Name : global block category', 1, 1351305191), 
(29, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351306295), 
(30, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351306548), 
(31, 'vi', 'themes', 'Thêm block', 'Name : global block topnews', 'Name : global block topnews', 1, 1351307263), 
(32, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351307891), 
(33, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351307979), 
(34, 'vi', 'themes', 'Thêm block', 'Name : global voting', 'Name : global voting', 1, 1351308143), 
(35, 'vi', 'themes', 'Thêm block', 'Name : global counter', 'Name : global counter', 1, 1351309000), 
(36, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351311914), 
(37, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351311931), 
(38, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351331211), 
(39, 'vi', 'modules', 'Thiết lập module mới shops\"', '', '', 1, 1351331256), 
(40, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1351331358), 
(41, 'vi', 'modules', 'Thứ tự module \"shops\"', '11 -> 3', '11 -> 3', 1, 1351331444), 
(42, 'vi', 'shops', 'log_add_catalog', 'id 1', 'id 1', 1, 1351331584), 
(43, 'vi', 'shops', 'log_add_catalog', 'id 2', 'id 2', 1, 1351331603), 
(44, 'vi', 'shops', 'log_add_catalog', 'id 3', 'id 3', 1, 1351331622), 
(45, 'vi', 'themes', 'Thêm block', 'Name : global block blocknews', 'Name : global block blocknews', 1, 1351333449), 
(46, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351333469), 
(47, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351333760), 
(48, 'vi', 'news', 'Thêm chuyên mục', 'Sản phẩm A', 'Sản phẩm A', 1, 1351336138), 
(49, 'vi', 'news', 'Thêm chuyên mục', 'Sản phẩm B', 'Sản phẩm B', 1, 1351336148), 
(50, 'vi', 'news', 'Thêm chuyên mục', 'Sản phẩm C', 'Sản phẩm C', 1, 1351336157), 
(51, 'vi', 'news', 'Thêm chuyên mục', 'Đối tác  A', 'Đối tác  A', 1, 1351344537), 
(52, 'vi', 'news', 'Thêm chuyên mục', 'Đối tác  B', 'Đối tác  B', 1, 1351344546), 
(53, 'vi', 'news', 'Thêm chuyên mục', 'Tuyển dụng  A', 'Tuyển dụng  A', 1, 1351344582), 
(54, 'vi', 'news', 'Thêm chuyên mục', 'Tuyển dụng  B', 'Tuyển dụng  B', 1, 1351344592), 
(55, 'vi', 'news', 'Thêm chuyên mục', 'Tuyển dụng  C', 'Tuyển dụng  C', 1, 1351344629), 
(56, 'vi', 'news', 'Thêm chuyên mục', 'Tuyển dụng  D', 'Tuyển dụng  D', 1, 1351344639), 
(57, 'vi', 'news', 'Thêm chuyên mục', 'Tuyển dụng  E', 'Tuyển dụng  E', 1, 1351344652), 
(58, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351344867), 
(59, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351344887), 
(60, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351394143), 
(61, 'vi', 'modules', 'Sửa module &ldquo;news&rdquo;', '', '', 1, 1351394927), 
(62, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1351394967), 
(63, 'vi', 'modules', 'Thứ tự module \"about\"', '11 -> 3', '11 -> 3', 1, 1351396596), 
(64, 'vi', 'modules', 'Thứ tự module \"about\"', '11 -> 1', '11 -> 1', 1, 1351396627), 
(65, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351399862), 
(66, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351399916), 
(67, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351400601), 
(68, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351400762), 
(69, 'vi', 'shops', 'log_edit_catalog', 'id 1', 'id 1', 1, 1351404894), 
(70, 'vi', 'shops', 'log_edit_catalog', 'id 2', 'id 2', 1, 1351405016), 
(71, 'vi', 'shops', 'log_edit_catalog', 'id 3', 'id 3', 1, 1351405052), 
(72, 'vi', 'shops', 'log_add_catalog', 'id 4', 'id 4', 1, 1351405323), 
(73, 'vi', 'shops', 'log_add_catalog', 'id 5', 'id 5', 1, 1351405353), 
(74, 'vi', 'shops', 'log_add_catalog', 'id 6', 'id 6', 1, 1351405369), 
(75, 'vi', 'shops', 'log_edit_catalog', 'id 3', 'id 3', 1, 1351405415), 
(76, 'vi', 'shops', 'log_edit_catalog', 'id 2', 'id 2', 1, 1351405429), 
(77, 'vi', 'shops', 'log_edit_catalog', 'id 6', 'id 6', 1, 1351405450), 
(78, 'vi', 'shops', 'log_add_catalog', 'id 7', 'id 7', 1, 1351405478), 
(79, 'vi', 'shops', 'log_add_catalog', 'id 8', 'id 8', 1, 1351405488), 
(80, 'vi', 'themes', 'Sửa block', 'Name : Lĩnh vực hoạt động', 'Name : Lĩnh vực hoạt động', 1, 1351405610), 
(81, 'vi', 'themes', 'Sửa block', 'Name : Thành viên', 'Name : Thành viên', 1, 1351405636), 
(82, 'vi', 'themes', 'Sửa block', 'Name : Thống kê', 'Name : Thống kê', 1, 1351405659), 
(83, 'vi', 'themes', 'Sửa block', 'Name : Thăm dò ý kiến', 'Name : Thăm dò ý kiến', 1, 1351405685), 
(84, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Sản phẩm C', 'Sản phẩm C', 1, 1351405946), 
(85, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Sản phẩm B', 'Sản phẩm B', 1, 1351405950), 
(86, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Sản phẩm A', 'Sản phẩm A', 1, 1351405954), 
(87, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Sản phẩm', 'Sản phẩm', 1, 1351405980), 
(88, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng  E', 'Tuyển dụng  E', 1, 1351405999), 
(89, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng  D', 'Tuyển dụng  D', 1, 1351406004), 
(90, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng  C', 'Tuyển dụng  C', 1, 1351406011), 
(91, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng  B', 'Tuyển dụng  B', 1, 1351406015), 
(92, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng  A', 'Tuyển dụng  A', 1, 1351406020), 
(93, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng', 'Tuyển dụng', 1, 1351406028), 
(94, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Đối tác  B', 'Đối tác  B', 1, 1351406044), 
(95, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Đối tác  A', 'Đối tác  A', 1, 1351406051), 
(96, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Đối tác', 'Đối tác', 1, 1351406063), 
(97, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tin công nghệ', 'Tin công nghệ', 1, 1351406071), 
(98, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Bản tin nội bộ', 'Bản tin nội bộ', 1, 1351406078), 
(99, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Thông cáo báo chí', 'Thông cáo báo chí', 1, 1351406083), 
(100, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tin tức', 'Tin tức', 1, 1351406102), 
(101, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ doanh nghiệp', 'Dịch vụ doanh nghiệp', 1, 1351406129), 
(102, 'vi', 'news', 'Thêm chuyên mục', 'Sở hữu trí tuệ', 'Sở hữu trí tuệ', 1, 1351406149), 
(103, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ tư vấn', 'Dịch vụ tư vấn', 1, 1351406165), 
(104, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ tài chính', 'Dịch vụ tài chính', 1, 1351406210), 
(105, 'vi', 'news', 'Thêm chuyên mục', 'Thông tin pháp luật', 'Thông tin pháp luật', 1, 1351406248), 
(106, 'vi', 'news', 'Thêm chuyên mục', 'Hỏi đáp pháp luật', 'Hỏi đáp pháp luật', 1, 1351406266), 
(107, 'vi', 'news', 'Thêm chuyên mục', 'Kiến thức', 'Kiến thức', 1, 1351406336), 
(108, 'vi', 'news', 'Thêm chuyên mục', 'Thư giãn', 'Thư giãn', 1, 1351406347), 
(109, 'vi', 'news', 'Thêm chuyên mục', 'Đăng ký kinh doanh', 'Đăng ký kinh doanh', 1, 1351406440), 
(110, 'vi', 'news', 'Thêm chuyên mục', 'Đăng ký đầu tư', 'Đăng ký đầu tư', 1, 1351406475), 
(111, 'vi', 'news', 'Thêm chuyên mục', 'Tổ chức doanh nghệp', 'Tổ chức doanh nghệp', 1, 1351406499), 
(112, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ đăng ký bảo hộ', 'Dịch vụ đăng ký bảo hộ', 1, 1351406544), 
(113, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ xử lý vi phạm SHTT', 'Dịch vụ xử lý vi phạm SHTT', 1, 1351406576), 
(114, 'vi', 'news', 'Thêm chuyên mục', 'Li xăng và nhượng quyền', 'Li xăng và nhượng quyền', 1, 1351406623), 
(115, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ luật sư', 'Dịch vụ luật sư', 1, 1351406748), 
(116, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ xin giấy phép', 'Dịch vụ xin giấy phép', 1, 1351406773), 
(117, 'vi', 'news', 'Thêm chuyên mục', 'Hướng dẫn thủ tục', 'Hướng dẫn thủ tục', 1, 1351406792), 
(118, 'vi', 'news', 'Thêm chuyên mục', 'Văn bản mới', 'Văn bản mới', 1, 1351406827), 
(119, 'vi', 'news', 'Thêm chuyên mục', 'Tin tức pháp luật', 'Tin tức pháp luật', 1, 1351406848), 
(120, 'vi', 'modules', 'Thêm module ảo \"shop\"', '', '', 1, 1351406929), 
(121, 'vi', 'modules', 'Thiết lập module mới shop\"', '', '', 1, 1351406940), 
(122, 'vi', 'modules', 'Sửa module &ldquo;shop&rdquo;', '', '', 1, 1351406956), 
(123, 'vi', 'modules', 'Xóa module \"shop\"', '', '', 1, 1351406981), 
(124, 'vi', 'users', 'log_add_user', 'userid 2', 'userid 2', 1, 1351407241), 
(125, 'vi', 'shops', 'log_del_catalog', 'id 1', 'id 1', 1, 1351407467), 
(126, 'vi', 'shops', 'log_del_catalog', 'id 8', 'id 8', 1, 1351407471), 
(127, 'vi', 'shops', 'log_del_catalog', 'id 7', 'id 7', 1, 1351407474), 
(128, 'vi', 'shops', 'log_del_catalog', 'id 6', 'id 6', 1, 1351407476), 
(129, 'vi', 'shops', 'log_del_catalog', 'id 5', 'id 5', 1, 1351407477), 
(130, 'vi', 'shops', 'log_del_catalog', 'id 4', 'id 4', 1, 1351407478), 
(131, 'vi', 'shops', 'log_del_catalog', 'id 3', 'id 3', 1, 1351407479), 
(132, 'vi', 'shops', 'log_del_catalog', 'id 2', 'id 2', 1, 1351407479), 
(133, 'vi', 'modules', 'Xóa module \"shops\"', '', '', 1, 1351407508), 
(134, 'vi', 'modules', 'Thêm module ảo \"thu_vien_van_ban\"', '', '', 1, 1351407578), 
(135, 'vi', 'modules', 'Thiết lập module mới thu-vien-van-ban\"', '', '', 1, 1351407590), 
(136, 'vi', 'modules', 'Sửa module &ldquo;thu-vien-van-ban&rdquo;', '', '', 1, 1351407614), 
(137, 'vi', 'modules', 'Thứ tự module \"thu-vien-van-ban\"', '11 -> 3', '11 -> 3', 1, 1351407641), 
(138, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật kinh doanh', 'Pháp luật kinh doanh', 1, 1351407732), 
(139, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật Sở hữu trí tuệ', 'Pháp luật Sở hữu trí tuệ', 1, 1351407751), 
(140, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật dân sự', 'Pháp luật dân sự', 1, 1351407774), 
(141, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật đất đai', 'Pháp luật đất đai', 1, 1351407797), 
(142, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật Hình sự', 'Pháp luật Hình sự', 1, 1351407847), 
(143, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật Hành chính', 'Pháp luật Hành chính', 1, 1351407858), 
(144, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật Lao động', 'Pháp luật Lao động', 1, 1351407870), 
(145, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Điều ước Quốc tế', 'Điều ước Quốc tế', 1, 1351407879), 
(146, 'vi', 'themes', 'Sửa block', 'Name : Lĩnh vực hoạt động', 'Name : Lĩnh vực hoạt động', 1, 1351407947), 
(147, 'vi', 'themes', 'Thêm block', 'Name : global block category', 'Name : global block category', 1, 1351407977), 
(148, 'vi', 'themes', 'Sửa block', 'Name : Thư viện văn bản', 'Name : Thư viện văn bản', 1, 1351408049), 
(149, 'vi', 'themes', 'Sửa block', 'Name : Lĩnh vực hoạt động', 'Name : Lĩnh vực hoạt động', 1, 1351408093), 
(150, 'vi', 'news', 'Thêm bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351408478), 
(151, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351408529), 
(152, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351408662), 
(153, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351408768), 
(154, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/logo1.jpg', 'uploads/news/2012_10/logo1.jpg', 1, 1351416669), 
(155, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/dkkd.jpeg', 'uploads/news/2012_10/dkkd.jpeg', 1, 1351417471), 
(156, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351417512), 
(157, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351419218), 
(158, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351419254), 
(159, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351419579), 
(160, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351419612), 
(161, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351419775), 
(162, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351419913), 
(163, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/thanhlapdoanhnghiep.jpeg', 'uploads/news/2012_10/thanhlapdoanhnghiep.jpeg', 1, 1351421000), 
(164, 'vi', 'news', 'Thêm bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 1, 1351421031), 
(165, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 1, 1351421089), 
(166, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/doanh-nghiep.jpeg', 'uploads/news/2012_10/doanh-nghiep.jpeg', 1, 1351421217), 
(167, 'vi', 'news', 'Thêm bài viết', 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 1, 1351421252), 
(168, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 1, 1351421316), 
(169, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351421331), 
(170, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/dau-tu.jpg', 'uploads/news/2012_10/dau-tu.jpg', 1, 1351421481), 
(171, 'vi', 'news', 'Thêm bài viết', 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 1, 1351421497), 
(172, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351421538), 
(173, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 1, 1351421553), 
(174, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 1, 1351421611), 
(175, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 1, 1351421640), 
(176, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/vanphongdaidien.jpg', 'uploads/news/2012_10/vanphongdaidien.jpg', 1, 1351421726), 
(177, 'vi', 'news', 'Thêm bài viết', 'Thành lập văn phòng đại diên của doanh nghiệp nước ngoài&#33;&#33;&#33;', 'Thành lập văn phòng đại diên của doanh nghiệp nước ngoài&#33;&#33;&#33;', 1, 1351421742), 
(178, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/dau-tu.jpeg', 'uploads/news/2012_10/dau-tu.jpeg', 1, 1351421845), 
(179, 'vi', 'news', 'Thêm bài viết', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 1, 1351421861);


-- ---------------------------------------


--
-- Table structure for table `nv3_sessions`
--

DROP TABLE IF EXISTS `nv3_sessions`;
CREATE TABLE `nv3_sessions` (
  `session_id` varchar(50) DEFAULT NULL,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(100) NOT NULL,
  `onl_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_setup`
--

DROP TABLE IF EXISTS `nv3_setup`;
CREATE TABLE `nv3_setup` (
  `lang` char(2) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tables` varchar(255) NOT NULL,
  `version` varchar(100) NOT NULL,
  `setup_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_setup_language`
--

DROP TABLE IF EXISTS `nv3_setup_language`;
CREATE TABLE `nv3_setup_language` (
  `lang` char(2) NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_setup_language`
--

INSERT INTO `nv3_setup_language` VALUES
('vi', 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_setup_modules`
--

DROP TABLE IF EXISTS `nv3_setup_modules`;
CREATE TABLE `nv3_setup_modules` (
  `title` varchar(55) NOT NULL,
  `is_sysmod` tinyint(1) NOT NULL DEFAULT '0',
  `virtual` tinyint(1) NOT NULL DEFAULT '0',
  `module_file` varchar(50) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `mod_version` varchar(50) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_setup_modules`
--

INSERT INTO `nv3_setup_modules` VALUES
('about', 0, 1, 'about', 'about', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('banners', 1, 0, 'banners', 'banners', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('contact', 0, 1, 'contact', 'contact', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('news', 0, 1, 'news', 'news', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('voting', 0, 0, 'voting', 'voting', '3.1.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('forum', 0, 0, 'forum', 'forum', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('search', 1, 0, 'search', 'search', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('users', 1, 0, 'users', 'users', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('download', 0, 1, 'download', 'download', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('weblinks', 0, 1, 'weblinks', 'weblinks', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('statistics', 0, 0, 'statistics', 'statistics', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('faq', 0, 1, 'faq', 'faq', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('menu', 0, 1, 'menu', 'menu', '3.1.00 1273225635', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('rss', 1, 0, 'rss', 'rss', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('shops', 0, 1, 'shops', 'shops', '3.3.00 1273830435', 1351331249, 'VINADES (contact@vinades.vn)', ''), 
('thu-vien-van-ban', 0, 0, 'news', 'thu_vien_van_ban', '', 1351407578, '', '');


-- ---------------------------------------


--
-- Table structure for table `nv3_users`
--

DROP TABLE IF EXISTS `nv3_users`;
CREATE TABLE `nv3_users` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `gender` char(1) NOT NULL,
  `photo` varchar(255) NOT NULL DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `website` varchar(255) NOT NULL DEFAULT '',
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL DEFAULT '',
  `telephone` varchar(100) NOT NULL DEFAULT '',
  `fax` varchar(100) NOT NULL DEFAULT '',
  `mobile` varchar(100) NOT NULL DEFAULT '',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `passlostkey` varchar(40) NOT NULL DEFAULT '',
  `view_mail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255) NOT NULL DEFAULT '',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` varchar(40) NOT NULL DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) NOT NULL DEFAULT '',
  `last_agent` varchar(255) NOT NULL DEFAULT '',
  `last_openid` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_users`
--

INSERT INTO `nv3_users` VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '4a467cdf5df6317340f339d54321b0b3d926cd73', 'tvthanh88hp@gmail.com', 'admin', '', '', 0, NULL, 1351249634, '', '', '', '', '', '', 'abc', 'abc', '', 0, 1, '', 1, '', 1351249634, '', '', ''), 
(2, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', '4a467cdf5df6317340f339d54321b0b3d926cd73', 'trinhthanh9688@gmail.com', '', '', '', 0, '', 1351407241, '', '', '', '', '', '', 'abc', 'abc', '', 0, 1, '', 1, '', 0, '', '', '');


-- ---------------------------------------


--
-- Table structure for table `nv3_users_config`
--

DROP TABLE IF EXISTS `nv3_users_config`;
CREATE TABLE `nv3_users_config` (
  `config` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_users_config`
--

INSERT INTO `nv3_users_config` VALUES
('registertype', '1', 1351249594), 
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1351249594), 
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1351249594), 
('siteterms_vi', '<p> Để trở thành thành viên, bạn phải cam kết đồng ý với các điều khoản dưới đây. Chúng tôi có thể thay đổi lại những điều khoản này vào bất cứ lúc nào và chúng tôi sẽ cố gắng thông báo đến bạn kịp thời.<br  /> <br  /> Bạn cam kết không gửi bất cứ bài viết có nội dung lừa đảo, thô tục, thiếu văn hoá; vu khống, khiêu khích, đe doạ người khác; liên quan đến các vấn đề tình dục hay bất cứ nội dung nào vi phạm luật pháp của quốc gia mà bạn đang sống, luật pháp của quốc gia nơi đặt máy chủ của website này hay luật pháp quốc tế. Nếu vẫn cố tình vi phạm, ngay lập tức bạn sẽ bị cấm tham gia vào website. Địa chỉ IP của tất cả các bài viết đều được ghi nhận lại để bảo vệ các điều khoản cam kết này trong trường hợp bạn không tuân thủ.<br  /> <br  /> Bạn đồng ý rằng website có quyền gỡ bỏ, sửa, di chuyển hoặc khoá bất kỳ bài viết nào trong website vào bất cứ lúc nào tuỳ theo nhu cầu công việc.<br  /> <br  /> Đăng ký làm thành viên của chúng tôi, bạn cũng phải đồng ý rằng, bất kỳ thông tin cá nhân nào mà bạn cung cấp đều được lưu trữ trong cơ sở dữ liệu của hệ thống. Mặc dù những thông tin này sẽ không được cung cấp cho bất kỳ người thứ ba nào khác mà không được sự đồng ý của bạn, chúng tôi không chịu trách nhiệm về việc những thông tin cá nhân này của bạn bị lộ ra bên ngoài từ những kẻ phá hoại có ý đồ xấu tấn công vào cơ sở dữ liệu của hệ thống.</p>', 1274757129);


-- ---------------------------------------


--
-- Table structure for table `nv3_users_openid`
--

DROP TABLE IF EXISTS `nv3_users_openid`;
CREATE TABLE `nv3_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `opid` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_users_question`
--

DROP TABLE IF EXISTS `nv3_users_question`;
CREATE TABLE `nv3_users_question` (
  `qid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `lang` char(2) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_users_question`
--

INSERT INTO `nv3_users_question` VALUES
(1, 'Bạn thích môn thể thao nào nhất', 'vi', 1, 1274840238, 1274840238), 
(2, 'Món ăn mà bạn yêu thích', 'vi', 2, 1274840250, 1274840250), 
(3, 'Thần tượng điện ảnh của bạn', 'vi', 3, 1274840257, 1274840257), 
(4, 'Bạn thích nhạc sỹ nào nhất', 'vi', 4, 1274840264, 1274840264), 
(5, 'Quê ngoại của bạn ở đâu', 'vi', 5, 1274840270, 1274840270), 
(6, 'Tên cuốn sách &quot;gối đầu giường&quot;', 'vi', 6, 1274840278, 1274840278), 
(7, 'Ngày lễ mà bạn luôn mong đợi', 'vi', 7, 1274840285, 1274840285);


-- ---------------------------------------


--
-- Table structure for table `nv3_users_reg`
--

DROP TABLE IF EXISTS `nv3_users_reg`;
CREATE TABLE `nv3_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `regdate` int(11) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `checknum` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_about`
--

DROP TABLE IF EXISTS `nv3_vi_about`;
CREATE TABLE `nv3_vi_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `bodytext` mediumtext NOT NULL,
  `keywords` mediumtext NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_about`
--

INSERT INTO `nv3_vi_about` VALUES
(1, 'Giới thiệu về NukeViet 3.0', 'Gioi-thieu-ve-NukeViet-3-0', '<p> NukeViet 3.0 là thế hệ CMS hoàn toàn mới do người Việt phát triển. Lần đầu tiên ở Việt Nam, một bộ nhân mã nguồn mở được đầu tư bài bản và chuyên nghiệp cả về tài chính, nhân lực và thời gian. Kết quả là 100% dòng code của NukeViet được viết mới hoàn toàn, NukeViet 3 sử dụng xHTML, CSS với Xtemplate và jquery cho phép vận dụng Ajax uyển chuyển cả trong công nghệ nhân.</p><p> Tận dụng các thành tựu mã nguồn mở có sẵn nhưng NukeViet 3 vẫn đảm bảo rằng từng dòng code là được code tay (NukeViet 3 không sử dụng bất cứ một nền tảng (framework) nào). Điều này có nghĩa là NukeViet 3 hoàn toàn không phụ thuộc vào bất cứ framework nào trong quá trình phát triển của mình; Bạn hoàn toàn có thể đọc hiểu để tự lập trình trên NukeViet 3 nếu bạn biết PHP và MySQL (đồng nghĩa với việc NukeViet 3 hoàn toàn mở và dễ nghiên cứu cho bất cứ ai muốn tìm hiểu về code của NukeViet).</p><p style=\"text-align: justify;\"> Bộ nhân NukeViet 3 ngoài việc thừa hưởng sự đơn giản vốn có của NukeViet nhưng không vì thế mà quên nâng cấp mình. Hệ thống NukeViet 3 hỗ trợ công nghệ đa nhân module. Chúng tôi gọi đó là công nghệ ảo hóa module. Công nghệ này cho phép người sử dụng có thể khởi tạo hàng ngàn module một cách tự động mà không cần động đến một dòng code. Các module được sinh ra từ công nghệ này gọi là module ảo. Module ảo là module được nhân bản từ một module bất kỳ của hệ thống nukeviet nếu module đó cho phép tạo module ảo.</p><p style=\"text-align: justify;\"> NukeViet 3 cũng hỗ trợ việc cài đặt từ động 100% các module, block, theme từ Admin Control Panel, người sử dụng có thể cài module mà không cần làm bất cứ thao tác phức tạp nào. NukeViet 3 còn cho phép bạn đóng gói module để chia sẻ cho người khác.</p><p style=\"text-align: justify;\"> NukeViet 3 đa ngôn ngữ 100% với 2 loại: đa ngôn ngữ giao diện và đa ngôn ngữ database. NukeViet 3 có tính năng&nbsp; cho phép người quản trị tự xây dựng ngôn ngữ mới cho site. Cho&nbsp; phép đóng gói file ngôn ngữ để chia sẻ cho cộng đồng... câu chuyện về nukeviet 3 sẽ còn dài vì một loạt các tính năng cao cấp vẫn đang được phát triển. Hãy sử dụng và phổ biến NukeViet 3 để tự mình tận hưởng những thành quả mới nhất từ công nghệ web mã nguồn mở. Cuối cùng NukeViet 3 là món của của <a href=\"http://vinades.vn\" target=\"_blank\">VINADES.,JSC</a> gửi tới cộng đồng để cảm ơn cộng đồng đã ủng hộ thời gian qua, bây giờ NukeViet 3 được đưa trở lại cộng đồng để cộng đồng tiếp tục nuôi nấng và chăm sóc NukeViet lớn mạnh hơn.</p><p style=\"text-align: justify;\"> Mọi ý kiến và yêu cầu trợ giúp về NukeViet 3 các bạn có thể gửi lên diễn đàn NukeViet tại địa chỉ: <a href=\"http://nukeviet.vn/phpbb/\" target=\"_blank\">http://nukeviet.vn/phpbb/</a>. Việc giúp đỡ hoàn toàn miễn phí và mọi góp ý của bạn đều được hoan nghênh.</p> <div style=\"text-align: center;\"> <object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" height=\"400\" width=\"480\"><param name=\"quality\" value=\"high\" /><param name=\"allowScriptAccess\" value=\"always\" /><param name=\"movie\" value=\"/phapluat2/images/jwplayer/player.swf\" /><param name=\"allowfullscreen\" value=\"true\" /><param name=\"allowscriptaccess\" value=\"always\" /><param name=\"flashvars\" value=\"file=http://www.youtube.com/watch?v=dG66RocXSeY&amp;autostart=true\" /><embed allowscriptaccess=\"always\" flashvars=\"file=http://www.youtube.com/watch?v=dG66RocXSeY&amp;autostart=true\" height=\"400\" quality=\"high\" src=\"/phapluat2/images/jwplayer/player.swf\" width=\"480\"></embed></object><br  /> Video clip Giới thiệu mã nguồn mở NukeViet trong bản tin Tiêu điểm của chương trình Xã hội thông tin<br  /> (Đài truyền hình kỹ thuật số VTC) phát sóng lúc 20h chủ nhật, ngày 05-09-2010 trên VTC1</div>', 'thế hệ,hoàn toàn,phát triển,tài chính,nhân lực,thời gian,kết quả,sử dụng,cho phép,uyển chuyển,công nghệ,tận dụng,thành tựu,đảm bảo,nền tảng,có nghĩa,phụ thuộc,quá trình,có thể,tự lập,đồng nghĩa', 1, 1, 1275320174, 1275320174, 1), 
(2, 'Giới thiệu về công ty chuyên quản NukeViet', 'Gioi-thieu-ve-cong-ty-chuyen-quan-NukeViet', '<p style=\"text-align: justify;\"> <strong>Công ty cổ phần phát triển nguồn mở Việt Nam</strong> (VINADES.,JSC) là công ty mã nguồn mở đầu tiên của Việt Nam sở hữu riêng một mã nguồn mở nổi tiếng và đang được sử dụng ở hàng ngàn website lớn nhỏ trong mọi lĩnh vực.<br  /> <br  /> Ra đời từ hoạt động của tổ chức nguồn mở NukeViet (từ năm 2004) và chính thức được thành lập đầu 2010 tại Hà Nội, khi đó báo chí đã gọi VINADES.,JSC là &quot;Công ty mã nguồn mở đầu tiên tại Việt Nam&quot;.<br  /> <br  /> Ngay sau khi thành lập, VINADES.,JSC đã thành công trong việc xây dựng <strong><a href=\"http://nukeviet.vn/\" target=\"_blank\">NukeViet</a></strong> thành một <a href=\"http://nukeviet.vn/\" target=\"_blank\">mã nguồn mở</a> thuần Việt. Với khả năng mạnh mẽ, cùng các ưu điểm vượt trội về công nghệ, độ an toàn và bảo mật, NukeViet đã được hàng ngàn website lựa chọn sử dụng trong năm qua. Ngay khi ra mắt phiên bản mới năm 2010, NukeViet đã tạo nên hiệu ứng truyền thông chưa từng có trong lịch sử mã nguồn mở Việt Nam. Tiếp đó, năm 2011 Mã nguồn mở NukeViet đã giành giải thưởng Nhân tài đất Việt cho sản phẩm Công nghệ thông tin đã được ứng dụng rộng rãi.<br  /> <div style=\"text-align: center;\"> <object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" height=\"400\" width=\"480\"><param name=\"movie\" value=\"/phapluat2/images/jwplayer/player.swf\" /><param name=\"allowfullscreen\" value=\"true\" /><param name=\"allowscriptaccess\" value=\"always\" /><param name=\"flashvars\" value=\"file=http://www.youtube.com/watch?v=ZOhu2bLE-eA&amp;autostart=true\" /><embed allowfullscreen=\"true\" allowscriptaccess=\"always\" flashvars=\"file=http://www.youtube.com/watch?v=ZOhu2bLE-eA&amp;autostart=true\" height=\"400\" src=\"/phapluat2/images/jwplayer/player.swf\" width=\"480\"></embed></object><br  /> <strong>Video clip trao giải Nhân tài đất Việt 2011.</strong><br  /> Sản phẩm &quot;Mã nguồn mở NukeViet&quot; đã nhận giải cao nhất (Giải ba, không có giải nhất, giải nhì) của Giải thưởng Nhân Tài Đất Việt 2011 ở lĩnh vực Công nghệ thông tin - Sản phẩm đã có ứng dụng rộng rãi.</div><br  /> Tự chuyên nghiệp hóa mình, thoát khỏi mô hình phát triển tự phát, công ty đã nỗ lực vươn mình ra thế giới và đang phấn đấu trở thành một trong những hiện tượng của thời &quot;dotcom&quot; ở Việt Nam.<br  /> <br  /> Để phục vụ hoạt động của công ty, công ty liên tục mở rộng và tuyển thêm nhân sự ở các vị trí: Lập trình viên, chuyên viên đồ họa, nhân viên kinh doanh... Hãy liên hệ ngay để gia nhập VINADES.,JSC và cùng chúng tôi trở thành một công ty phát triển nguồn mở thành công nhất Việt Nam.</p> <p>Nếu bạn có nhu cầu triển khai các hệ thống <a href=\"http://toasoandientu.vn\" target=\"_blank\">Tòa Soạn Điện Tử</a>, <a href=\"http://webnhanh.vn\" target=\"_blank\">phần mềm trực tuyến</a>, <a href=\"http://vinades.vn\" target=\"_blank\">thiết kế web</a> theo yêu cầu hoặc dịch vụ có liên quan, hãy liên hệ công ty chuyên quản NukeViet theo thông tin dưới đây:</p><strong><span style=\"font-family: Tahoma; color: rgb(255, 69, 0); font-size: 14px;\">CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM</span></strong><br  /><div> <strong>VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY</strong> (<strong>VINADES.,JSC</strong>)<br  /> <div>Website: <a href=\"http://vinades.vn/\">http://vinades.vn</a> | <a href=\"http://nukeviet.vn/\">http://nukeviet.vn</a> | <a href=\"http://webnhanh.vn/\">http://webnhanh.vn</a></div><br  />Trụ sở: Phòng 407 Tòa nhà CT1 FODACON, 18 Trần Phú, Hà Đông, Hà Nội.<br  /> - Tel: +84-4-85872007<br  /> - Fax: +84-4-35500914<br  /> - Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></div><br  />Chi nhánh: 69/6/10A khu phố 10, đường Tân Chánh Hiệp 7, phường Tân Chánh Hiệp, quận 12, tp. Hồ Chí Minh.<br  /> - Tel: +84-8-62736367<br  /> - Email: <a href=\"mailto:hcm@vinades.vn\">hcm@vinades.vn</a></div>', '', 2, 1, 1275320224, 1275320224, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_blocks_groups`
--

DROP TABLE IF EXISTS `nv3_vi_blocks_groups`;
CREATE TABLE `nv3_vi_blocks_groups` (
  `bid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(55) NOT NULL,
  `module` varchar(55) NOT NULL,
  `file_name` varchar(55) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `template` varchar(55) DEFAULT NULL,
  `position` varchar(55) DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` tinyint(4) DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text,
  PRIMARY KEY (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=30  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_blocks_groups`
--

INSERT INTO `nv3_vi_blocks_groups` VALUES
(1, 'default', 'news', 'global.block_category.php', 'Menu', '', '', '[LEFT]', 0, 1, '0', 0, 1, 'a:1:{s:12:\"title_length\";i:25;}'), 
(2, 'default', 'statistics', 'global.counter.php', 'Thống kê truy cập', '', '', '[LEFT]', 0, 1, '0', 1, 2, ''), 
(3, 'default', 'banners', 'global.banners.php', 'Quảng cáo trái', '', '', '[LEFT]', 0, 1, '0', 1, 3, 'a:1:{s:12:\"idplanbanner\";i:2;}'), 
(4, 'default', 'about', 'global.about.php', 'Giới thiệu', '', 'orange', '[RIGHT]', 0, 1, '0', 1, 1, ''), 
(5, 'default', 'users', 'global.login.php', 'Đăng nhập thành viên', '', '', '[RIGHT]', 0, 1, '0', 1, 2, ''), 
(6, 'default', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '0', 1, 3, ''), 
(7, 'default', 'news', 'module.block_headline.php', 'Tin nổi bật', '', 'no_title', '[TOP]', 0, 1, '0', 0, 1, ''), 
(9, 'modern', 'news', 'module.block_newscenter.php', 'Tin mới', '', 'no_title', '[HEADER]', 0, 1, '0', 0, 1, ''), 
(10, 'modern', 'about', 'global.about.php', 'Giới thiệu', '', 'no_title_html', '[RIGHT]', 0, 1, '0', 1, 1, ''), 
(11, 'modern', 'users', 'global.login.php', 'Đăng nhập', '', '', '[RIGHT]', 0, 1, '0', 1, 2, ''), 
(12, 'modern', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '0', 1, 3, ''), 
(13, 'modern', 'statistics', 'global.counter.php', 'Bộ đếm', '', '', '[RIGHT]', 0, 1, '0', 1, 4, ''), 
(14, 'modern', 'news', 'module.block_newsright.php', 'News Right', '', 'no_title', '[RIGHT]', 0, 1, '0', 0, 5, ''), 
(15, 'modern', 'banners', 'global.banners.php', 'Quảng cáo top banner', '', 'no_title', '[TOPADV]', 0, 1, '0', 1, 1, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(16, 'modern', 'menu', 'global.menu_theme_modern.php', 'global menu theme modern', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''), 
(17, 'default', 'menu', 'global.menu_theme_default.php', 'global menu theme default', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''), 
(18, 'modern', 'global', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '0', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:274:\"© Copyright NukeViet 3. All right reserved.<br  />Xây dựng trên nền tảng <a href=\"http://nukeviet.vn/\" title=\"Mã nguồn mở NukeViet\">Mã nguồn mở NukeViet</a>. <a href=\"http://vinades.vn/\" title=\"Thiết kế web\">Thiết kế website</a> bởi VINADES.,JSC\";}'), 
(19, 'default', 'global', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '0', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:231:\"<p class=\"footer\"> © Copyright NukeViet 3. All right reserved.</p><p> Powered by <a href=\"http://nukeviet.vn/\" title=\"NukeViet CMS\">NukeViet CMS</a>. Design by <a href=\"http://vinades.vn/\" title=\"VINADES.,JSC\">VINADES.,JSC</a></p>\";}'), 
(20, 'mobile_nukeviet', 'menu', 'global.menu_theme_default.php', 'global menu theme default', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''), 
(21, 'phapluat2', 'users', 'global.login.php', 'Thành viên', '', '', '[RIGHT]', 0, 1, '0', 1, 1, ''), 
(24, 'phapluat2', 'news', 'global.block_category.php', 'Lĩnh vực hoạt động', '', '', '[LEFT]', 0, 1, '0', 0, 1, 'a:1:{s:12:\"title_length\";i:30;}'), 
(23, 'phapluat2', 'menu', 'global.menu_theme_default.php', 'global menu theme default', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''), 
(25, 'phapluat2', 'news', 'global.block_topnews.php', 'global block topnews', '', '', '[RIGHT]', 0, 1, '0', 1, 2, 'a:2:{s:10:\"number_day\";i:365;s:6:\"numrow\";i:10;}'), 
(26, 'phapluat2', 'voting', 'global.voting.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '0', 1, 3, 'a:1:{s:3:\"vid\";i:3;}'), 
(27, 'phapluat2', 'statistics', 'global.counter.php', 'Thống kê', '', '', '[LEFT]', 0, 1, '0', 1, 2, ''), 
(29, 'phapluat2', 'thu-vien-van-ban', 'global.block_category.php', 'Thư viện văn bản', '', '', '[LEFT]', 0, 1, '0', 0, 3, 'a:1:{s:12:\"title_length\";i:30;}');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_blocks_weight`
--

DROP TABLE IF EXISTS `nv3_vi_blocks_weight`;
CREATE TABLE `nv3_vi_blocks_weight` (
  `bid` int(11) NOT NULL DEFAULT '0',
  `func_id` int(11) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_blocks_weight`
--

INSERT INTO `nv3_vi_blocks_weight` VALUES
(1, 5, 1), 
(1, 6, 1), 
(1, 7, 1), 
(1, 13, 1), 
(1, 15, 1), 
(1, 16, 1), 
(2, 2, 1), 
(2, 36, 1), 
(2, 39, 1), 
(2, 42, 1), 
(2, 43, 1), 
(2, 27, 1), 
(2, 5, 2), 
(2, 6, 2), 
(2, 7, 2), 
(2, 13, 2), 
(2, 15, 2), 
(2, 16, 2), 
(2, 47, 1), 
(2, 46, 1), 
(2, 28, 1), 
(2, 29, 1), 
(2, 30, 1), 
(2, 31, 1), 
(2, 32, 1), 
(2, 33, 1), 
(2, 34, 1), 
(2, 17, 1), 
(2, 25, 1), 
(2, 24, 1), 
(2, 23, 1), 
(2, 22, 1), 
(2, 21, 1), 
(2, 20, 1), 
(2, 19, 1), 
(2, 18, 1), 
(2, 26, 1), 
(3, 2, 2), 
(3, 36, 2), 
(3, 39, 2), 
(3, 42, 2), 
(3, 43, 2), 
(3, 27, 2), 
(3, 5, 3), 
(3, 6, 3), 
(3, 7, 3), 
(3, 13, 3), 
(3, 15, 3), 
(3, 16, 3), 
(3, 47, 2), 
(3, 46, 2), 
(3, 28, 2), 
(3, 29, 2), 
(3, 30, 2), 
(3, 31, 2), 
(3, 32, 2), 
(3, 33, 2), 
(3, 34, 2), 
(3, 17, 2), 
(3, 25, 2), 
(3, 24, 2), 
(3, 23, 2), 
(3, 22, 2), 
(3, 21, 2), 
(3, 20, 2), 
(3, 19, 2), 
(3, 18, 2), 
(3, 26, 2), 
(4, 2, 1), 
(4, 36, 1), 
(4, 39, 1), 
(4, 42, 1), 
(4, 43, 1), 
(4, 27, 1), 
(4, 5, 1), 
(4, 6, 1), 
(4, 7, 1), 
(4, 13, 1), 
(4, 15, 1), 
(4, 16, 1), 
(4, 47, 1), 
(4, 46, 1), 
(4, 28, 1), 
(4, 29, 1), 
(4, 30, 1), 
(4, 31, 1), 
(4, 32, 1), 
(4, 33, 1), 
(4, 34, 1), 
(4, 17, 1), 
(4, 25, 1), 
(4, 24, 1), 
(4, 23, 1), 
(4, 22, 1), 
(4, 21, 1), 
(4, 20, 1), 
(4, 19, 1), 
(4, 18, 1), 
(4, 26, 1), 
(5, 2, 2), 
(5, 36, 2), 
(5, 39, 2), 
(5, 42, 2), 
(5, 43, 2), 
(5, 27, 2), 
(5, 5, 2), 
(5, 6, 2), 
(5, 7, 2), 
(5, 13, 2), 
(5, 15, 2), 
(5, 16, 2), 
(5, 47, 2), 
(5, 46, 2), 
(5, 28, 2), 
(5, 29, 2), 
(5, 30, 2), 
(5, 31, 2), 
(5, 32, 2), 
(5, 33, 2), 
(5, 34, 2), 
(5, 17, 2), 
(5, 25, 2), 
(5, 24, 2), 
(5, 23, 2), 
(5, 22, 2), 
(5, 21, 2), 
(5, 20, 2), 
(5, 19, 2), 
(5, 18, 2), 
(5, 26, 2), 
(6, 2, 3), 
(6, 36, 3), 
(6, 39, 3), 
(6, 42, 3), 
(6, 43, 3), 
(6, 27, 3), 
(6, 5, 3), 
(6, 6, 3), 
(6, 7, 3), 
(6, 13, 3), 
(6, 15, 3), 
(6, 16, 3), 
(6, 47, 3), 
(6, 46, 3), 
(6, 28, 3), 
(6, 29, 3), 
(6, 30, 3), 
(6, 31, 3), 
(6, 32, 3), 
(6, 33, 3), 
(6, 34, 3), 
(6, 17, 3), 
(6, 25, 3), 
(6, 24, 3), 
(6, 23, 3), 
(6, 22, 3), 
(6, 21, 3), 
(6, 20, 3), 
(6, 19, 3), 
(6, 18, 3), 
(6, 26, 3), 
(7, 7, 1), 
(9, 7, 1), 
(10, 2, 1), 
(10, 36, 1), 
(10, 39, 1), 
(10, 42, 1), 
(10, 43, 1), 
(10, 27, 1), 
(10, 5, 1), 
(10, 6, 1), 
(10, 7, 1), 
(10, 13, 1), 
(10, 15, 1), 
(10, 16, 1), 
(10, 47, 1), 
(10, 46, 1), 
(10, 28, 1), 
(10, 29, 1), 
(10, 30, 1), 
(10, 31, 1), 
(10, 32, 1), 
(10, 33, 1), 
(10, 34, 1), 
(10, 17, 1), 
(10, 25, 1), 
(10, 24, 1), 
(10, 23, 1), 
(10, 22, 1), 
(10, 21, 1), 
(10, 20, 1), 
(10, 19, 1), 
(10, 18, 1), 
(10, 26, 1), 
(11, 2, 2), 
(11, 36, 2), 
(11, 39, 2), 
(11, 42, 2), 
(11, 43, 2), 
(11, 27, 2), 
(11, 5, 2), 
(11, 6, 2), 
(11, 7, 2), 
(11, 13, 2), 
(11, 15, 2), 
(11, 16, 2), 
(11, 47, 2), 
(11, 46, 2), 
(11, 28, 2), 
(11, 29, 2), 
(11, 30, 2), 
(11, 31, 2), 
(11, 32, 2), 
(11, 33, 2), 
(11, 34, 2), 
(11, 17, 2), 
(11, 25, 2), 
(11, 24, 2), 
(11, 23, 2), 
(11, 22, 2), 
(11, 21, 2), 
(11, 20, 2), 
(11, 19, 2), 
(11, 18, 2), 
(11, 26, 2), 
(12, 2, 3), 
(12, 36, 3), 
(12, 39, 3), 
(12, 42, 3), 
(12, 43, 3), 
(12, 27, 3), 
(12, 5, 3), 
(12, 6, 3), 
(12, 7, 3), 
(12, 13, 3), 
(12, 15, 3), 
(12, 16, 3), 
(12, 47, 3), 
(12, 46, 3), 
(12, 28, 3), 
(12, 29, 3), 
(12, 30, 3), 
(12, 31, 3), 
(12, 32, 3), 
(12, 33, 3), 
(12, 34, 3), 
(12, 17, 3), 
(12, 25, 3), 
(12, 24, 3), 
(12, 23, 3), 
(12, 22, 3), 
(12, 21, 3), 
(12, 20, 3), 
(12, 19, 3), 
(12, 18, 3), 
(12, 26, 3), 
(13, 2, 4), 
(13, 36, 4), 
(13, 39, 4), 
(13, 42, 4), 
(13, 43, 4), 
(13, 27, 4), 
(13, 5, 4), 
(13, 6, 4), 
(13, 7, 4), 
(13, 13, 4), 
(13, 15, 4), 
(13, 16, 4), 
(13, 47, 4), 
(13, 46, 4), 
(13, 28, 4), 
(13, 29, 4), 
(13, 30, 4), 
(13, 31, 4), 
(13, 32, 4), 
(13, 33, 4), 
(13, 34, 4), 
(13, 17, 4), 
(13, 25, 4), 
(13, 24, 4), 
(13, 23, 4), 
(13, 22, 4), 
(13, 21, 4), 
(13, 20, 4), 
(13, 19, 4), 
(13, 18, 4), 
(13, 26, 4), 
(14, 5, 5), 
(14, 6, 5), 
(14, 7, 5), 
(14, 13, 5), 
(14, 15, 5), 
(14, 16, 5), 
(15, 2, 1), 
(15, 36, 1), 
(15, 39, 1), 
(15, 42, 1), 
(15, 43, 1), 
(15, 27, 1), 
(15, 5, 1), 
(15, 6, 1), 
(15, 7, 1), 
(15, 13, 1), 
(15, 15, 1), 
(15, 16, 1), 
(15, 47, 1), 
(15, 46, 1), 
(15, 28, 1), 
(15, 29, 1), 
(15, 30, 1), 
(15, 31, 1), 
(15, 32, 1), 
(15, 33, 1), 
(15, 34, 1), 
(15, 17, 1), 
(15, 25, 1), 
(15, 24, 1), 
(15, 23, 1), 
(15, 22, 1), 
(15, 21, 1), 
(15, 20, 1), 
(15, 19, 1), 
(15, 18, 1), 
(15, 26, 1), 
(16, 2, 1), 
(16, 36, 1), 
(16, 39, 1), 
(16, 42, 1), 
(16, 43, 1), 
(16, 27, 1), 
(16, 5, 1), 
(16, 6, 1), 
(16, 7, 1), 
(16, 13, 1), 
(16, 15, 1), 
(16, 16, 1), 
(16, 47, 1), 
(16, 46, 1), 
(16, 33, 1), 
(16, 32, 1), 
(16, 30, 1), 
(16, 29, 1), 
(16, 31, 1), 
(16, 28, 1), 
(16, 34, 1), 
(16, 24, 1), 
(16, 20, 1), 
(16, 21, 1), 
(16, 26, 1), 
(16, 23, 1), 
(16, 18, 1), 
(16, 25, 1), 
(16, 17, 1), 
(16, 22, 1), 
(16, 19, 1), 
(17, 2, 1), 
(17, 36, 1), 
(17, 39, 1), 
(17, 42, 1), 
(17, 43, 1), 
(17, 27, 1), 
(17, 5, 1), 
(17, 6, 1), 
(17, 7, 1), 
(17, 13, 1), 
(17, 15, 1), 
(17, 16, 1), 
(17, 47, 1), 
(17, 46, 1), 
(17, 33, 1), 
(17, 32, 1), 
(17, 30, 1), 
(17, 29, 1), 
(17, 31, 1), 
(17, 28, 1), 
(17, 34, 1), 
(17, 24, 1), 
(17, 20, 1), 
(17, 21, 1), 
(17, 26, 1), 
(17, 23, 1), 
(17, 18, 1), 
(17, 25, 1), 
(17, 17, 1), 
(17, 22, 1), 
(17, 19, 1), 
(18, 2, 1), 
(18, 36, 1), 
(18, 39, 1), 
(18, 42, 1), 
(18, 43, 1), 
(18, 27, 1), 
(18, 5, 1), 
(18, 6, 1), 
(18, 7, 1), 
(18, 13, 1), 
(18, 15, 1), 
(18, 16, 1), 
(18, 47, 1), 
(18, 46, 1), 
(18, 33, 1), 
(18, 32, 1), 
(18, 30, 1), 
(18, 29, 1), 
(18, 31, 1), 
(18, 28, 1), 
(18, 34, 1), 
(18, 24, 1), 
(18, 20, 1), 
(18, 21, 1), 
(18, 26, 1), 
(18, 23, 1), 
(18, 18, 1), 
(18, 25, 1), 
(18, 17, 1), 
(18, 22, 1), 
(18, 19, 1), 
(19, 2, 1), 
(19, 36, 1), 
(19, 39, 1), 
(19, 42, 1), 
(19, 43, 1), 
(19, 27, 1), 
(19, 5, 1), 
(19, 6, 1), 
(19, 7, 1), 
(19, 13, 1), 
(19, 15, 1), 
(19, 16, 1), 
(19, 47, 1), 
(19, 46, 1), 
(19, 33, 1), 
(19, 32, 1), 
(19, 30, 1), 
(19, 29, 1), 
(19, 31, 1), 
(19, 28, 1), 
(19, 34, 1), 
(19, 24, 1), 
(19, 20, 1), 
(19, 21, 1), 
(19, 26, 1), 
(19, 23, 1), 
(19, 18, 1), 
(19, 25, 1), 
(19, 17, 1), 
(19, 22, 1), 
(19, 19, 1), 
(19, 48, 1), 
(2, 48, 1), 
(3, 48, 2), 
(17, 48, 1), 
(4, 48, 1), 
(5, 48, 2), 
(6, 48, 3), 
(18, 48, 1), 
(16, 48, 1), 
(10, 48, 1), 
(11, 48, 2), 
(12, 48, 3), 
(13, 48, 4), 
(15, 48, 1), 
(20, 2, 1), 
(20, 36, 1), 
(20, 39, 1), 
(20, 42, 1), 
(20, 43, 1), 
(20, 27, 1), 
(20, 5, 1), 
(20, 6, 1), 
(20, 7, 1), 
(20, 13, 1), 
(20, 15, 1), 
(20, 16, 1), 
(20, 47, 1), 
(20, 46, 1), 
(20, 33, 1), 
(20, 32, 1), 
(20, 30, 1), 
(20, 29, 1), 
(20, 31, 1), 
(20, 28, 1), 
(20, 34, 1), 
(20, 48, 1), 
(20, 24, 1), 
(20, 20, 1), 
(20, 21, 1), 
(20, 26, 1), 
(20, 23, 1), 
(20, 18, 1), 
(20, 25, 1), 
(20, 17, 1), 
(20, 22, 1), 
(20, 19, 1), 
(16, 35, 1), 
(10, 35, 1), 
(11, 35, 2), 
(12, 35, 3), 
(13, 35, 4), 
(15, 35, 1), 
(18, 35, 1), 
(17, 35, 1), 
(19, 35, 1), 
(2, 35, 1), 
(3, 35, 2), 
(4, 35, 1), 
(5, 35, 2), 
(6, 35, 3), 
(20, 35, 1), 
(16, 50, 1), 
(10, 50, 1), 
(11, 50, 2), 
(12, 50, 3), 
(13, 50, 4), 
(15, 50, 1), 
(18, 50, 1), 
(17, 50, 1), 
(19, 50, 1), 
(2, 50, 1), 
(3, 50, 2), 
(4, 50, 1), 
(5, 50, 2), 
(6, 50, 3), 
(20, 50, 1), 
(21, 2, 1), 
(21, 36, 1), 
(21, 39, 1), 
(21, 42, 1), 
(21, 43, 1), 
(21, 27, 1), 
(21, 5, 1), 
(21, 6, 1), 
(21, 7, 1), 
(21, 13, 1), 
(21, 15, 1), 
(21, 16, 1), 
(21, 50, 1), 
(21, 47, 1), 
(21, 46, 1), 
(21, 33, 1), 
(21, 32, 1), 
(21, 30, 1), 
(21, 29, 1), 
(21, 31, 1), 
(21, 28, 1), 
(21, 34, 1), 
(21, 48, 1), 
(21, 24, 1), 
(21, 20, 1), 
(21, 21, 1), 
(21, 26, 1), 
(21, 23, 1), 
(21, 18, 1), 
(21, 25, 1), 
(21, 17, 1), 
(21, 22, 1), 
(21, 19, 1), 
(21, 35, 1), 
(23, 2, 1), 
(23, 36, 1), 
(23, 39, 1), 
(23, 42, 1), 
(23, 43, 1), 
(23, 27, 1), 
(23, 5, 1), 
(23, 6, 1), 
(23, 7, 1), 
(23, 13, 1), 
(23, 15, 1), 
(23, 16, 1), 
(23, 50, 1), 
(23, 47, 1), 
(23, 46, 1), 
(23, 33, 1), 
(23, 32, 1), 
(23, 30, 1), 
(23, 29, 1), 
(23, 31, 1), 
(23, 28, 1), 
(23, 34, 1), 
(23, 48, 1), 
(23, 24, 1), 
(23, 20, 1), 
(23, 21, 1), 
(23, 26, 1), 
(23, 23, 1), 
(23, 18, 1), 
(23, 25, 1), 
(23, 17, 1), 
(23, 22, 1), 
(23, 19, 1), 
(23, 35, 1), 
(24, 2, 1), 
(24, 36, 1), 
(24, 39, 1), 
(24, 42, 1), 
(24, 43, 1), 
(24, 27, 1), 
(24, 5, 1), 
(24, 6, 1), 
(24, 7, 1), 
(24, 13, 1), 
(24, 15, 1), 
(24, 16, 1), 
(24, 50, 1), 
(24, 47, 1), 
(24, 46, 1), 
(24, 33, 1), 
(24, 32, 1), 
(24, 30, 1), 
(24, 29, 1), 
(24, 31, 1), 
(24, 28, 1), 
(24, 34, 1), 
(24, 48, 1), 
(24, 24, 1), 
(24, 20, 1), 
(24, 21, 1), 
(24, 26, 1), 
(24, 23, 1), 
(24, 18, 1), 
(24, 25, 1), 
(24, 17, 1), 
(24, 22, 1), 
(24, 19, 1), 
(24, 35, 1), 
(25, 2, 2), 
(25, 36, 2), 
(25, 39, 2), 
(25, 42, 2), 
(25, 43, 2), 
(25, 27, 2), 
(25, 5, 2), 
(25, 6, 2), 
(25, 7, 2), 
(25, 13, 2), 
(25, 15, 2), 
(25, 16, 2), 
(25, 50, 2), 
(25, 47, 2), 
(25, 46, 2), 
(25, 33, 2), 
(25, 32, 2), 
(25, 30, 2), 
(25, 29, 2), 
(25, 31, 2), 
(25, 28, 2), 
(25, 34, 2), 
(25, 48, 2), 
(25, 24, 2), 
(25, 20, 2), 
(25, 21, 2), 
(25, 26, 2), 
(25, 23, 2), 
(25, 18, 2), 
(25, 25, 2), 
(25, 17, 2), 
(25, 22, 2), 
(25, 19, 2), 
(25, 35, 2), 
(26, 2, 3), 
(26, 36, 3), 
(26, 39, 3), 
(26, 42, 3), 
(26, 43, 3), 
(26, 27, 3), 
(26, 5, 3), 
(26, 6, 3), 
(26, 7, 3), 
(26, 13, 3), 
(26, 15, 3), 
(26, 16, 3), 
(26, 50, 3), 
(26, 47, 3), 
(26, 46, 3), 
(26, 33, 3), 
(26, 32, 3), 
(26, 30, 3), 
(26, 29, 3), 
(26, 31, 3), 
(26, 28, 3), 
(26, 34, 3), 
(26, 48, 3), 
(26, 24, 3), 
(26, 20, 3), 
(26, 21, 3), 
(26, 26, 3), 
(26, 23, 3), 
(26, 18, 3), 
(26, 25, 3), 
(26, 17, 3), 
(26, 22, 3), 
(26, 19, 3), 
(26, 35, 3), 
(27, 2, 2), 
(27, 36, 2), 
(27, 39, 2), 
(27, 42, 2), 
(27, 43, 2), 
(27, 27, 2), 
(27, 5, 2), 
(27, 6, 2), 
(27, 7, 2), 
(27, 13, 2), 
(27, 15, 2), 
(27, 16, 2), 
(27, 50, 2), 
(27, 47, 2), 
(27, 46, 2), 
(27, 33, 2), 
(27, 32, 2), 
(27, 30, 2), 
(27, 29, 2), 
(27, 31, 2), 
(27, 28, 2), 
(27, 34, 2), 
(27, 48, 2), 
(27, 24, 2), 
(27, 20, 2), 
(27, 21, 2), 
(27, 26, 2), 
(27, 23, 2), 
(27, 18, 2), 
(27, 25, 2), 
(27, 17, 2), 
(27, 22, 2), 
(27, 19, 2), 
(27, 35, 2), 
(19, 62, 1), 
(19, 74, 1), 
(19, 58, 1), 
(19, 70, 1), 
(19, 53, 1), 
(19, 63, 1), 
(19, 64, 1), 
(19, 55, 1), 
(19, 60, 1), 
(19, 59, 1), 
(2, 62, 1), 
(2, 74, 1), 
(2, 58, 1), 
(2, 70, 1), 
(2, 53, 1), 
(2, 63, 1), 
(2, 64, 1), 
(2, 55, 1), 
(2, 60, 1), 
(2, 59, 1), 
(3, 62, 2), 
(3, 74, 2), 
(3, 58, 2), 
(3, 70, 2), 
(3, 53, 2), 
(3, 63, 2), 
(3, 64, 2), 
(3, 55, 2), 
(3, 60, 2), 
(3, 59, 2), 
(17, 62, 1), 
(17, 74, 1), 
(17, 58, 1), 
(17, 70, 1), 
(17, 53, 1), 
(17, 63, 1), 
(17, 64, 1), 
(17, 55, 1), 
(17, 60, 1), 
(17, 59, 1), 
(4, 62, 1), 
(4, 74, 1), 
(4, 58, 1), 
(4, 70, 1), 
(4, 53, 1), 
(4, 63, 1), 
(4, 64, 1), 
(4, 55, 1), 
(4, 60, 1), 
(4, 59, 1), 
(5, 62, 2), 
(5, 74, 2), 
(5, 58, 2), 
(5, 70, 2), 
(5, 53, 2), 
(5, 63, 2), 
(5, 64, 2), 
(5, 55, 2), 
(5, 60, 2), 
(5, 59, 2), 
(6, 62, 3), 
(6, 74, 3), 
(6, 58, 3), 
(6, 70, 3), 
(6, 53, 3), 
(6, 63, 3), 
(6, 64, 3), 
(6, 55, 3), 
(6, 60, 3), 
(6, 59, 3), 
(20, 62, 1), 
(20, 74, 1), 
(20, 58, 1), 
(20, 70, 1), 
(20, 53, 1), 
(20, 63, 1), 
(20, 64, 1), 
(20, 55, 1), 
(20, 60, 1), 
(20, 59, 1), 
(18, 62, 1), 
(18, 74, 1), 
(18, 58, 1), 
(18, 70, 1), 
(18, 53, 1), 
(18, 63, 1), 
(18, 64, 1), 
(18, 55, 1), 
(18, 60, 1), 
(18, 59, 1), 
(16, 62, 1), 
(16, 74, 1), 
(16, 58, 1), 
(16, 70, 1), 
(16, 53, 1), 
(16, 63, 1), 
(16, 64, 1), 
(16, 55, 1), 
(16, 60, 1), 
(16, 59, 1), 
(10, 62, 1), 
(10, 74, 1), 
(10, 58, 1), 
(10, 70, 1), 
(10, 53, 1), 
(10, 63, 1), 
(10, 64, 1), 
(10, 55, 1), 
(10, 60, 1), 
(10, 59, 1), 
(11, 62, 2), 
(11, 74, 2), 
(11, 58, 2), 
(11, 70, 2), 
(11, 53, 2), 
(11, 63, 2), 
(11, 64, 2), 
(11, 55, 2), 
(11, 60, 2), 
(11, 59, 2), 
(12, 62, 3), 
(12, 74, 3), 
(12, 58, 3), 
(12, 70, 3), 
(12, 53, 3), 
(12, 63, 3), 
(12, 64, 3), 
(12, 55, 3), 
(12, 60, 3), 
(12, 59, 3), 
(13, 62, 4), 
(13, 74, 4), 
(13, 58, 4), 
(13, 70, 4), 
(13, 53, 4), 
(13, 63, 4), 
(13, 64, 4), 
(13, 55, 4), 
(13, 60, 4), 
(13, 59, 4), 
(15, 62, 1), 
(15, 74, 1), 
(15, 58, 1), 
(15, 70, 1), 
(15, 53, 1), 
(15, 63, 1), 
(15, 64, 1), 
(15, 55, 1), 
(15, 60, 1), 
(15, 59, 1), 
(29, 112, 3), 
(29, 102, 3), 
(29, 103, 3), 
(29, 104, 1), 
(29, 113, 3), 
(27, 62, 2), 
(27, 74, 2), 
(27, 58, 2), 
(27, 70, 2), 
(27, 53, 2), 
(27, 63, 2), 
(27, 64, 2), 
(27, 55, 2), 
(27, 60, 2), 
(27, 59, 2), 
(23, 62, 1), 
(23, 74, 1), 
(23, 58, 1), 
(23, 70, 1), 
(23, 53, 1), 
(23, 63, 1), 
(23, 64, 1), 
(23, 55, 1), 
(23, 60, 1), 
(23, 59, 1), 
(21, 62, 1), 
(21, 74, 1), 
(21, 58, 1), 
(21, 70, 1), 
(21, 53, 1), 
(21, 63, 1), 
(21, 64, 1), 
(21, 55, 1), 
(21, 60, 1), 
(21, 59, 1), 
(25, 62, 2), 
(25, 74, 2), 
(25, 58, 2), 
(25, 70, 2), 
(25, 53, 2), 
(25, 63, 2), 
(25, 64, 2), 
(25, 55, 2), 
(25, 60, 2), 
(25, 59, 2), 
(26, 62, 3), 
(26, 74, 3), 
(26, 58, 3), 
(26, 70, 3), 
(26, 53, 3), 
(26, 63, 3), 
(26, 64, 3), 
(26, 55, 3), 
(26, 60, 3), 
(26, 59, 3), 
(19, 86, 1), 
(19, 98, 1), 
(19, 82, 1), 
(19, 94, 1), 
(19, 77, 1), 
(19, 87, 1), 
(19, 88, 1), 
(19, 79, 1), 
(19, 84, 1), 
(19, 83, 1), 
(2, 86, 1), 
(2, 98, 1), 
(2, 82, 1), 
(2, 94, 1), 
(2, 77, 1), 
(2, 87, 1), 
(2, 88, 1), 
(2, 79, 1), 
(2, 84, 1), 
(2, 83, 1), 
(3, 86, 2), 
(3, 98, 2), 
(3, 82, 2), 
(3, 94, 2), 
(3, 77, 2), 
(3, 87, 2), 
(3, 88, 2), 
(3, 79, 2), 
(3, 84, 2), 
(3, 83, 2), 
(17, 86, 1), 
(17, 98, 1), 
(17, 82, 1), 
(17, 94, 1), 
(17, 77, 1), 
(17, 87, 1), 
(17, 88, 1), 
(17, 79, 1), 
(17, 84, 1), 
(17, 83, 1), 
(4, 86, 1), 
(4, 98, 1), 
(4, 82, 1), 
(4, 94, 1), 
(4, 77, 1), 
(4, 87, 1), 
(4, 88, 1), 
(4, 79, 1), 
(4, 84, 1), 
(4, 83, 1), 
(5, 86, 2), 
(5, 98, 2), 
(5, 82, 2), 
(5, 94, 2), 
(5, 77, 2), 
(5, 87, 2), 
(5, 88, 2), 
(5, 79, 2), 
(5, 84, 2), 
(5, 83, 2), 
(6, 86, 3), 
(6, 98, 3), 
(6, 82, 3), 
(6, 94, 3), 
(6, 77, 3), 
(6, 87, 3), 
(6, 88, 3), 
(6, 79, 3), 
(6, 84, 3), 
(6, 83, 3), 
(20, 86, 1), 
(20, 98, 1), 
(20, 82, 1), 
(20, 94, 1), 
(20, 77, 1), 
(20, 87, 1), 
(20, 88, 1), 
(20, 79, 1), 
(20, 84, 1), 
(20, 83, 1), 
(18, 86, 1), 
(18, 98, 1), 
(18, 82, 1), 
(18, 94, 1), 
(18, 77, 1), 
(18, 87, 1), 
(18, 88, 1), 
(18, 79, 1), 
(18, 84, 1), 
(18, 83, 1), 
(16, 86, 1), 
(16, 98, 1), 
(16, 82, 1), 
(16, 94, 1), 
(16, 77, 1), 
(16, 87, 1), 
(16, 88, 1), 
(16, 79, 1), 
(16, 84, 1), 
(16, 83, 1), 
(10, 86, 1), 
(10, 98, 1), 
(10, 82, 1), 
(10, 94, 1), 
(10, 77, 1), 
(10, 87, 1), 
(10, 88, 1), 
(10, 79, 1), 
(10, 84, 1), 
(10, 83, 1), 
(11, 86, 2), 
(11, 98, 2), 
(11, 82, 2), 
(11, 94, 2), 
(11, 77, 2), 
(11, 87, 2), 
(11, 88, 2), 
(11, 79, 2), 
(11, 84, 2), 
(11, 83, 2), 
(12, 86, 3), 
(12, 98, 3), 
(12, 82, 3), 
(12, 94, 3), 
(12, 77, 3), 
(12, 87, 3), 
(12, 88, 3), 
(12, 79, 3), 
(12, 84, 3), 
(12, 83, 3), 
(13, 86, 4), 
(13, 98, 4), 
(13, 82, 4), 
(13, 94, 4), 
(13, 77, 4), 
(13, 87, 4), 
(13, 88, 4), 
(13, 79, 4), 
(13, 84, 4), 
(13, 83, 4), 
(15, 86, 1), 
(15, 98, 1), 
(15, 82, 1), 
(15, 94, 1), 
(15, 77, 1), 
(15, 87, 1), 
(15, 88, 1), 
(15, 79, 1), 
(15, 84, 1), 
(15, 83, 1), 
(27, 86, 2), 
(27, 98, 2), 
(27, 82, 2), 
(27, 94, 2), 
(27, 77, 2), 
(27, 87, 2), 
(27, 88, 2), 
(27, 79, 2), 
(27, 84, 2), 
(27, 83, 2), 
(23, 86, 1), 
(23, 98, 1), 
(23, 82, 1), 
(23, 94, 1), 
(23, 77, 1), 
(23, 87, 1), 
(23, 88, 1), 
(23, 79, 1), 
(23, 84, 1), 
(23, 83, 1), 
(21, 86, 1), 
(21, 98, 1), 
(21, 82, 1), 
(21, 94, 1), 
(21, 77, 1), 
(21, 87, 1), 
(21, 88, 1), 
(21, 79, 1), 
(21, 84, 1), 
(21, 83, 1), 
(25, 86, 2), 
(25, 98, 2), 
(25, 82, 2), 
(25, 94, 2), 
(25, 77, 2), 
(25, 87, 2), 
(25, 88, 2), 
(25, 79, 2), 
(25, 84, 2), 
(25, 83, 2), 
(26, 86, 3), 
(26, 98, 3), 
(26, 82, 3), 
(26, 94, 3), 
(26, 77, 3), 
(26, 87, 3), 
(26, 88, 3), 
(26, 79, 3), 
(26, 84, 3), 
(26, 83, 3), 
(19, 104, 1), 
(19, 113, 1), 
(19, 112, 1), 
(19, 103, 1), 
(19, 102, 1), 
(19, 110, 1), 
(19, 101, 1), 
(2, 104, 1), 
(2, 113, 1), 
(2, 112, 1), 
(2, 103, 1), 
(2, 102, 1), 
(2, 110, 1), 
(2, 101, 1), 
(3, 104, 2), 
(3, 113, 2), 
(3, 112, 2), 
(3, 103, 2), 
(3, 102, 2), 
(3, 110, 2), 
(3, 101, 2), 
(17, 104, 1), 
(17, 113, 1), 
(17, 112, 1), 
(17, 103, 1), 
(17, 102, 1), 
(17, 110, 1), 
(17, 101, 1), 
(4, 104, 1), 
(4, 113, 1), 
(4, 112, 1), 
(4, 103, 1), 
(4, 102, 1), 
(4, 110, 1), 
(4, 101, 1), 
(5, 104, 2), 
(5, 113, 2), 
(5, 112, 2), 
(5, 103, 2), 
(5, 102, 2), 
(5, 110, 2), 
(5, 101, 2), 
(6, 104, 3), 
(6, 113, 3), 
(6, 112, 3), 
(6, 103, 3), 
(6, 102, 3), 
(6, 110, 3), 
(6, 101, 3), 
(20, 104, 1), 
(20, 113, 1), 
(20, 112, 1), 
(20, 103, 1), 
(20, 102, 1), 
(20, 110, 1), 
(20, 101, 1), 
(18, 104, 1), 
(18, 113, 1), 
(18, 112, 1), 
(18, 103, 1), 
(18, 102, 1), 
(18, 110, 1), 
(18, 101, 1), 
(16, 104, 1), 
(16, 113, 1), 
(16, 112, 1), 
(16, 103, 1), 
(16, 102, 1), 
(16, 110, 1), 
(16, 101, 1), 
(10, 104, 1), 
(10, 113, 1), 
(10, 112, 1), 
(10, 103, 1), 
(10, 102, 1), 
(10, 110, 1), 
(10, 101, 1), 
(11, 104, 2), 
(11, 113, 2), 
(11, 112, 2), 
(11, 103, 2), 
(11, 102, 2), 
(11, 110, 2), 
(11, 101, 2), 
(12, 104, 3), 
(12, 113, 3), 
(12, 112, 3), 
(12, 103, 3), 
(12, 102, 3), 
(12, 110, 3), 
(12, 101, 3), 
(13, 104, 4), 
(13, 113, 4), 
(13, 112, 4), 
(13, 103, 4), 
(13, 102, 4), 
(13, 110, 4), 
(13, 101, 4), 
(15, 104, 1), 
(15, 113, 1), 
(15, 112, 1), 
(15, 103, 1), 
(15, 102, 1), 
(15, 110, 1), 
(15, 101, 1), 
(27, 104, 2), 
(27, 113, 2), 
(27, 112, 2), 
(27, 103, 2), 
(27, 102, 2), 
(27, 110, 2), 
(27, 101, 2), 
(23, 104, 1), 
(23, 113, 1), 
(23, 112, 1), 
(23, 103, 1), 
(23, 102, 1), 
(23, 110, 1), 
(23, 101, 1), 
(21, 104, 1), 
(21, 113, 1), 
(21, 112, 1), 
(21, 103, 1), 
(21, 102, 1), 
(21, 110, 1), 
(21, 101, 1), 
(25, 104, 2), 
(25, 113, 2), 
(25, 112, 2), 
(25, 103, 2), 
(25, 102, 2), 
(25, 110, 2), 
(25, 101, 2), 
(26, 104, 3), 
(26, 113, 3), 
(26, 112, 3), 
(26, 103, 3), 
(26, 102, 3), 
(26, 110, 3), 
(26, 101, 3), 
(29, 110, 3), 
(29, 101, 3);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_contact_rows`
--

DROP TABLE IF EXISTS `nv3_vi_contact_rows`;
CREATE TABLE `nv3_vi_contact_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `note` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_contact_rows`
--

INSERT INTO `nv3_vi_contact_rows` VALUES
(1, 'Webmaster', '', '', '', '', '1/1/1/0;', 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_contact_send`
--

DROP TABLE IF EXISTS `nv3_vi_contact_send`;
CREATE TABLE `nv3_vi_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `send_time` int(11) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100) NOT NULL,
  `sender_email` varchar(100) NOT NULL,
  `sender_phone` varchar(255) NOT NULL,
  `sender_ip` varchar(15) NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `reply_content` mediumtext NOT NULL,
  `reply_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_counter`
--

DROP TABLE IF EXISTS `nv3_vi_counter`;
CREATE TABLE `nv3_vi_counter` (
  `c_type` varchar(100) NOT NULL,
  `c_val` varchar(100) NOT NULL,
  `c_count` int(11) unsigned NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_counter`
--

INSERT INTO `nv3_vi_counter` VALUES
('c_time', 'start', 0, 0), 
('c_time', 'last', 1351394062, 0), 
('total', 'hits', 5, 1351394062), 
('year', '2009', 0, 0), 
('year', '2010', 0, 0), 
('year', '2011', 0, 0), 
('year', '2012', 5, 1351394062), 
('year', '2013', 0, 0), 
('year', '2014', 0, 0), 
('year', '2015', 0, 0), 
('year', '2016', 0, 0), 
('year', '2017', 0, 0), 
('year', '2018', 0, 0), 
('year', '2019', 0, 0), 
('year', '2020', 0, 0), 
('month', 'Jan', 0, 0), 
('month', 'Feb', 0, 0), 
('month', 'Mar', 0, 0), 
('month', 'Apr', 0, 0), 
('month', 'May', 0, 0), 
('month', 'Jun', 0, 0), 
('month', 'Jul', 0, 0), 
('month', 'Aug', 0, 0), 
('month', 'Sep', 0, 0), 
('month', 'Oct', 5, 1351394062), 
('month', 'Nov', 0, 0), 
('month', 'Dec', 0, 0), 
('day', '01', 0, 0), 
('day', '02', 0, 0), 
('day', '03', 0, 0), 
('day', '04', 0, 0), 
('day', '05', 0, 0), 
('day', '06', 0, 0), 
('day', '07', 0, 0), 
('day', '08', 0, 0), 
('day', '09', 0, 0), 
('day', '10', 0, 0), 
('day', '11', 0, 0), 
('day', '12', 0, 0), 
('day', '13', 0, 0), 
('day', '14', 0, 0), 
('day', '15', 0, 0), 
('day', '16', 0, 0), 
('day', '17', 0, 0), 
('day', '18', 0, 0), 
('day', '19', 0, 0), 
('day', '20', 0, 0), 
('day', '21', 0, 0), 
('day', '22', 0, 0), 
('day', '23', 0, 0), 
('day', '24', 0, 0), 
('day', '25', 0, 0), 
('day', '26', 2, 1351257664), 
('day', '27', 2, 1351328441), 
('day', '28', 1, 1351394062), 
('day', '29', 0, 0), 
('day', '30', 0, 0), 
('day', '31', 0, 0), 
('dayofweek', 'Sunday', 1, 1351394062), 
('dayofweek', 'Monday', 0, 0), 
('dayofweek', 'Tuesday', 0, 0), 
('dayofweek', 'Wednesday', 0, 0), 
('dayofweek', 'Thursday', 0, 0), 
('dayofweek', 'Friday', 2, 1351257664), 
('dayofweek', 'Saturday', 2, 1351328441), 
('hour', '00', 0, 0), 
('hour', '01', 0, 0), 
('hour', '02', 0, 0), 
('hour', '03', 0, 0), 
('hour', '04', 0, 0), 
('hour', '05', 0, 0), 
('hour', '06', 0, 0), 
('hour', '07', 0, 0), 
('hour', '08', 0, 0), 
('hour', '09', 0, 1351304564), 
('hour', '10', 1, 1351394062), 
('hour', '11', 0, 0), 
('hour', '12', 0, 0), 
('hour', '13', 0, 0), 
('hour', '14', 0, 0), 
('hour', '15', 0, 0), 
('hour', '16', 0, 1351328441), 
('hour', '17', 0, 0), 
('hour', '18', 0, 1351249732), 
('hour', '19', 0, 0), 
('hour', '20', 0, 1351257664), 
('hour', '21', 0, 0), 
('hour', '22', 0, 0), 
('hour', '23', 0, 0), 
('bot', 'Alexa', 0, 0), 
('bot', 'AltaVista Scooter', 0, 0), 
('bot', 'Altavista Mercator', 0, 0), 
('bot', 'Altavista Search', 0, 0), 
('bot', 'Aport.ru Bot', 0, 0), 
('bot', 'Ask Jeeves', 0, 0), 
('bot', 'Baidu', 0, 0), 
('bot', 'Exabot', 0, 0), 
('bot', 'FAST Enterprise', 0, 0), 
('bot', 'FAST WebCrawler', 0, 0), 
('bot', 'Francis', 0, 0), 
('bot', 'Gigablast', 0, 0), 
('bot', 'Google AdsBot', 0, 0), 
('bot', 'Google Adsense', 0, 0), 
('bot', 'Google Bot', 0, 0), 
('bot', 'Google Desktop', 0, 0), 
('bot', 'Google Feedfetcher', 0, 0), 
('bot', 'Heise IT-Markt', 0, 0), 
('bot', 'Heritrix', 0, 0), 
('bot', 'IBM Research', 0, 0), 
('bot', 'ICCrawler - ICjobs', 0, 0), 
('bot', 'Ichiro', 0, 0), 
('bot', 'InfoSeek Spider', 0, 0), 
('bot', 'Lycos.com Bot', 0, 0), 
('bot', 'MSN Bot', 0, 0), 
('bot', 'MSN Bot Media', 0, 0), 
('bot', 'MSN Bot News', 0, 0), 
('bot', 'MSN NewsBlogs', 0, 0), 
('bot', 'Majestic-12', 0, 0), 
('bot', 'Metager', 0, 0), 
('bot', 'NG-Search', 0, 0), 
('bot', 'Nutch Bot', 0, 0), 
('bot', 'NutchCVS', 0, 0), 
('bot', 'OmniExplorer', 0, 0), 
('bot', 'Online Link Validator', 0, 0), 
('bot', 'Open-source Web Search', 0, 0), 
('bot', 'Psbot', 0, 0), 
('bot', 'Rambler', 0, 0), 
('bot', 'SEO Crawler', 0, 0), 
('bot', 'SEOSearch', 0, 0), 
('bot', 'Seekport', 0, 0), 
('bot', 'Sensis', 0, 0), 
('bot', 'Seoma', 0, 0), 
('bot', 'Snappy', 0, 0), 
('bot', 'Steeler', 0, 0), 
('bot', 'Synoo', 0, 0), 
('bot', 'Telekom', 0, 0), 
('bot', 'TurnitinBot', 0, 0), 
('bot', 'Vietnamese Search', 0, 0), 
('bot', 'Voyager', 0, 0), 
('bot', 'W3 Sitesearch', 0, 0), 
('bot', 'W3C Linkcheck', 0, 0), 
('bot', 'W3C Validator', 0, 0), 
('bot', 'WiseNut', 0, 0), 
('bot', 'YaCy', 0, 0), 
('bot', 'Yahoo Bot', 0, 0), 
('bot', 'Yahoo MMCrawler', 0, 0), 
('bot', 'Yahoo Slurp', 0, 0), 
('bot', 'YahooSeeker', 0, 0), 
('bot', 'Yandex', 0, 0), 
('bot', 'Yandex Blog', 0, 0), 
('bot', 'Yandex Direct Bot', 0, 0), 
('bot', 'Yandex Something', 0, 0), 
('browser', 'netcaptor', 0, 0), 
('browser', 'opera', 0, 0), 
('browser', 'aol', 0, 0), 
('browser', 'aol2', 0, 0), 
('browser', 'mosaic', 0, 0), 
('browser', 'k-meleon', 0, 0), 
('browser', 'konqueror', 0, 0), 
('browser', 'avantbrowser', 0, 0), 
('browser', 'avantgo', 0, 0), 
('browser', 'proxomitron', 0, 0), 
('browser', 'chrome', 0, 0), 
('browser', 'safari', 0, 0), 
('browser', 'lynx', 0, 0), 
('browser', 'links', 0, 0), 
('browser', 'galeon', 0, 0), 
('browser', 'abrowse', 0, 0), 
('browser', 'amaya', 0, 0), 
('browser', 'ant', 0, 0), 
('browser', 'aweb', 0, 0), 
('browser', 'beonex', 0, 0), 
('browser', 'blazer', 0, 0), 
('browser', 'camino', 0, 0), 
('browser', 'chimera', 0, 0), 
('browser', 'columbus', 0, 0), 
('browser', 'crazybrowser', 0, 0), 
('browser', 'curl', 0, 0), 
('browser', 'deepnet', 0, 0), 
('browser', 'dillo', 0, 0), 
('browser', 'doris', 0, 0), 
('browser', 'elinks', 0, 0), 
('browser', 'epiphany', 0, 0), 
('browser', 'ibrowse', 0, 0), 
('browser', 'icab', 0, 0), 
('browser', 'ice', 0, 0), 
('browser', 'isilox', 0, 0), 
('browser', 'lotus', 0, 0), 
('browser', 'lunascape', 0, 0), 
('browser', 'maxthon', 0, 0), 
('browser', 'mbrowser', 0, 0), 
('browser', 'multibrowser', 0, 0), 
('browser', 'nautilus', 0, 0), 
('browser', 'netfront', 0, 0), 
('browser', 'netpositive', 0, 0), 
('browser', 'omniweb', 0, 0), 
('browser', 'oregano', 0, 0), 
('browser', 'phaseout', 0, 0), 
('browser', 'plink', 0, 0), 
('browser', 'phoenix', 0, 0), 
('browser', 'shiira', 0, 0), 
('browser', 'sleipnir', 0, 0), 
('browser', 'slimbrowser', 0, 0), 
('browser', 'staroffice', 0, 0), 
('browser', 'sunrise', 0, 0), 
('browser', 'voyager', 0, 0), 
('browser', 'w3m', 0, 0), 
('browser', 'webtv', 0, 0), 
('browser', 'xiino', 0, 0), 
('browser', 'explorer', 0, 0), 
('browser', 'firefox', 5, 1351394062), 
('browser', 'netscape', 0, 0), 
('browser', 'netscape2', 0, 0), 
('browser', 'mozilla', 0, 0), 
('browser', 'mozilla2', 0, 0), 
('browser', 'firebird', 0, 0), 
('browser', 'Mobile', 0, 0), 
('browser', 'Unknown', 0, 0), 
('os', 'windows7', 5, 1351394062), 
('os', 'windowsvista', 0, 0), 
('os', 'windows2003', 0, 0), 
('os', 'windowsxp', 0, 0), 
('os', 'windowsxp2', 0, 0), 
('os', 'windows2k', 0, 0), 
('os', 'windows95', 0, 0), 
('os', 'windowsce', 0, 0), 
('os', 'windowsme', 0, 0), 
('os', 'windowsme2', 0, 0), 
('os', 'windowsnt', 0, 0), 
('os', 'windowsnt2', 0, 0), 
('os', 'windows98', 0, 0), 
('os', 'windows', 0, 0), 
('os', 'linux', 0, 0), 
('os', 'linux2', 0, 0), 
('os', 'linux3', 0, 0), 
('os', 'macosx', 0, 0), 
('os', 'macppc', 0, 0), 
('os', 'mac', 0, 0), 
('os', 'amiga', 0, 0), 
('os', 'beos', 0, 0), 
('os', 'freebsd', 0, 0), 
('os', 'freebsd2', 0, 0), 
('os', 'irix', 0, 0), 
('os', 'netbsd', 0, 0), 
('os', 'netbsd2', 0, 0), 
('os', 'os2', 0, 0), 
('os', 'os22', 0, 0), 
('os', 'openbsd', 0, 0), 
('os', 'openbsd2', 0, 0), 
('os', 'palm', 0, 0), 
('os', 'palm2', 0, 0), 
('os', 'Unspecified', 0, 0), 
('country', 'AD', 0, 0), 
('country', 'AE', 0, 0), 
('country', 'AF', 0, 0), 
('country', 'AG', 0, 0), 
('country', 'AI', 0, 0), 
('country', 'AL', 0, 0), 
('country', 'AM', 0, 0), 
('country', 'AN', 0, 0), 
('country', 'AO', 0, 0), 
('country', 'AQ', 0, 0), 
('country', 'AR', 0, 0), 
('country', 'AS', 0, 0), 
('country', 'AT', 0, 0), 
('country', 'AU', 0, 0), 
('country', 'AW', 0, 0), 
('country', 'AZ', 0, 0), 
('country', 'BA', 0, 0), 
('country', 'BB', 0, 0), 
('country', 'BD', 0, 0), 
('country', 'BE', 0, 0), 
('country', 'BF', 0, 0), 
('country', 'BG', 0, 0), 
('country', 'BH', 0, 0), 
('country', 'BI', 0, 0), 
('country', 'BJ', 0, 0), 
('country', 'BM', 0, 0), 
('country', 'BN', 0, 0), 
('country', 'BO', 0, 0), 
('country', 'BR', 0, 0), 
('country', 'BS', 0, 0), 
('country', 'BT', 0, 0), 
('country', 'BW', 0, 0), 
('country', 'BY', 0, 0), 
('country', 'BZ', 0, 0), 
('country', 'CA', 0, 0), 
('country', 'CD', 0, 0), 
('country', 'CF', 0, 0), 
('country', 'CG', 0, 0), 
('country', 'CH', 0, 0), 
('country', 'CI', 0, 0), 
('country', 'CK', 0, 0), 
('country', 'CL', 0, 0), 
('country', 'CM', 0, 0), 
('country', 'CN', 0, 0), 
('country', 'CO', 0, 0), 
('country', 'CR', 0, 0), 
('country', 'CS', 0, 0), 
('country', 'CU', 0, 0), 
('country', 'CV', 0, 0), 
('country', 'CY', 0, 0), 
('country', 'CZ', 0, 0), 
('country', 'DE', 0, 0), 
('country', 'DJ', 0, 0), 
('country', 'DK', 0, 0), 
('country', 'DM', 0, 0), 
('country', 'DO', 0, 0), 
('country', 'DZ', 0, 0), 
('country', 'EC', 0, 0), 
('country', 'EE', 0, 0), 
('country', 'EG', 0, 0), 
('country', 'ER', 0, 0), 
('country', 'ES', 0, 0), 
('country', 'ET', 0, 0), 
('country', 'EU', 0, 0), 
('country', 'FI', 0, 0), 
('country', 'FJ', 0, 0), 
('country', 'FK', 0, 0), 
('country', 'FM', 0, 0), 
('country', 'FO', 0, 0), 
('country', 'FR', 0, 0), 
('country', 'GA', 0, 0), 
('country', 'GB', 0, 0), 
('country', 'GD', 0, 0), 
('country', 'GE', 0, 0), 
('country', 'GF', 0, 0), 
('country', 'GH', 0, 0), 
('country', 'GI', 0, 0), 
('country', 'GL', 0, 0), 
('country', 'GM', 0, 0), 
('country', 'GN', 0, 0), 
('country', 'GP', 0, 0), 
('country', 'GQ', 0, 0), 
('country', 'GR', 0, 0), 
('country', 'GS', 0, 0), 
('country', 'GT', 0, 0), 
('country', 'GU', 0, 0), 
('country', 'GW', 0, 0), 
('country', 'GY', 0, 0), 
('country', 'HK', 0, 0), 
('country', 'HN', 0, 0), 
('country', 'HR', 0, 0), 
('country', 'HT', 0, 0), 
('country', 'HU', 0, 0), 
('country', 'ID', 0, 0), 
('country', 'IE', 0, 0), 
('country', 'IL', 0, 0), 
('country', 'IN', 0, 0), 
('country', 'IO', 0, 0), 
('country', 'IQ', 0, 0), 
('country', 'IR', 0, 0), 
('country', 'IS', 0, 0), 
('country', 'IT', 0, 0), 
('country', 'JM', 0, 0), 
('country', 'JO', 0, 0), 
('country', 'JP', 0, 0), 
('country', 'KE', 0, 0), 
('country', 'KG', 0, 0), 
('country', 'KH', 0, 0), 
('country', 'KI', 0, 0), 
('country', 'KM', 0, 0), 
('country', 'KN', 0, 0), 
('country', 'KR', 0, 0), 
('country', 'KW', 0, 0), 
('country', 'KY', 0, 0), 
('country', 'KZ', 0, 0), 
('country', 'LA', 0, 0), 
('country', 'LB', 0, 0), 
('country', 'LC', 0, 0), 
('country', 'LI', 0, 0), 
('country', 'LK', 0, 0), 
('country', 'LR', 0, 0), 
('country', 'LS', 0, 0), 
('country', 'LT', 0, 0), 
('country', 'LU', 0, 0), 
('country', 'LV', 0, 0), 
('country', 'LY', 0, 0), 
('country', 'MA', 0, 0), 
('country', 'MC', 0, 0), 
('country', 'MD', 0, 0), 
('country', 'MG', 0, 0), 
('country', 'MH', 0, 0), 
('country', 'MK', 0, 0), 
('country', 'ML', 0, 0), 
('country', 'MM', 0, 0), 
('country', 'MN', 0, 0), 
('country', 'MO', 0, 0), 
('country', 'MP', 0, 0), 
('country', 'MQ', 0, 0), 
('country', 'MR', 0, 0), 
('country', 'MT', 0, 0), 
('country', 'MU', 0, 0), 
('country', 'MV', 0, 0), 
('country', 'MW', 0, 0), 
('country', 'MX', 0, 0), 
('country', 'MY', 0, 0), 
('country', 'MZ', 0, 0), 
('country', 'NA', 0, 0), 
('country', 'NC', 0, 0), 
('country', 'NE', 0, 0), 
('country', 'NF', 0, 0), 
('country', 'NG', 0, 0), 
('country', 'NI', 0, 0), 
('country', 'NL', 0, 0), 
('country', 'NO', 0, 0), 
('country', 'NP', 0, 0), 
('country', 'NR', 0, 0), 
('country', 'NU', 0, 0), 
('country', 'NZ', 0, 0), 
('country', 'OM', 0, 0), 
('country', 'PA', 0, 0), 
('country', 'PE', 0, 0), 
('country', 'PF', 0, 0), 
('country', 'PG', 0, 0), 
('country', 'PH', 0, 0), 
('country', 'PK', 0, 0), 
('country', 'PL', 0, 0), 
('country', 'PR', 0, 0), 
('country', 'PS', 0, 0), 
('country', 'PT', 0, 0), 
('country', 'PW', 0, 0), 
('country', 'PY', 0, 0), 
('country', 'QA', 0, 0), 
('country', 'RE', 0, 0), 
('country', 'RO', 0, 0), 
('country', 'RU', 0, 0), 
('country', 'RW', 0, 0), 
('country', 'SA', 0, 0), 
('country', 'SB', 0, 0), 
('country', 'SC', 0, 0), 
('country', 'SD', 0, 0), 
('country', 'SE', 0, 0), 
('country', 'SG', 0, 0), 
('country', 'SI', 0, 0), 
('country', 'SK', 0, 0), 
('country', 'SL', 0, 0), 
('country', 'SM', 0, 0), 
('country', 'SN', 0, 0), 
('country', 'SO', 0, 0), 
('country', 'SR', 0, 0), 
('country', 'ST', 0, 0), 
('country', 'SV', 0, 0), 
('country', 'SY', 0, 0), 
('country', 'SZ', 0, 0), 
('country', 'TD', 0, 0), 
('country', 'TF', 0, 0), 
('country', 'TG', 0, 0), 
('country', 'TH', 0, 0), 
('country', 'TJ', 0, 0), 
('country', 'TK', 0, 0), 
('country', 'TL', 0, 0), 
('country', 'TM', 0, 0), 
('country', 'TN', 0, 0), 
('country', 'TO', 0, 0), 
('country', 'TR', 0, 0), 
('country', 'TT', 0, 0), 
('country', 'TV', 0, 0), 
('country', 'TW', 0, 0), 
('country', 'TZ', 0, 0), 
('country', 'UA', 0, 0), 
('country', 'UG', 0, 0), 
('country', 'US', 0, 0), 
('country', 'UY', 0, 0), 
('country', 'UZ', 0, 0), 
('country', 'VA', 0, 0), 
('country', 'VC', 0, 0), 
('country', 'VE', 0, 0), 
('country', 'VG', 0, 0), 
('country', 'VI', 0, 0), 
('country', 'VN', 0, 0), 
('country', 'VU', 0, 0), 
('country', 'WS', 0, 0), 
('country', 'YE', 0, 0), 
('country', 'YT', 0, 0), 
('country', 'YU', 0, 0), 
('country', 'ZA', 0, 0), 
('country', 'ZM', 0, 0), 
('country', 'ZW', 0, 0), 
('country', 'ZZ', 5, 1351394062), 
('country', 'unkown', 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_menu_menu`
--

DROP TABLE IF EXISTS `nv3_vi_menu_menu`;
CREATE TABLE `nv3_vi_menu_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `menu_item` mediumtext NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_menu_rows`
--

DROP TABLE IF EXISTS `nv3_vi_menu_rows`;
CREATE TABLE `nv3_vi_menu_rows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` int(11) unsigned NOT NULL,
  `mid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  `weight` int(11) NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` mediumtext NOT NULL,
  `who_view` tinyint(2) NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL,
  `module_name` varchar(255) NOT NULL DEFAULT '',
  `op` varchar(255) NOT NULL DEFAULT '',
  `target` tinyint(4) NOT NULL DEFAULT '0',
  `css` varchar(255) NOT NULL DEFAULT '',
  `active_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_modfuncs`
--

DROP TABLE IF EXISTS `nv3_vi_modfuncs`;
CREATE TABLE `nv3_vi_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55) NOT NULL,
  `func_custom_name` varchar(255) NOT NULL,
  `in_module` varchar(55) NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(2) unsigned NOT NULL DEFAULT '1',
  `setting` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`)
) ENGINE=MyISAM  AUTO_INCREMENT=114  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_modfuncs`
--

INSERT INTO `nv3_vi_modfuncs` VALUES
(1, 'Sitemap', 'Sitemap', 'about', 0, 0, 0, ''), 
(2, 'main', 'Main', 'about', 1, 0, 1, ''), 
(3, 'Sitemap', 'Sitemap', 'news', 0, 0, 0, ''), 
(4, 'comment', 'Comment', 'news', 0, 0, 0, ''), 
(5, 'content', 'Content', 'news', 1, 0, 1, ''), 
(6, 'detail', 'Detail', 'news', 1, 0, 2, ''), 
(7, 'main', 'Main', 'news', 1, 0, 3, ''), 
(8, 'postcomment', 'Postcomment', 'news', 0, 0, 0, ''), 
(9, 'print', 'Print', 'news', 0, 0, 0, ''), 
(10, 'rating', 'Rating', 'news', 0, 0, 0, ''), 
(11, 'rss', 'Rss', 'news', 0, 0, 0, ''), 
(12, 'savefile', 'Savefile', 'news', 0, 0, 0, ''), 
(13, 'search', 'Search', 'news', 1, 0, 4, ''), 
(14, 'sendmail', 'Sendmail', 'news', 0, 0, 0, ''), 
(15, 'topic', 'Topic', 'news', 1, 0, 5, ''), 
(16, 'viewcat', 'Viewcat', 'news', 1, 0, 6, ''), 
(17, 'active', 'Active', 'users', 1, 0, 8, ''), 
(18, 'changepass', 'Đổi mật khẩu', 'users', 1, 1, 6, ''), 
(19, 'editinfo', 'Editinfo', 'users', 1, 0, 10, ''), 
(20, 'login', 'Đăng nhập', 'users', 1, 1, 2, ''), 
(21, 'logout', 'Logout', 'users', 1, 1, 3, ''), 
(22, 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 9, ''), 
(23, 'lostpass', 'Quên mật khẩu', 'users', 1, 1, 5, ''), 
(24, 'main', 'Main', 'users', 1, 1, 1, ''), 
(25, 'openid', 'Openid', 'users', 1, 1, 7, ''), 
(26, 'register', 'Đăng ký', 'users', 1, 1, 4, ''), 
(27, 'main', 'Main', 'contact', 1, 0, 1, ''), 
(28, 'allbots', 'Máy chủ tìm kiếm', 'statistics', 1, 1, 6, ''), 
(29, 'allbrowsers', 'Theo trình duyệt', 'statistics', 1, 1, 4, ''), 
(30, 'allcountries', 'Theo quốc gia', 'statistics', 1, 1, 3, ''), 
(31, 'allos', 'Theo hệ điều hành', 'statistics', 1, 1, 5, ''), 
(32, 'allreferers', 'Theo đường dẫn đến site', 'statistics', 1, 1, 2, ''), 
(33, 'main', 'Main', 'statistics', 1, 0, 1, ''), 
(34, 'referer', 'Đường dẫn đến site theo tháng', 'statistics', 1, 0, 7, ''), 
(35, 'main', 'Main', 'voting', 1, 0, 0, ''), 
(36, 'addads', 'Addads', 'banners', 1, 0, 1, ''), 
(37, 'cledit', 'Cledit', 'banners', 0, 0, 0, ''), 
(38, 'click', 'Click', 'banners', 0, 0, 0, ''), 
(39, 'clientinfo', 'Clientinfo', 'banners', 1, 0, 2, ''), 
(40, 'clinfo', 'Clinfo', 'banners', 0, 0, 0, ''), 
(41, 'logininfo', 'Logininfo', 'banners', 0, 0, 0, ''), 
(42, 'main', 'Main', 'banners', 1, 0, 3, ''), 
(43, 'stats', 'Stats', 'banners', 1, 0, 4, ''), 
(44, 'viewmap', 'Viewmap', 'banners', 0, 0, 0, ''), 
(45, 'adv', 'Adv', 'search', 0, 0, 0, ''), 
(46, 'main', 'Main', 'search', 1, 0, 1, ''), 
(47, 'main', 'Main', 'rss', 1, 0, 1, ''), 
(48, 'regroups', 'Nhóm thành viên', 'users', 1, 0, 1, ''), 
(50, 'groups', 'Groups', 'news', 1, 0, 7, ''), 
(113, 'viewcat', 'Viewcat', 'thu-vien-van-ban', 1, 0, 2, ''), 
(112, 'topic', 'Topic', 'thu-vien-van-ban', 1, 0, 3, ''), 
(111, 'sendmail', 'Sendmail', 'thu-vien-van-ban', 0, 0, 0, ''), 
(110, 'search', 'Search', 'thu-vien-van-ban', 1, 0, 6, ''), 
(108, 'rss', 'Rss', 'thu-vien-van-ban', 0, 0, 0, ''), 
(107, 'rating', 'Rating', 'thu-vien-van-ban', 0, 0, 0, ''), 
(106, 'print', 'Print', 'thu-vien-van-ban', 0, 0, 0, ''), 
(105, 'postcomment', 'Postcomment', 'thu-vien-van-ban', 0, 0, 0, ''), 
(104, 'main', 'Main', 'thu-vien-van-ban', 1, 0, 1, ''), 
(103, 'groups', 'Groups', 'thu-vien-van-ban', 1, 0, 4, ''), 
(102, 'detail', 'Detail', 'thu-vien-van-ban', 1, 0, 5, ''), 
(101, 'content', 'Content', 'thu-vien-van-ban', 1, 0, 7, ''), 
(100, 'comment', 'Comment', 'thu-vien-van-ban', 0, 0, 0, ''), 
(99, 'Sitemap', 'Sitemap', 'thu-vien-van-ban', 0, 0, 0, ''), 
(109, 'savefile', 'Savefile', 'thu-vien-van-ban', 0, 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_modthemes`
--

DROP TABLE IF EXISTS `nv3_vi_modthemes`;
CREATE TABLE `nv3_vi_modthemes` (
  `func_id` int(11) DEFAULT NULL,
  `layout` varchar(100) DEFAULT NULL,
  `theme` varchar(100) DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_modthemes`
--

INSERT INTO `nv3_vi_modthemes` VALUES
(0, 'body', 'mobile_nukeviet'), 
(0, 'body-right', 'modern'), 
(0, 'left-body-right', 'default'), 
(0, 'left-body-right', 'phapluat2'), 
(2, 'body', 'mobile_nukeviet'), 
(2, 'body', 'modern'), 
(2, 'left-body-right', 'default'), 
(2, 'left-body-right', 'phapluat2'), 
(5, 'body', 'mobile_nukeviet'), 
(5, 'body-right', 'modern'), 
(5, 'left-body-right', 'default'), 
(5, 'left-body-right', 'phapluat2'), 
(6, 'body', 'mobile_nukeviet'), 
(6, 'body-right', 'modern'), 
(6, 'left-body-right', 'default'), 
(6, 'left-body-right', 'phapluat2'), 
(7, 'body', 'mobile_nukeviet'), 
(7, 'body-right', 'modern'), 
(7, 'left-body-right', 'default'), 
(7, 'left-body-right', 'phapluat2'), 
(13, 'body', 'mobile_nukeviet'), 
(13, 'body-right', 'modern'), 
(13, 'left-body-right', 'default'), 
(13, 'left-body-right', 'phapluat2'), 
(15, 'body', 'mobile_nukeviet'), 
(15, 'body-right', 'modern'), 
(15, 'left-body-right', 'default'), 
(15, 'left-body-right', 'phapluat2'), 
(16, 'body', 'mobile_nukeviet'), 
(16, 'body-right', 'modern'), 
(16, 'left-body-right', 'default'), 
(16, 'left-body-right', 'phapluat2'), 
(17, 'body', 'mobile_nukeviet'), 
(17, 'body-right', 'modern'), 
(17, 'left-body-right', 'default'), 
(17, 'left-body-right', 'phapluat2'), 
(18, 'body', 'mobile_nukeviet'), 
(18, 'body-right', 'modern'), 
(18, 'left-body-right', 'default'), 
(18, 'left-body-right', 'phapluat2'), 
(19, 'body', 'mobile_nukeviet'), 
(19, 'body-right', 'modern'), 
(19, 'left-body-right', 'default'), 
(19, 'left-body-right', 'phapluat2'), 
(20, 'body', 'mobile_nukeviet'), 
(20, 'body-right', 'modern'), 
(20, 'left-body-right', 'default'), 
(20, 'left-body-right', 'phapluat2'), 
(21, 'body', 'mobile_nukeviet'), 
(21, 'body-right', 'modern'), 
(21, 'left-body-right', 'default'), 
(21, 'left-body-right', 'phapluat2'), 
(22, 'body', 'mobile_nukeviet'), 
(22, 'body-right', 'modern'), 
(22, 'left-body-right', 'default'), 
(22, 'left-body-right', 'phapluat2'), 
(23, 'body', 'mobile_nukeviet'), 
(23, 'body-right', 'modern'), 
(23, 'left-body-right', 'default'), 
(23, 'left-body-right', 'phapluat2'), 
(24, 'body', 'mobile_nukeviet'), 
(24, 'body-right', 'modern'), 
(24, 'left-body-right', 'default'), 
(24, 'left-body-right', 'phapluat2'), 
(25, 'body', 'mobile_nukeviet'), 
(25, 'body-right', 'modern'), 
(25, 'left-body-right', 'default'), 
(25, 'left-body-right', 'phapluat2'), 
(26, 'body', 'mobile_nukeviet'), 
(26, 'body-right', 'modern'), 
(26, 'left-body-right', 'default'), 
(26, 'left-body-right', 'phapluat2'), 
(27, 'body', 'mobile_nukeviet'), 
(27, 'body-right', 'modern'), 
(27, 'left-body-right', 'default'), 
(27, 'left-body-right', 'phapluat2'), 
(28, 'body', 'mobile_nukeviet'), 
(28, 'body', 'modern'), 
(28, 'left-body', 'default'), 
(28, 'left-body', 'phapluat2'), 
(29, 'body', 'mobile_nukeviet'), 
(29, 'body', 'modern'), 
(29, 'left-body', 'default'), 
(29, 'left-body', 'phapluat2'), 
(30, 'body', 'mobile_nukeviet'), 
(30, 'body', 'modern'), 
(30, 'left-body', 'default'), 
(30, 'left-body', 'phapluat2'), 
(31, 'body', 'mobile_nukeviet'), 
(31, 'body', 'modern'), 
(31, 'left-body', 'default'), 
(31, 'left-body', 'phapluat2'), 
(32, 'body', 'mobile_nukeviet'), 
(32, 'body', 'modern'), 
(32, 'left-body', 'default'), 
(32, 'left-body', 'phapluat2'), 
(33, 'body', 'mobile_nukeviet'), 
(33, 'body', 'modern'), 
(33, 'left-body', 'default'), 
(33, 'left-body', 'phapluat2'), 
(34, 'body', 'mobile_nukeviet'), 
(34, 'body', 'modern'), 
(34, 'left-body', 'default'), 
(34, 'left-body', 'phapluat2'), 
(35, 'body', 'mobile_nukeviet'), 
(35, 'body-right', 'modern'), 
(35, 'left-body-right', 'default'), 
(35, 'left-body-right', 'phapluat2'), 
(36, 'body', 'mobile_nukeviet'), 
(36, 'body-right', 'modern'), 
(36, 'left-body-right', 'default'), 
(36, 'left-body-right', 'phapluat2'), 
(39, 'body', 'mobile_nukeviet'), 
(39, 'body-right', 'modern'), 
(39, 'left-body-right', 'default'), 
(39, 'left-body-right', 'phapluat2'), 
(42, 'body', 'mobile_nukeviet'), 
(42, 'body-right', 'modern'), 
(42, 'left-body-right', 'default'), 
(42, 'left-body-right', 'phapluat2'), 
(43, 'body', 'mobile_nukeviet'), 
(43, 'body-right', 'modern'), 
(43, 'left-body-right', 'default'), 
(43, 'left-body-right', 'phapluat2'), 
(46, 'body', 'mobile_nukeviet'), 
(46, 'body-right', 'modern'), 
(46, 'left-body-right', 'default'), 
(46, 'left-body-right', 'phapluat2'), 
(47, 'body', 'mobile_nukeviet'), 
(47, 'body', 'modern'), 
(47, 'left-body-right', 'default'), 
(47, 'left-body-right', 'phapluat2'), 
(48, 'body', 'mobile_nukeviet'), 
(48, 'body-right', 'modern'), 
(48, 'left-body-right', 'default'), 
(48, 'left-body-right', 'phapluat2'), 
(50, 'body', 'mobile_nukeviet'), 
(50, 'body-right', 'modern'), 
(50, 'left-body-right', 'default'), 
(50, 'left-body-right', 'phapluat2'), 
(101, 'body', 'mobile_nukeviet'), 
(101, 'body-right', 'modern'), 
(101, 'left-body-right', 'default'), 
(101, 'left-body-right', 'phapluat2'), 
(102, 'body', 'mobile_nukeviet'), 
(102, 'body-right', 'modern'), 
(102, 'left-body-right', 'default'), 
(102, 'left-body-right', 'phapluat2'), 
(103, 'body', 'mobile_nukeviet'), 
(103, 'body-right', 'modern'), 
(103, 'left-body-right', 'default'), 
(103, 'left-body-right', 'phapluat2'), 
(104, 'body', 'mobile_nukeviet'), 
(104, 'body-right', 'modern'), 
(104, 'left-body-right', 'default'), 
(104, 'left-body-right', 'phapluat2'), 
(110, 'body', 'mobile_nukeviet'), 
(110, 'body-right', 'modern'), 
(110, 'left-body-right', 'default'), 
(110, 'left-body-right', 'phapluat2'), 
(112, 'body', 'mobile_nukeviet'), 
(112, 'body-right', 'modern'), 
(112, 'left-body-right', 'default'), 
(112, 'left-body-right', 'phapluat2'), 
(113, 'body', 'mobile_nukeviet'), 
(113, 'body-right', 'modern'), 
(113, 'left-body-right', 'default'), 
(113, 'left-body-right', 'phapluat2');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_modules`
--

DROP TABLE IF EXISTS `nv3_vi_modules`;
CREATE TABLE `nv3_vi_modules` (
  `title` varchar(55) NOT NULL,
  `module_file` varchar(55) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `custom_title` varchar(255) NOT NULL,
  `admin_title` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  `main_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `keywords` mediumtext NOT NULL,
  `groups_view` varchar(255) NOT NULL,
  `in_menu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(255) NOT NULL,
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_modules`
--

INSERT INTO `nv3_vi_modules` VALUES
('about', 'about', 'about', 'Giới thiệu', '', 1276333182, 1, 1, '', 'mobile_nukeviet', '', '0', 1, 1, 1, 1, '', 0), 
('news', 'news', 'news', 'Lĩnh vực hoạt động', '', 1270400000, 1, 1, '', 'mobile_nukeviet', '', '0', 1, 2, 1, 1, '', 1), 
('users', 'users', 'users', 'Thành viên', 'Tài khoản', 1274080277, 1, 1, '', 'mobile_nukeviet', '', '0', 1, 4, 1, 1, '', 0), 
('contact', 'contact', 'contact', 'Liên hệ', '', 1275351337, 1, 1, '', 'mobile_nukeviet', '', '0', 1, 5, 1, 1, '', 0), 
('statistics', 'statistics', 'statistics', 'Thống kê', '', 1276520928, 1, 0, '', 'mobile_nukeviet', 'truy cập, online, statistics', '0', 1, 6, 1, 1, '', 0), 
('voting', 'voting', 'voting', 'Thăm dò ý kiến', '', 1275315261, 1, 1, '', 'mobile_nukeviet', '', '0', 0, 7, 1, 1, '', 1), 
('banners', 'banners', 'banners', 'Quảng cáo', '', 1270400000, 1, 1, '', 'mobile_nukeviet', '', '0', 0, 8, 1, 1, '', 0), 
('search', 'search', 'search', 'Tìm kiếm', '', 1273474173, 1, 0, '', 'mobile_nukeviet', '', '0', 0, 9, 1, 1, '', 0), 
('menu', 'menu', 'menu', 'Menu Site', '', 1295287334, 0, 1, '', 'mobile_nukeviet', '', '0', 0, 10, 1, 1, '', 0), 
('rss', 'rss', 'rss', 'Rss', '', 1279366705, 1, 1, '', 'mobile_nukeviet', '', '0', 0, 11, 10, 1, '', 0), 
('thu-vien-van-ban', 'news', 'thu_vien_van_ban', 'Thư viện văn bản', '', 1351407590, 1, 1, '', '', '', '0', 1, 3, 1, 1, '', 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_23`
--

DROP TABLE IF EXISTS `nv3_vi_news_23`;
CREATE TABLE `nv3_vi_news_23` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=17  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_23`
--

INSERT INTO `nv3_vi_news_23` VALUES
(11, 31, '23,31', 0, 1, '', 0, 1351408478, 1351421539, 1, 1351408478, 0, 2, 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Nhung-van-de-can-luu-y-khi-thuc-hien-thu-tuc-dang-ky-kinh-doanh', 'BRANDCO - Để giúp các bạn khởi sự kinh doanh nhanh chóng và thuận lợi. Brandco xin cung cấp cho quý khách hàng một số vấn đề cần lưu ý khi thực hiện thủ tục đăng ký doanh nghiệp theo Luật Doanh nghiệp năm 2005.', 'nangly.jpg', '', 'thumb/nangly.jpg|block/nangly.jpg', 1, 2, 1, 1, 0, 5, 1, 'khởi sự,kinh doanh,nhanh chóng,thuận lợi,quý khách,vấn đề,lưu ý,thực hiện,thủ tục,đăng ký,doanh nghiệp'), 
(14, 32, '23,32', 0, 1, '', 0, 1351421497, 1351421554, 1, 1351421497, 0, 2, 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 'Cong-ty-luat-Brandco-Xin-giay-phep-dau-tu', 'BRANDCO - Công ty Luật Brandco  tự hào là công ty hàng đầu trong lĩnh vực tư vấn đầu tư và cung cấp các dịch vụ hỗ trợ các nhà đầu tư tại việt nam như: tư vấn thành lập doanh nghiệp liên doanh, công ty 100% vốn nước ngoài, tư vấn lập dự án đầu tư (dự án tiền khả thi và dự án khả thi), tư vấn thủ tục xin ưu đãi đầu tư....', '2012_10/dau-tu.jpg', '', 'thumb/dau-tu.jpg|block/dau-tu.jpg', 1, 2, 1, 0, 0, 0, 0, 'công ty,tự hào,hàng đầu,lĩnh vực,tư vấn,hỗ trợ,thành lập,doanh nghiệp,liên doanh,dự án,khả thi,thủ tục'), 
(12, 31, '23,31', 0, 1, '', 0, 1351421031, 1351421613, 1, 1351421031, 0, 2, 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Cong-ty-luat-Brandco-Dich-vu-thanh-lap-doanh-nghiep', 'BRANDCO -  Là nhà tư vấn chuyên nghiệp trong lĩnh vực tư vấn đầu tư và tư vấn sở hữu trí tuệ, với nhiều năm kinh nghiệm phục vụ khách hàng, Công ty luật Brandco xin được giới thiệu tới rộng rãi các nhà đầu tư dịch vụ tư vấn thành lập doanh nghiệp do Công ty luật Brandco cung cấp.', '2012_10/dkkd.jpeg', '', 'thumb/dkkd.jpeg.jpg|block/dkkd.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'tư vấn,lĩnh vực,sở hữu,trí tuệ,kinh nghiệm,phục vụ,khách hàng,công ty,giới thiệu,rộng rãi,thành lập,doanh nghiệp'), 
(13, 31, '23,31', 0, 1, '', 0, 1351421252, 1351421641, 1, 1351421252, 0, 2, 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 'Cong-ty-luat-Brandco-Dac-diem-cua-cac-loai-hinh-cac-loai-hinh-doanh-nghiep', 'BRANDCO - Để giúp các bạn khởi sự kinh doanh nhanh chóng và thuận lợi. Brandco xin cung cấp cho quý khách hàng một số kiến thức về sự khác nhau giữa các loại hình doanh nghiệp, để quý khách có được sự lựa chọn tốt nhất', '2012_10/doanh-nghiep.jpeg', '', 'thumb/doanh-nghiep.jpeg.jpg|block/doanh-nghiep.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'khởi sự,kinh doanh,nhanh chóng,thuận lợi,quý khách,kiến thức,loại hình,doanh nghiệp'), 
(15, 32, '23,32', 0, 1, '', 0, 1351421742, 1351421742, 1, 1351421742, 0, 2, 'Thành lập văn phòng đại diên của doanh nghiệp nước ngoài&#33;&#33;&#33;', 'Thanh-lap-van-phong-dai-dien-cua-doanh-nghiep-nuoc-ngoai', 'BRANDCO -  Sau sự kiện Việt Nam tham gia vào WTO ngày càng có nhiều thương nhân nước ngoài đến Việt Nam để tìm hiểu môi trường đầu tư, xúc tiến các hoạt động kinh doanh. Là nhà tư vấn chuyên nghiệp trong lĩnh vực doanh nghiệp – thương mại – kinh tế, công ty luật  Brandco xin cung cấp tới quý khách hàng  về điều kiện cấp phép thành lập văn phòng đại diện của thương nhân nước ngoài tại Việt Nam.', '2012_10/vanphongdaidien.jpg', '', 'thumb/vanphongdaidien.jpg|block/vanphongdaidien.jpg', 1, 2, 1, 0, 0, 0, 0, 'sự kiện,tham gia,ngày càng,tìm hiểu,môi trường,xúc tiến,hoạt động,kinh doanh,tư vấn,lĩnh vực,doanh nghiệp,thương mại,kinh tế,công ty,quý khách,thành lập,văn phòng,đại diện'), 
(16, 32, '23,32', 0, 1, '', 0, 1351421861, 1351421861, 1, 1351421861, 0, 2, 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 'Tu-van-xin-chung-nhan-dau-tu-thanh-lap-cong-ty-lien-doanh-cong-ty-100-von-dau-tu-nuoc-ngoai-ve-phan-phoi', 'BRANDCO LAWFIRM - Công ty Luật Brandco  tự hào là công ty hàng đầu trong lĩnh vực tư vấn đầu tư và cung cấp các dịch vụ hỗ trợ các nhà đầu tư tại việt nam như: tư vấn thành lập doanh nghiệp liên doanh, công ty 100% vốn nước ngoài, tư vấn lập dự án đầu tư (dự án tiền khả thi và dự án khả thi), tư vấn thủ tục xin ưu đãi đầu tư....', '2012_10/dau-tu.jpeg', '', 'thumb/dau-tu.jpeg.jpg|block/dau-tu.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'công ty,tự hào,hàng đầu,lĩnh vực,tư vấn,hỗ trợ,thành lập,doanh nghiệp,liên doanh,dự án,khả thi,thủ tục');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_24`
--

DROP TABLE IF EXISTS `nv3_vi_news_24`;
CREATE TABLE `nv3_vi_news_24` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_25`
--

DROP TABLE IF EXISTS `nv3_vi_news_25`;
CREATE TABLE `nv3_vi_news_25` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_26`
--

DROP TABLE IF EXISTS `nv3_vi_news_26`;
CREATE TABLE `nv3_vi_news_26` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_27`
--

DROP TABLE IF EXISTS `nv3_vi_news_27`;
CREATE TABLE `nv3_vi_news_27` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_28`
--

DROP TABLE IF EXISTS `nv3_vi_news_28`;
CREATE TABLE `nv3_vi_news_28` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_29`
--

DROP TABLE IF EXISTS `nv3_vi_news_29`;
CREATE TABLE `nv3_vi_news_29` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_30`
--

DROP TABLE IF EXISTS `nv3_vi_news_30`;
CREATE TABLE `nv3_vi_news_30` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_31`
--

DROP TABLE IF EXISTS `nv3_vi_news_31`;
CREATE TABLE `nv3_vi_news_31` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_31`
--

INSERT INTO `nv3_vi_news_31` VALUES
(11, 31, '23,31', 0, 1, '', 0, 1351408478, 1351421539, 1, 1351408478, 0, 2, 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Nhung-van-de-can-luu-y-khi-thuc-hien-thu-tuc-dang-ky-kinh-doanh', 'BRANDCO - Để giúp các bạn khởi sự kinh doanh nhanh chóng và thuận lợi. Brandco xin cung cấp cho quý khách hàng một số vấn đề cần lưu ý khi thực hiện thủ tục đăng ký doanh nghiệp theo Luật Doanh nghiệp năm 2005.', 'nangly.jpg', '', 'thumb/nangly.jpg|block/nangly.jpg', 1, 2, 1, 1, 0, 5, 1, 'khởi sự,kinh doanh,nhanh chóng,thuận lợi,quý khách,vấn đề,lưu ý,thực hiện,thủ tục,đăng ký,doanh nghiệp'), 
(12, 31, '23,31', 0, 1, '', 0, 1351421031, 1351421613, 1, 1351421031, 0, 2, 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Cong-ty-luat-Brandco-Dich-vu-thanh-lap-doanh-nghiep', 'BRANDCO -  Là nhà tư vấn chuyên nghiệp trong lĩnh vực tư vấn đầu tư và tư vấn sở hữu trí tuệ, với nhiều năm kinh nghiệm phục vụ khách hàng, Công ty luật Brandco xin được giới thiệu tới rộng rãi các nhà đầu tư dịch vụ tư vấn thành lập doanh nghiệp do Công ty luật Brandco cung cấp.', '2012_10/dkkd.jpeg', '', 'thumb/dkkd.jpeg.jpg|block/dkkd.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'tư vấn,lĩnh vực,sở hữu,trí tuệ,kinh nghiệm,phục vụ,khách hàng,công ty,giới thiệu,rộng rãi,thành lập,doanh nghiệp'), 
(13, 31, '23,31', 0, 1, '', 0, 1351421252, 1351421641, 1, 1351421252, 0, 2, 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 'Cong-ty-luat-Brandco-Dac-diem-cua-cac-loai-hinh-cac-loai-hinh-doanh-nghiep', 'BRANDCO - Để giúp các bạn khởi sự kinh doanh nhanh chóng và thuận lợi. Brandco xin cung cấp cho quý khách hàng một số kiến thức về sự khác nhau giữa các loại hình doanh nghiệp, để quý khách có được sự lựa chọn tốt nhất', '2012_10/doanh-nghiep.jpeg', '', 'thumb/doanh-nghiep.jpeg.jpg|block/doanh-nghiep.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'khởi sự,kinh doanh,nhanh chóng,thuận lợi,quý khách,kiến thức,loại hình,doanh nghiệp');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_32`
--

DROP TABLE IF EXISTS `nv3_vi_news_32`;
CREATE TABLE `nv3_vi_news_32` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=17  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_32`
--

INSERT INTO `nv3_vi_news_32` VALUES
(14, 32, '23,32', 0, 1, '', 0, 1351421497, 1351421554, 1, 1351421497, 0, 2, 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 'Cong-ty-luat-Brandco-Xin-giay-phep-dau-tu', 'BRANDCO - Công ty Luật Brandco  tự hào là công ty hàng đầu trong lĩnh vực tư vấn đầu tư và cung cấp các dịch vụ hỗ trợ các nhà đầu tư tại việt nam như: tư vấn thành lập doanh nghiệp liên doanh, công ty 100% vốn nước ngoài, tư vấn lập dự án đầu tư (dự án tiền khả thi và dự án khả thi), tư vấn thủ tục xin ưu đãi đầu tư....', '2012_10/dau-tu.jpg', '', 'thumb/dau-tu.jpg|block/dau-tu.jpg', 1, 2, 1, 0, 0, 0, 0, 'công ty,tự hào,hàng đầu,lĩnh vực,tư vấn,hỗ trợ,thành lập,doanh nghiệp,liên doanh,dự án,khả thi,thủ tục'), 
(15, 32, '23,32', 0, 1, '', 0, 1351421742, 1351421742, 1, 1351421742, 0, 2, 'Thành lập văn phòng đại diên của doanh nghiệp nước ngoài&#33;&#33;&#33;', 'Thanh-lap-van-phong-dai-dien-cua-doanh-nghiep-nuoc-ngoai', 'BRANDCO -  Sau sự kiện Việt Nam tham gia vào WTO ngày càng có nhiều thương nhân nước ngoài đến Việt Nam để tìm hiểu môi trường đầu tư, xúc tiến các hoạt động kinh doanh. Là nhà tư vấn chuyên nghiệp trong lĩnh vực doanh nghiệp – thương mại – kinh tế, công ty luật  Brandco xin cung cấp tới quý khách hàng  về điều kiện cấp phép thành lập văn phòng đại diện của thương nhân nước ngoài tại Việt Nam.', '2012_10/vanphongdaidien.jpg', '', 'thumb/vanphongdaidien.jpg|block/vanphongdaidien.jpg', 1, 2, 1, 0, 0, 0, 0, 'sự kiện,tham gia,ngày càng,tìm hiểu,môi trường,xúc tiến,hoạt động,kinh doanh,tư vấn,lĩnh vực,doanh nghiệp,thương mại,kinh tế,công ty,quý khách,thành lập,văn phòng,đại diện'), 
(16, 32, '23,32', 0, 1, '', 0, 1351421861, 1351421861, 1, 1351421861, 0, 2, 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 'Tu-van-xin-chung-nhan-dau-tu-thanh-lap-cong-ty-lien-doanh-cong-ty-100-von-dau-tu-nuoc-ngoai-ve-phan-phoi', 'BRANDCO LAWFIRM - Công ty Luật Brandco  tự hào là công ty hàng đầu trong lĩnh vực tư vấn đầu tư và cung cấp các dịch vụ hỗ trợ các nhà đầu tư tại việt nam như: tư vấn thành lập doanh nghiệp liên doanh, công ty 100% vốn nước ngoài, tư vấn lập dự án đầu tư (dự án tiền khả thi và dự án khả thi), tư vấn thủ tục xin ưu đãi đầu tư....', '2012_10/dau-tu.jpeg', '', 'thumb/dau-tu.jpeg.jpg|block/dau-tu.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'công ty,tự hào,hàng đầu,lĩnh vực,tư vấn,hỗ trợ,thành lập,doanh nghiệp,liên doanh,dự án,khả thi,thủ tục');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_33`
--

DROP TABLE IF EXISTS `nv3_vi_news_33`;
CREATE TABLE `nv3_vi_news_33` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_34`
--

DROP TABLE IF EXISTS `nv3_vi_news_34`;
CREATE TABLE `nv3_vi_news_34` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_35`
--

DROP TABLE IF EXISTS `nv3_vi_news_35`;
CREATE TABLE `nv3_vi_news_35` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_36`
--

DROP TABLE IF EXISTS `nv3_vi_news_36`;
CREATE TABLE `nv3_vi_news_36` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_37`
--

DROP TABLE IF EXISTS `nv3_vi_news_37`;
CREATE TABLE `nv3_vi_news_37` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_38`
--

DROP TABLE IF EXISTS `nv3_vi_news_38`;
CREATE TABLE `nv3_vi_news_38` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_39`
--

DROP TABLE IF EXISTS `nv3_vi_news_39`;
CREATE TABLE `nv3_vi_news_39` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_40`
--

DROP TABLE IF EXISTS `nv3_vi_news_40`;
CREATE TABLE `nv3_vi_news_40` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_41`
--

DROP TABLE IF EXISTS `nv3_vi_news_41`;
CREATE TABLE `nv3_vi_news_41` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_admins`
--

DROP TABLE IF EXISTS `nv3_vi_news_admins`;
CREATE TABLE `nv3_vi_news_admins` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `comment` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_block`
--

DROP TABLE IF EXISTS `nv3_vi_news_block`;
CREATE TABLE `nv3_vi_news_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_block`
--

INSERT INTO `nv3_vi_news_block` VALUES
(2, 13, 4), 
(2, 15, 2), 
(2, 11, 6), 
(2, 12, 5), 
(2, 14, 3), 
(2, 16, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_block_cat`
--

DROP TABLE IF EXISTS `nv3_vi_news_block_cat`;
CREATE TABLE `nv3_vi_news_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `number` mediumint(4) NOT NULL DEFAULT '10',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_block_cat`
--

INSERT INTO `nv3_vi_news_block_cat` VALUES
(1, 0, 4, 'Tin tiêu điểm', 'Tin-tieu-diem', '', '', 'Tin tiêu điểm', 1, '', 1279945710, 1279956943), 
(2, 1, 4, 'Tin mới nhất', 'Tin-moi-nhat', '', '', 'Tin tiêu điểm', 2, '', 1279945725, 1279956445);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_bodyhtml_1`
--

DROP TABLE IF EXISTS `nv3_vi_news_bodyhtml_1`;
CREATE TABLE `nv3_vi_news_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_bodyhtml_1`
--

INSERT INTO `nv3_vi_news_bodyhtml_1` VALUES
(16, 'Theo Khoản 1, Ðiều 50 Luật Ðầu tư thì nhà đầu tư nước ngoài lần đầu tiên đầu tư vào Việt Nam phải có dự án đầu tư và làm thủ tục đăng ký đầu tư hoặc thẩm tra dự án đầu tư tại cơ quan Nhà nước quản lý đầu tư để được cấp Giấy chứng nhận đầu tư. Giấy chứng nhận đầu tư đồng thời là Giấy chứng nhận đăng ký kinh doanh.<br  />&nbsp;<br  />1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Các văn bản pháp luật tham khảo:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Biểu Cam kết dịch vụ WTO của Việt&nbsp;Nam.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Quyết định 10/2007/QÐ-BTM của Bộ Thương Mại ngày 21/05/2007 về Quyết định công bố lộ trình thực hiện hoạt động mua bán hàng hóa và các hoạt động liên quan trực tiếp đến mua bán hàng hóa.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Thông tư 09/2007/TT-BTM của Bộ Thương Mại ngày 17/07/2007 về Hướng dẫn thi hành Nghị định số 23/2007/NÐ-CP ngày 12 tháng 02 năm 2007 quy định chi tiết Luật Thương mại về hoạt động mua bán hàng hóa và các hoạt động liên quan trực tiếp đến mua bán hàng hóa của doanh nghiệp có vốn đầu tư nước ngoài tại Việt Nam.<br  />2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hồ sơ xin cấp giấy phép thành lập Công ty:<br  />a.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Văn bản đề nghị cấp Giấy chứng nhận đầu tư - theo mẫu I-3 của Quyết định 1088/2006/QÐ-BKH.<br  />b.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Báo cáo năng lực tài chính của nhà đầu tư (do nhà đầu tư lập và chịu trách nhiệm).<br  />c.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Giải trình khả năng đáp ứng điều kiện mà dự án đầu tư phải đáp ứng theo quy định của pháp luật.<br  />d.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hồ sơ pháp lý liên quan đến địa chỉ trụ sở chính và địa điểm thực hiện dự án (Nhà đầu tư chỉ mang đến để chuyên viên tiếp nhận hồ sơ xem và đối chiếu).<br  />e.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Dự thảo Ðiều lệ Công ty tương ứng với từng loại hình doanh nghiệp (Công ty TNHH 2 thành viên trở lên, Công ty Cổ phần) (được người đại diện theo pháp luật, các thành viên hoặc người đại diện theo uỷ quyền ký từng trang). Danh sách thành viên sáng lập/ cổ đông sáng lập.<br  />f.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Văn bản xác nhận tư cách pháp lý của các thành viên sáng lập:<br  />&nbsp;<br  /><ul> <li> Ðối với thành viên sáng lập là pháp nhân: Bản sao hợp lệ có hợp pháp hóa lãnh sự (không quá 3 tháng trước ngày nộp hồ sơ) của một trong các loại giấy tờ: Quyết định thành lập, Giấy chứng nhận Ðăng ký kinh doanh hoặc Giấy tờ tương đương khác, Ðiều lệ (đối với pháp nhân trong nước).</li></ul>&nbsp;<br  /><ul> <li> Ðối với thành viên sáng lập là cá nhân: Bản sao hợp lệ có hợp pháp hóa lãnh sự (bản sao có công chứng không quá 3 tháng trước ngày nộp hồ sơ) của một trong các giấy tờ: Giấy chứng minh nhân dân, Hộ chiếu hoặc giấy tờ chứng thực cá nhân hợp pháp còn hiệu lực.</li></ul>&nbsp;<br  />&nbsp;<br  />g.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Văn bản uỷ quyền của Chủ sở hữu cho người được uỷ quyền đối với trường hợp chủ sở hữu công ty là tổ chức và Bản sao hợp lệ (bản sao có công chứng) một trong các giấy tờ chứng thực cá nhân của người đại diện theo uỷ quyền.<br  />&nbsp;<br  />h.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hợp đồng liên doanh đối với hình thức đầu tư thành lập tổ chức kinh tế liên doanh giữa nhà đầu tư trong nước và nhà đầu tư nước ngoài. (Tham khảo Ðiều 54, 55 Nghị định 108/2006/NÐ-CP ngày 22/09/2006).<br  />&nbsp;<br  />i.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Trường hợp dự án đầu tư liên doanh có sử dụng vốn Nhà nước thì phải có văn bản chấp thuận việc sử dụng vốn Nhà nước để đầu tư của cơ quan có thẩm quyền.<br  />&nbsp;<br  />j.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Bản sao hợp lệ chứng chỉ hành nghề của Giám đốc (Tổng Giám đốc) và các cá nhân khác quy định tại K.13 Ðiều 4 Luật Doanh nghiệp.<br  />&nbsp;<br  />3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hồ sơ nộp tại :<br  />a.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Sở Kế hoạch và Ðầu tư phòng doanh nghiệp nước ngoài Phòng Doanh nghiệp nước ngoài<br  />b.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Số lượng hồ sơ nộp: 8 bộ (trong đó có 1 bộ gốc)<br  />&nbsp;<br  />Mọi vấn đề còn thắc mắc liên quan đến thủ tục nói trên, xin Quý khách hàng vui lòng liên lạc với công ty chúng tôi để được cung cấp&nbsp;<a href=\"http://brandco.vn/?do=service&amp;mod=category&amp;show=search&amp;kw=ch%E1%BB%A9ng%20nh%E1%BA%ADn%20%C4%91%E1%BA%A7u%20t%C6%B0\">dịch vụ tư vấn thành lập công ty có vốn đầu tư nước ngoài tại Việt nam</a>.', '', 1, 0, 1, 1, 1), 
(14, '<div align=\"justify\"> Là một nhà tư vấn chuyên nghiệp trong lĩnh vực tư vấn đầu tư, Công ty Luật Brandco hiện đang cung cấp nhiều các dịch vụ tư vấn đầu tư hỗ trợ Quý khách hàng, cụ thể:<br  /> &nbsp;</div><strong>- Tư vấn đầu tư trong và ngoài nước</strong>: Tư vấn và giúp khách hàng lựa chọn các hình thức đầu tư tối ưu: đầu tư trực tiếp, đầu tư gián tiếp, thành lập các đơn vị sản xuất kinh doanh như :&nbsp;<br  /><br  /><br  /><ul> <li> Thành lập Công ty Liên doanh;</li> <li> Thành lập Doanh nghiệp 100% vốn nước ngoài;</li> <li> Thành lập công ty cổ phần có vốn đầu tư nước ngoài;</li> <li> Hợp đồng hợp tác liên doanh;</li> <li> Lập dự án Đầu tư nước ngoài tại Việt&nbsp;Nam;</li> <li> Cung cấp thông tin về môi trường đầu tư tại Việt&nbsp;Nam;</li> <li> Điều tra vị trí đầu tư, đối tác, cung cấp dịch vụ Tư vấn chuyên nghiệp&nbsp; cho các Doanh nghiệp nước ngoài;</li> <li> Luật sư Đại diện tại Việt&nbsp;Nam&nbsp;cho doanh nghiệp đầu tư nước ngoài tại Việt&nbsp;Nam;</li> <li> Dự án đầu tư trong nước và đầu tư ra nước ngoài;</li> <li> Mở Văn phòng đại diện, chi nhánh công ty tại Việt nam và ở nước ngoài;</li> <li> Cơ cấu lại doanh nghiệp có vốn đầu tư nước ngoài tại Việt&nbsp;Nam;</li> <li> Giải thể, phá sản doanh nghiệp có vốn đầu tư nước ngoài tại ViệtNam;</li> <li> Hợp nhất, sáp nhập doanh nghiệp có vốn đầu tư nước ngoài tại ViệtNam;-&nbsp;&nbsp;<strong>Đại diện cho nhà đầu tư</strong>&nbsp;liên hệ với các cơ quan chức năng để triển khai Dự án;<br  /> -&nbsp;<strong>Giới thiệu về những ưu đãi đầu tư</strong>&nbsp;trong các lĩnh vực, địa bàn đầu tư cũng như điều kiện để nhận được những ưu đãi đó.<br  /> -&nbsp;<strong>Cung cấp các thông tin về các dự án</strong>&nbsp;gọi vốn đầu tư nước ngoài, bao gồm các thông tin chi tiết về các lĩnh vực, địa bàn đặc biệt khuyến khích đầu tư, các dự án có thể triển khai ngay. Những thông tin về những dự án quan trọng được cập nhật từ những cơ quan chức năng của Nhà nước Việt&nbsp;Nam.<br  /> -&nbsp;<strong>Lập Hồ sơ xin đăng ký đầu tư</strong>&nbsp;và các ưu đãi đầu tư;&nbsp;<br  /> <br  /> -&nbsp;Lập Hồ sơ&nbsp;<strong>xin cấp Giấy phép đầu tư</strong>&nbsp;và các ưu đãi đầu tư;<br  /> - Lập các Dự án chi tiết;<br  /> -&nbsp;<strong>Dịch các tài liệu pháp lý</strong>&nbsp;liên quan đến Dự án đầu tư;<br  /> -&nbsp;Tham gia đàm phán, xây dựng các&nbsp;<strong>Hợp đồng liên doanh, Hợp tác kinh doanh</strong><br  /> -&nbsp;<strong>Nhận sự uỷ quyền của các nhà đầu tư</strong>&nbsp;để liên hệ với các cơ quan chức năng Việt&nbsp;Nam&nbsp;hoàn thành các thủ tục đăng ký hoặc xin cấp phép đầu tư.<br  /> &nbsp;<br  /> Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với&nbsp;<strong>Tư vấn Luật Brandco</strong>&nbsp;để&nbsp;được hướng dẫn chi tiết<strong>. </strong><br  /> &nbsp;</li></ul>', '', 1, 0, 1, 1, 1), 
(15, '<strong>1. Điều kiện cấp Giấy phép thành lập Văn phòng đại diện</strong><br  />1. Thương nhân nước ngoài được cấp Giấy phép thành lập Văn phòng đại diện tại Việt Nam khi có đủ các điều kiện sau:<br  />a) Là thương nhân được pháp luật nước, vùng lãnh thổ (sau đây gọi chung là nước) nơi thương nhân đó thành lập hoặc đăng ký kinh doanh công nhận hợp pháp;<br  />b) Đã hoạt động không dưới 01 năm, kể từ khi được thành lập hoặc đăng ký kinh doanh hợp pháp ở nước của thương nhân.<br  /><strong>2.&nbsp;Hồ sơ&nbsp;&nbsp;thành lập VPDD:</strong><br  />Hồ sơ xin cấp giấy phép thành lập VPDD của Quý khách hàng sẽ gồm các giấy tờ sau đây:<br  />1) Đơn đề nghị cấp Giấy phép thành lập văn phòng đại diện bằng tiếng Việt Nam (theo mẫu của Bộ Thương mại) do đại diện có thẩm quyền của thương nhân nước ngoài ký;<br  />2) Bản sao Giấy đăng ký kinh doanh hoặc giấy tờ có giá trị tương đương của thương nhân nước ngoài được cơ quan có thẩm quyền nơi thương nhân nước ngoài thành lập xác nhận. Trong trường hợp Giấy đăng ký kinh doanh hoặc giấy tờ có giá trị tương đương có quy định thời hạn hoạt động của thương nhân nước ngoài thì thời hạn đó phải còn ít nhất là một năm;<br  />3) Báo cáo tài chính có kiểm toán hoặc tài liệu khác có giá trị tương đương chứng minh được sự tồn tại và hoạt động thực sự của thương nhân nước ngoài trong năm tài chính gần nhất;<br  />4) Bản sao Điều lệ hoạt động của thương nhân đối với thương nhân nước ngoài là các tổ chức kinh tế.<br  />5) Bản sao hộ chiếu hoặc giấy chứng minh nhân dân (nếu là người ViệtNam); bản sao hộ chiếu (nếu là người nước ngoài) của người đứng đầu văn phòng đại diện;<br  />6) Bản sao hợp đồng thuê địa điểm đặt trụ sở văn phòng đại diện.<br  />Các giấy tờ quy định tại điểm 2 và 3 được lập bằng tiếng nước nơi thương nhân đăng ký và phải dịch ra tiếng Việt, được cơ quan đại diện ngoại giao, cơ quan lãnh sự của Việt Nam ở nước sở tại chứng nhận và thực hiện việc hợp pháp hóa lãnh sự theo quy định của pháp luật Việt Nam.&nbsp;<br  />&nbsp;<br  />Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với&nbsp;<strong>Tư vấn Luật Brandco</strong>&nbsp;để&nbsp;được hướng dẫn chi tiết<strong>. </strong><br  />', '', 1, 0, 1, 1, 1), 
(11, '<strong>I- Lựa chọn ngành, nghề kinh doanh</strong><br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Doanh&nbsp; nghiệp có quyền kinh doanh tất cả các ngành mà pháp luật không cấm trừ kinh doanh các ngành, nghề gây phương hại đến quốc phòng, an ninh, trật tự, an toàn xã hội, truyền thống lịch sử, văn hóa, đạo đức,&nbsp; thuần phong mỹ tục Việt Nam và sức khỏe của nhân dân.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>&nbsp;Điều 7 của Luật Doanh nghiệp (Luật Doanh nghiệp năm 2005):</strong><br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1. Doanh nghiệp thuộc mọi thành phần kinh tế có quyền kinh doanh các ngành, nghề mà pháp luật không cấm.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. Đối với ngành, nghề mà pháp luật về đầu tư và pháp luật có liên quan quy định phải có điều kiện thì doanh nghiệp chỉ được kinh doanh ngành,&nbsp;nghề đó khi có đủ điều kiện theo quy định.<br  />Điều kiện kinh doanh là yêu cầu mà doanh nghiệp phải có hoặc phải thực hiện khi kinh doanh ngành, nghề cụ thể, được thể hiện bằng giấy phép kinh doanh, giấy chứng nhận đủ điều kiện kinh doanh, chứng chỉ hành nghề, chứng nhận bảo hiểm trách nhiệm nghề nghiệp, yêu cầu về vốn pháp định hoặc yêu cầu khác.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. Cấm hoạt động kinh doanh gây phương hại đến quốc phòng, an ninh, trật tự, an toàn xã hội, truyền thống lịch sử, văn hoá, đạo đức, thuần phong mỹ tục Việt Nam và sức khoẻ của nhân dân, làm huỷ hoại tài nguyên, phá huỷ môi trường.<br  />Chính phủ quy định cụ thể danh mục ngành, nghề kinh doanh bị cấm.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4. Chính phủ định kỳ rà soát, đánh giá lại toàn bộ hoặc một phần các điều kiện kinh doanh; bãi bỏ hoặc kiến nghị bãi bỏ các điều kiện không còn phù hợp; sửa đổi hoặc kiến nghị sửa đổi các điều kiện bất hợp lý; ban hành hoặc kiến nghị ban hành điều kiện kinh doanh mới theo yêu cầu quản lý nhà nước.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5. Bộ, cơ quan ngang bộ, Hội đồng nhân dân và Uỷ ban nhân dân các cấp không được quy định về ngành, nghề kinh doanh có điều kiện và điều kiện kinh doanh.<br  /><br  /><br  />&nbsp;<strong>II- Quyền thành lập, góp vốn, mua cổ phần và quản lý doanh nghiệp:</strong><br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Điều 13 của Luật Doanh nghiệp (Luật Doanh nghiệp&nbsp; năm 2005):</strong><br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1. Tổ chức, cá nhân Việt Nam, tổ chức, cá nhân nước ngoài có quyền thành lập và quản lý doanh nghiệp tại Việt Nam theo quy định của Luật này, trừ trường hợp quy định tại khoản 2 Điều này.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. Tổ chức, cá nhân sau đây không được quyền thành lập và quản lý doanh nghiệp tại Việt Nam:<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; a) Cơ quan nhà nước, đơn vị lực lượng vũ trang nhân dân Việt Nam sử dụng tài sản nhà nước để thành lập doanh nghiệp kinh doanh thu lợi riêng cho cơ quan, đơn vị mình;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; b) Cán bộ, công chức theo quy định của pháp luật về cán bộ, công chức;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; c) Sĩ quan, hạ sĩ quan, quân nhân chuyên nghiệp, công nhân quốc phòng trong các cơ quan, đơn vị thuộc Quân đội nhân dân Việt Nam; sĩ quan,&nbsp;hạ sĩ quan chuyên nghiệp trong các cơ quan, đơn vị thuộc Công an nhân dân Việt Nam;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; d) Cán bộ lãnh đạo, quản lý nghiệp vụ trong các doanh nghiệp 100% vốn sở hữu nhà nước, trừ những người được cử làm đại diện theo uỷ quyền để quản lý phần vốn góp của Nhà nước tại doanh nghiệp khác;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; đ) Người chưa thành niên; người bị hạn chế năng lực hành vi dân sự hoặc bị mất năng lực hành vi dân sự;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; e) Người đang chấp hành hình phạt tù hoặc đang bị Toà án cấm hành nghề kinh doanh;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; g) Các trường hợp khác theo quy định của pháp luật về phá sản.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. Tổ chức, cá nhân có quyền mua cổ phần của công ty cổ phần, góp vốn vào công ty trách nhiệm hữu hạn, công ty hợp danh theo quy định của Luật này, trừ trường hợp quy định tại khoản 4 Điều này.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4. Tổ chức, cá nhân sau đây không được mua cổ phần của công ty cổ phần, góp vốn vào công ty trách nhiệm hữu hạn, công ty hợp danh theo quy định của Luật này:<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; a) Cơ quan nhà nước, đơn vị lực lượng vũ trang nhân dân Việt Nam sử dụng tài sản nhà nước góp vốn vào doanh nghiệp để thu lợi riêng cho cơ quan, đơn vị mình;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; b) Các đối tượng không được góp vốn vào doanh nghiệp theo quy định của pháp luật về cán bộ, công chức.<br  /><br  /><br  /><strong>III- Cách đặt tên của doanh nghiệp:</strong><br  /><strong>(Tên của doanh&nbsp; nghiệp phải bảo đảm theo quy định tại Điều 31, 32, 33, 34 - Luật Doanh nghiệp năm 2005)</strong><br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Điều 31. </strong>Tên doanh nghiệp<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1. Tên doanh nghiệp phải viết được bằng tiếng Việt, có thể kèm theo chữ số và ký hiệu, phải phát âm được và có ít nhất hai thành tố sau đây:<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; a) Loại hình doanh nghiệp;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; b) Tên riêng.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. Tên doanh nghiệp phải được viết hoặc gắn tại trụ sở chính, chi nhánh, văn phòng đại diện của doanh nghiệp. Tên doanh nghiệp phải được in hoặc viết trên các giấy tờ giao dịch, hồ sơ tài liệu và ấn phẩm do doanh nghiệp phát hành.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. Căn cứ vào quy định tại Điều này và các điều 32, 33 và 34 của Luật này, cơ quan đăng ký kinh doanh có quyền từ chối chấp thuận tên dự kiến đăng ký của doanh nghiệp. Quyết định của cơ quan đăng ký kinh doanh là quyết định cuối cùng.<br  />&nbsp;<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Điều 32.</strong> Những điều cấm trong đặt tên doanh nghiệp<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1. Đặt tên trùng hoặc tên gây nhầm lẫn với tên của doanh nghiệp đã đăng ký.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. Sử dụng tên cơ quan nhà nước, đơn vị lực lượng vũ trang nhân dân, tên của tổ chức chính trị, tổ chức chính trị - xã hội, tổ chức chính trị xã hội - nghề nghiệp, tổ chức xã hội, tổ chức xã hội - nghề nghiệp để làm toàn bộ hoặc một phần tên riêng của doanh nghiệp, trừ trường hợp có sự chấp thuận của cơ quan, đơn vị hoặc tổ chức đó.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. Sử dụng từ ngữ, ký hiệu vi phạm truyền thống lịch sử, văn hoá, đạo đức và thuần phong mỹ tục của dân tộc.<br  />&nbsp;<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Điều 33.</strong> Tên doanh nghiệp viết bằng tiếng nước ngoài và tên viết tắt của doanh nghiệp<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1. Tên doanh nghiệp viết bằng tiếng nước ngoài là tên được dịch từ tên bằng tiếng Việt sang tiếng nước ngoài tương ứng. Khi dịch sang tiếng nước ngoài, tên riêng của doanh nghiệp có thể giữ nguyên hoặc dịch theo nghĩa tương ứng sang tiếng nước ngoài.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. Tên bằng tiếng nước ngoài của doanh nghiệp được in hoặc viết với khổ chữ nhỏ hơn tên bằng tiếng Việt của doanh nghiệp tại cơ sở của doanh nghiệp hoặc trên các giấy tờ giao dịch, hồ sơ tài liệu và ấn phẩm do doanh nghiệp phát hành.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. Tên viết tắt của doanh nghiệp được viết tắt từ tên bằng tiếng Việt hoặc tên viết bằng tiếng nước ngoài.<br  />&nbsp;<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Điều 34.</strong> Tên trùng và tên gây nhầm lẫn<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1. Tên trùng là tên của doanh nghiệp yêu cầu đăng ký được viết và đọc bằng tiếng Việt hoàn toàn giống với tên của doanh nghiệp đã đăng ký.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. Các trường hợp sau đây được coi là tên gây nhầm lẫn với tên của doanh nghiệp đã đăng ký:<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; a) Tên bằng tiếng Việt của doanh nghiệp yêu cầu đăng ký được đọc giống như tên doanh nghiệp đã đăng ký;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; b) Tên bằng tiếng Việt của doanh nghiệp yêu cầu đăng ký chỉ khác tên doanh nghiệp đã đăng ký bởi ký hiệu “&amp;”;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; c) Tên viết tắt của doanh nghiệp yêu cầu đăng ký trùng với tên viết tắt của doanh nghiệp đã đăng ký;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; d) Tên bằng tiếng nước ngoài của doanh nghiệp yêu cầu đăng ký trùng với tên bằng tiếng nước ngoài của doanh nghiệp đã đăng ký;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; đ) Tên riêng của doanh nghiệp yêu cầu đăng ký khác với tên riêng của doanh nghiệp đã đăng ký bởi số tự nhiên, số thứ tự hoặc các chữ cái tiếng Việt ngay sau tên riêng của doanh nghiệp đó, trừ trường hợp doanh nghiệp yêu cầu đăng ký là công ty con của doanh nghiệp đã đăng ký;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; e) Tên riêng của doanh nghiệp yêu cầu đăng ký khác với tên riêng của doanh nghiệp đã đăng ký bởi từ “tân” ngay trước hoặc “mới” ngay sau tên riêng của doanh nghiệp đã đăng ký;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; g) Tên riêng của doanh nghiệp yêu cầu đăng ký chỉ khác tên riêng của doanh nghiệp đã đăng ký bằng các từ “miền bắc”, “miền nam”, “miền trung”, “miền tây”, “miền đông” hoặc các từ có ý nghĩa tương tự, trừ trường hợp doanh nghiệp yêu cầu đăng ký là công ty con của doanh nghiệp đã đăng ký.<br  />&nbsp;<br  />&nbsp;<br  />Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với <strong>Tư vấn Luật Brandco</strong>&nbsp;để&nbsp;được hướng dẫn chi tiết<strong>.</strong>', '', 1, 0, 1, 1, 1), 
(12, '<strong>A.</strong>&nbsp;<strong><u>Thủ tục thành lập doanh nghiệp:</u></strong><br  />&nbsp;<br  />Để khởi sự kinh doanh theo quy định của pháp luật, các nhà đầu tư cần tiến hành thủ tục đăng ký kinh doanh để thành lập doanh nghiệp theo quy trình sau:&nbsp;<br  /><br  /><strong>1.</strong>&nbsp;<strong>Đăng ký kinh doanh:</strong><br  />Doanh nghiệp phải tiến hành nộp hồ sơ đăng ký kinh doanh của Công ty tại<strong>Sở kế hoạch và đầu tỉnh thành phố nơi doanh nghiệp đặt trụ sở chính;</strong><br  />&nbsp;<br  /><strong>2.</strong>&nbsp;<strong>Đăng ký con dấu pháp&nbsp; nhân:</strong><br  />Sau khi có Giấy đăng ký kinh doanh Quý khách hàng phải tiến hành&nbsp; đăng ký sử dụng hợp pháp con dấu pháp nhân của doanh nghiệp tại cơ quan Công an tỉnh thành phố nơi doanh nghiệp đặt trụ sở chính;<br  />&nbsp;<br  /><strong>3.</strong>&nbsp;<strong>Đăng ký mã số thuế:</strong><br  />Quý khách hàng phải đăng ký sử dụng hợp pháp Mã số thuế, Mã số Hải quan của doanh nghiệp&nbsp; tại Cục Thuế tỉnh thành phố nơi doanh nghiệp đặt trụ sở chính;<br  />&nbsp;<br  /><strong><u>B.&nbsp;Các dịch vụ hỗ trợ của Công ty luật Brandco:</u></strong><br  />Với tư cách của một nhà tư vấn tận tâm của Quý khách hàng,&nbsp;<strong>Công ty luật Brandco</strong>&nbsp;sẽ có các hỗ trợ quan trọng dành cho Quý khách hàng, cụ thể:<br  />&nbsp;<br  /><strong>I. Tư vấn, giải đáp các vướng mắc của nhà đầu tư:</strong><br  /><ul> <li> Tư vấn các vấn đề pháp lý liên quan đến quá trình thành lập, hoạt động, quản lý Doanh nghiệp;</li> <li> Tư vấn cơ cấu nhân sự trong công ty;</li> <li> Tư vấn về các hợp đồng trước khi đăng ký kinh doanh;</li> <li> Tư vấn về việc thiết lập văn bản ràng buộc giữa các thành viên/cổ đông trong công ty;</li> <li> Tư vấn hồ sơ, tài liệu chuẩn bị thành lập Doanh nghiệp;</li> <li> Tư vấn về chọn loại hình doanh nghiệp phù hợp với ngành nghề kinh doanh và quy mô của công ty;</li> <li> Tư vấn cách phân chia lợi nhuận của các thành viên;</li> <li> Tư vấn chi tiết về thủ tục mua hoá đơn lần đầu cho doanh nghiệp;</li> <li> Tư vấn về vốn đầu tư ban đầu, vốn pháp định, vốn điều lệ…</li> <li> Tư vấn cách đặt tên Doanh nghiệp, tên viết tắt phù hợp với nhu cầu và yêu cầu của hoạt động kinh doanh và tiến hành tra cứu tên doanh nghiệp;</li> <li> Tư vấn về đăng ký ngành nghề Đăng ký kinh doanh (lựa chọn, sắp xếp ngành nghề và dự tính ngành nghề kinh doanh sắp tới);</li> <li> Tư vấn những điều kiện trước khi thành lập, những điều kiện sau khi thành lập đối với nghành nghề đăng ký kinh doanh;</li> <li> Tư vấn chi tiết cho doanh nghiệp các vấn đề về thuế, các nghĩa vụ về tài chính sau khi đăng ký kinh doanh và quá trình hoạt động sản xuất kinh doanh ;</li> <li> Tư vấn về cơ cấu nhân sự, quyền hạn, nghĩa vụ của các thành viên/cổ đông trong công ty;</li></ul><br  /><strong><u>II. Tư vấn, soạn thảo tài liệu hò sơ doanh nghiệp:</u></strong><br  /><ul> <li> Đơn đăng ký kinh doanh;</li> <li> Danh sách&nbsp; thành viên/cổ đông;</li> <li> Điều lệ công ty;</li> <li> Quyết định bổ nhiệm Kế toán trưởng;</li> <li> Sổ đăng ký thành viên/cổ dông sáng lập.&nbsp;</li> <li> Hợp đồng lao động_nếu có;</li> <li> Biên bản họp công ty về việc góp vốn của sáng lập viên;</li> <li> Giấy chứng nhận góp vốn cho các thành viên/cổ đông;</li> <li> Quyết định bổ nhiệm Giám đốc;</li></ul><strong><u>III. Thực hiện dịch vụ tư vấn:</u></strong><br  /><ul> <li> Đại diện cho khách hàng trên phòng đăng ký kinh doanh của sở&nbsp;kế hoạch và đầu tư để nộp hồ&nbsp;sơ Thành lập Doanh nghiệp;</li> <li> Đại diện cho khách hàng để theo dõi hồ sơ của doanh nghiệp và nhận kết quả trả lời của Phòng đăng ký kinh doanh;</li> <li> Nhận kết quả là Giấy chứng nhận ĐKKD tại Phòng đăng ký kinh doanh;</li> <li> Đại diện tại cơ quan Công an để xin giấy phép sử dụng con dấu;</li> <li> Tiến hành thủ tục để làm con dấu cho Doanh nghiệp (dấu công ty, dấu chức danh, dấu đăng ký&nbsp;mã số thuế);</li> <li> Tiến hành thủ tục đăng ký mã số thuế và mã số hải quan cho doanh nghiệp;</li></ul>&nbsp;<br  /><strong>IV.</strong>&nbsp;<strong>Thời gian thực hiện dịch vụ:</strong><br  />Thời gian để hoàn thiện thủ tục thành lập doanh nghiệp là 05 - 20 ngày làm việc. Tuy nhiên,&nbsp;<strong>thời gian nói trên có thể thay đổi theo yêu cầu</strong>&nbsp;của Quý khách hàng.<br  />&nbsp;<br  /><em><strong><u>Lưu ý</u></strong></em><em><strong>:&nbsp;</strong></em><em>Trong quá trình thành lập Doanh nghiệp người đại diện theo pháp luật của doanh nghiệp phải 02 lần đến cơ quan đăng ký kinh doanh (1) để ký nhận giấy chứng nhận đăng ký kinh doanh (2) ký lấy dấu pháp nhân của doanh nghiệp)_khách hàng nhớ mang theo một trong hai giấy tờ: CMTND bản gốc hoặc Hộ Chiếu.</em><br  />&nbsp;<br  /><strong>C.Trách nhiệm của Công ty luật Brandco sau thành lập:</strong><br  /><ul> <li> Tư vấn chính sách thuế hiện hành liên quan đến hoạt động của doanh nghiệp;</li> <li> Tư vấn các vấn đề liên quan đến tổ chức và hoạt động của doanh nghiệp;</li> <li> Hướng dẫn thủ tục mua hóa đơn thuế Giá trị gia tăng;</li> <li> Tư vấn kê khai thuế;</li> <li> Tư vấn và hoàn thiện Bộ hồ sơ Nội bộ doanh nghiệp, bao gồm: Điều lệ Doanh nghiệp, Danh sách thành viên, Giấy chứng nhận Vốn góp, các Quyết định bổ nhiệm các chức danh quản lý của doanh nghiệp...</li></ul>&nbsp;<br  /><strong>Note: Đặc biệt, để đồng hành cùng sự phát triển của Cộng đồng doanh nhân Việt. Công ty Luật Brandco cam kết tư vấn miễn phí về chính sách pháp luật hiện hành liên quan đến hoạt động của Công ty 01 năm sau thành lập</strong>;<br  />&nbsp;<br  />Hãy để chúng tôi chuẩn hóa ý tưởng&nbsp;thành lập doanh nghiệp&nbsp;của bạn bằng cách cung cấp thông tin thành lập doanh nghiệp theo mẫu sau:&nbsp;<a href=\"http://www.camnangphapluat.com/Uploaded/admins/YEU%20CAU%20THONG%20TIN%20TL%20CA%20NHAN%20MOI.doc\">YEU CAU THONG TIN TL CA NHAN MOI.doc</a><br  />&nbsp;<br  />=========================<br  />Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với&nbsp;<strong>Công ty Luật Brandco</strong>&nbsp;để&nbsp;được hướng dẫn chi tiết<strong>.</strong>', '', 1, 0, 1, 1, 1), 
(13, 'Việc lựa chọn hình thức doanh nghiệp trước khi bắt đầu công việc kinh doanh là rất quan trọng, nó có ảnh hưởng không nhỏ tới sự tồn tại và phát triển của doanh nghiệp. Về cơ bản, những sự khác biệt tạo ra bởi loại hình doanh nghiệp là: (i) uy tín doanh nghiệp do thói quen tiêu dùng; (ii) khả năng huy động vốn; (iii) rủi ro đầu tư; (iv) tính phức tạp của thủ tục và các chi phí thành lập doanh nghiệp; (v) tổ chức quản lý doanh nghiệp.<br  />&nbsp;<br  /><strong>1. Công ty cổ phần:</strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vốn điều lệ được chia thành nhiều phần bằng nhau gọi là cổ phần (Công ty cổ phần phải có cổ phần phổ thông và có thể có cổ phần ưu đãi. Cổ phần ưu đãi gồm các loại như cổ phần ưu đãi biểu quyết, cổ phần ưu đãi cổ tức, cổ phần ưu đãi hoàn lại và cổ phần ưu đãi khác do Điều lệ công ty quy định);<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cổ đông có thể là tổ chức, cá nhân; số lượng cổ đông tối thiểu là ba và không hạn chế số lượng tối đa;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cổ đông chỉ chịu trách nhiệm về các khoản nợ và nghĩa vụ tài sản khác của doanh nghiệp trong phạm vi số vốn đã góp vào doanh nghiệp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cổ đông có quyền tự do chuyển nhượng cổ phần của mình cho người khác, trừ trường hợp (Cổ đông sở hữu cổ phần ưu đãi biểu quyết không được chuyển nhượng cổ phần đó cho người khác; Trong thời hạn ba năm, kể từ ngày công ty được cấp Giấy chứng nhận đăng ký kinh doanh, cổ đông sáng lập có quyền tự do chuyển nhượng cổ phần phổ thông của mình cho cổ đông sáng lập khác nhưng chỉ được chuyển nhượng cổ phần phổ thông của mình cho người không phải là cổ đông sáng lập nếu được sự chấp thuận của Đại hội đồng cổ đông sau 3 năm mọi hạn chế đối với cổ đông sáng lập bị bãi bỏ).<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty cổ phần có quyền phát hành chứng khoán các loại để huy động vốn.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty cổ phần có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh.<br  /><strong><u>Ưu điểm:</u></strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chế độ trách nhiệm của công ty cổ phần là trách nhiệm hữu hạn, các cổ đông chỉ chịu trách nhiệm về nợ và các nghĩa vụ tài sản khác của công ty trong phạm vi vốn góp nên mức độ rủi do của các cổ đông không cao;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Khả năng hoạt động của công ty cổ phần rất rộng, trong hầu hết các lịch vực, ngành nghề;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cơ cấu vốn của công ty cổ phần hết sức linh hoạt tạo điều kiện nhiều người cùng góp vốn vào công ty;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Khả năng huy động vốn của công ty cổ phầnrất cao thông qua việc phát hành cổ phiếu ra công chúng, đây là đặc điểm riêng có của công ty cổ phần;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Việc chuyển nhượng vốn trong công ty cổ phần là tương đối dễ dàng, do vậy phạm vi đối tượng được tham gia công ty cổ phần là rất rộng, ngay cả các cán bộ công chức cũng có quyền mua cổ phiếu của công ty cổ phần.<br  /><strong><u>Nhược điểm:</u></strong><br  />Bên cạnh những lợi thế nêu trên, loại hình công ty cổ phần cũng có những hạn chế nhất định như.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Việc quản lý và điều hành công ty cổ phần rất phức tạp do số lượng các cổ đông có thể rất lớn, có nhiều người không hề quen biết nhau và thậm chí có thể có sự phân hóa thành các nhóm cổ động đối kháng nhau về lợi ích;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Việc thành lập và quản lý công ty cổ phần cũng phức tạp hơn các loại hình công ty khác do bị ràng buộc chặt chẽ bởi các quy định của pháp luật, đặc biệt về chế độ tài chính, kế toán.<br  />&nbsp;<br  /><strong>2. Công ty trách nhiệm hữu hạn 2 thành viên trở lên:</strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thành viên có thể là tổ chức, cá nhân; số lượng thành viên không vượt quá năm mươi;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thành viên chịu trách nhiệm về các khoản nợ và nghĩa vụ tài sản khác của doanh nghiệp trong phạm vi số vốn cam kết góp vào doanh nghiệp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phần vốn góp của thành viên được chuyển nhượng cho người khác (Phần vốn góp của thành viên được phép chuyển nhượng toàn bộ hoặc một phần cho các thành viên còn lại trong công ty hoặc cho người không phải là thành viên công ty nếu các thành viên còn lại của công ty không mua hoặc không mua hết. Thành viên công ty cũng có quyền yêu cầu công ty mua lại phần vốn góp của mình nếu không đồng ý với quyết định của Hội đồng thành viên về những vấn đề các vấn đề như sửa đổi, bổ sung Điều lệ công ty liên quan đến quyền và nghĩa vụ của thành viên, quyền và nhiệm vụ của Hội đồng thành viên; tổ chức lại công ty; và các trường hợp khác quy định tại Điều lệ công ty).<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty trách nhiệm hữu hạn không được quyền phát hành cổ phần.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty trách nhiệm hữu hạn có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh.<br  />&nbsp;<br  /><strong>3.Công ty trách nhiệm hữu hạn một thành viên:</strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty trách nhiệm hữu hạn một thành viên là doanh nghiệp do một tổ chức hoặc một cá nhân làm chủ sở hữu (gọi là chủ sở hữu công ty); chủ sở hữu công ty chịu trách nhiệm về các khoản nợ và nghĩa vụ tài sản khác của công ty trong phạm vi số vốn điều lệ của công ty.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty trách nhiệm hữu hạn một thành viên không được quyền phát hành cổ phần.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty trách nhiệm hữu hạn một thành viên có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh.<br  /><strong><u>Ưu điểm</u></strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Do có tư cách pháp nhân nên các thành viên công ty chỉ trách nhiệm về các hoạt động của công ty trong phạm vi số vốn góp vào công ty nên ít gây rủi ro cho người góp vốn;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Số lượng thành viên công ty trách nhiệm không nhiều và các thành viên thường là người quen biết, tin cậy nhau, nên việc quản lý, điều hành công ty không quá phức tạp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chế độ chuyển nhượng vốn được điều chỉnh chặt chẽ nên nhà đầu tư dễ dàng kiểm soát được việc thay đổi các thành viên, hạn chế sự thâm nhập của người lạ vào công ty.<br  /><strong><u>Nhược điểm:</u></strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Do chế độ trách nhiệm hữu hạn nên uy tín của công ty trước đối tác, bạn hàng cũng phần nào bị ảnh hưởng;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty trách nhiệm hữu hạn chịu sự điều chỉnh chặt chẽ của pháp luật hơn là doanh nghiệp tư nhân hay công ty hợp danh;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Việc huy động vốn của công ty trách nhiệm hữu hạn bị hạn chế do không có quyền phát hành cổ phiếu.<br  />&nbsp;<br  /><strong>4. Công ty hợp danh:</strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phải có ít nhất hai thành viên là chủ sở hữu chung của công ty, cùng nhau kinh doanh dưới một tên chung (gọi là thành viên hợp danh); ngoài các thành viên hợp danh có thể có thành viên góp vốn (thành viên góp vốn không được tham gia quản lý công ty và hoạt động kinh doanh nhân danh công ty);<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thành viên hợp danh phải là cá nhân, chịu trách nhiệm bằng toàn bộ tài sản của mình về các nghĩa vụ của công ty;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thành viên góp vốn chỉ chịu trách nhiệm về các khoản nợ của công ty trong phạm vi số vốn đã góp vào công ty.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty hợp danh không được phát hành bất kỳ loại chứng khoán nào.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty hợp danh có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh.<br  /><strong><u>Ưu điểm:</u></strong><br  />Ưu điểm của công ty hợp danh là kết hợp được uy tín cá nhân của nhiều người. Do chế độ liên đới chịu trách nhiệm vô hạn của các thành viên hợp danh mà công ty hợp danh dễ dàng tạo được sự tin cậy của các bạn hàng, đối tác kinh doanh. Việc điều hành quản lý công ty không quá phức tạp do số lượng các thành viên ít và là những người có uy tín, tuyệt đối tin tưởng nhau.<br  /><strong><u>Nhược điểm:</u></strong><br  />Hạn chế của công ty hợp danh là do chế độ liên đới chịu trách nhiệm vô hạn nên mức độ rủi ro của các thành viên hợp danh là rất cao.<br  />Loại hình công ty hợp danh được quy định trong Luật doanh nghiệp năm 1999 và 2005 nhưng trên thực tế loại hình doanh nghiệp này chưa phổ biến.<br  /><br  />&nbsp;<br  /><strong>5. Doanh nghiệp tư nhân:</strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Doanh nghiệp tư nhân là doanh nghiệp do một cá nhân làm chủ và tự chịu trách nhiệm bằng toàn bộ tài sản của mình về mọi hoạt động của doanh nghiệp.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Doanh nghiệp tư nhân không được phát hành bất kỳ loại chứng khoán nào.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mỗi cá nhân chỉ được quyền thành lập một doanh nghiệp tư nhân.<br  /><strong><u>Ưu điểm:</u></strong><br  />Do là chủ sở hữu duy nhất của doanh nghiệp nên doanh nghiệp tư nhân hoàn toàn chủ động trong việc quyết định các vấn đề liên quan đến hoạt động kinh doanh của Doanh nghiệp. Chế độ trách nhiệm vô hạn của chủ doanh nghiệp tư nhân tạo sự tin tưởng cho đối tác, khách hàng và giúp cho doanh nghiệp ít chịu sự ràng buộc chặt chẽ bởi pháp luật như các loại hình doanh nghiệp khác.<br  /><strong><u>Nhược điểm:</u></strong><br  />Do không có tư cách pháp nhân nên mức độ rủi ro của chủ doanh tư nhân cao, chủ doanh nghiệp tư nhân phải chịu trách nhiệm bằng toàn bộ tài sản của doanh nghiệp và của chủ doanh nghiệp chứ không giới hạn số vốn mà chủ doanh nghiệp đã đầu tư vào doanh nghiệp.<br  /><br  /><br  /><strong>6. Hợp tác xã.</strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hợp tác xã là tổ chức kinh tế tập thể do các cá nhân, hộ gia đình, pháp nhân (gọi chung là xã viên) có nhu cầu, lợi ích chung, tự nguyện góp vốn, góp sức lập ra theo quy định của Luật hợp tác xã để phát huy sức mạnh tập thể của từng xã viên tham gia hợp tác xã, cùng giúp nhau thực hiện có hiệu quả các hoạt động sản xuất, kinh doanh và nâng cao đời sống vật chất, tinh thần, góp phần phát triển kinh tế - xã hội của đất nước.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hợp tác xã là một loại hình doanh nghiệp đặc biệt, có tư cách pháp nhân, tự chủ, tự chịu trách nhiệm về các nghĩa vụ tài chính trong phạm vi vốn điều lệ, vốn tích luỹ và các nguồn vốn khác của hợp tác xã theo quy định của pháp luật. Nhưng ưu điểm, nhược điểm của Hợp tác xã.<br  /><strong><u>Ưu điểm</u></strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Có thể thu hút được đông đảo người lao động tham gia;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Việc quản lý hợp tác xã thực hiện trên nguyên tắc dân chủ và bình đẳng nên mọi xã viên đều bình đẳng trong việc tham gia quyết định các vấn đề liên quan đến hoạt động của hợp tác xã không phân biệt nhiều vốn hay ít vốn;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Các xã viên tham gia hợp tác xã chỉ chịu trách nhiệm trước các hoạt động của hợp tác xã trong phạm vi vốn góp vào hợp tác xã.<br  /><strong><u>Nhược điểm:</u></strong><br  />Hoạt động kinh doanh theo hình thức hợp tác xã cũng có những hạn chế nhất định như.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Không khuyến khích được người nhiều vốn;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nhiều kinh nghiệm quản lý, kinh doanh tham gia hợp tác xã do nguyên tắc chia lợi nhuận kết hợp lợi ích của xã viên với sự phát triển của hợp tác xã;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Việc quản lý hợp tác xã phức tạp do số lượng xã viên đông;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sở hữu manh mún của các xã viên đối tài sản của mình làm hạn chế các quyết định của Hợp tác xã.<br  />&nbsp;<br  />&nbsp;<br  />(Các quy định trên căn cứ theo Luật Doanh nghiệp được Quốc hội thông qua ngày 29/11/2005 có hiệu lực thi hành từ ngày 01/07/2006.)', '', 1, 0, 1, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_bodytext`
--

DROP TABLE IF EXISTS `nv3_vi_news_bodytext`;
CREATE TABLE `nv3_vi_news_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_bodytext`
--

INSERT INTO `nv3_vi_news_bodytext` VALUES
(16, 'Theo Khoản 1, Ðiều 50 Luật Ðầu tư thì nhà đầu tư nước ngoài lần đầu tiên đầu tư vào Việt Nam phải có dự án đầu tư và làm thủ tục đăng ký đầu tư hoặc thẩm tra dự án đầu tư tại cơ quan Nhà nước quản lý đầu tư để được cấp Giấy chứng nhận đầu tư. Giấy chứng nhận đầu tư đồng thời là Giấy chứng nhận đăng ký kinh doanh. 1. Các văn bản pháp luật tham khảo:- Biểu Cam kết dịch vụ WTO của Việt Nam.- Quyết định 10/2007/QÐ-BTM của Bộ Thương Mại ngày 21/05/2007 về Quyết định công bố lộ trình thực hiện hoạt động mua bán hàng hóa và các hoạt động liên quan trực tiếp đến mua bán hàng hóa.- Thông tư 09/2007/TT-BTM của Bộ Thương Mại ngày 17/07/2007 về Hướng dẫn thi hành Nghị định số 23/2007/NÐ-CP ngày 12 tháng 02 năm 2007 quy định chi tiết Luật Thương mại về hoạt động mua bán hàng hóa và các hoạt động liên quan trực tiếp đến mua bán hàng hóa của doanh nghiệp có vốn đầu tư nước ngoài tại Việt Nam.2. Hồ sơ xin cấp giấy phép thành lập Công ty:a. Văn bản đề nghị cấp Giấy chứng nhận đầu tư - theo mẫu I-3 của Quyết định 1088/2006/QÐ-BKH.b. Báo cáo năng lực tài chính của nhà đầu tư (do nhà đầu tư lập và chịu trách nhiệm).c. Giải trình khả năng đáp ứng điều kiện mà dự án đầu tư phải đáp ứng theo quy định của pháp luật.d. Hồ sơ pháp lý liên quan đến địa chỉ trụ sở chính và địa điểm thực hiện dự án (Nhà đầu tư chỉ mang đến để chuyên viên tiếp nhận hồ sơ xem và đối chiếu).e. Dự thảo Ðiều lệ Công ty tương ứng với từng loại hình doanh nghiệp (Công ty TNHH 2 thành viên trở lên, Công ty Cổ phần) (được người đại diện theo pháp luật, các thành viên hoặc người đại diện theo uỷ quyền ký từng trang). Danh sách thành viên sáng lập/ cổ đông sáng lập.f. Văn bản xác nhận tư cách pháp lý của các thành viên sáng lập: Ðối với thành viên sáng lập là pháp nhân: Bản sao hợp lệ có hợp pháp hóa lãnh sự (không quá 3 tháng trước ngày nộp hồ sơ) của một trong các loại giấy tờ: Quyết định thành lập, Giấy chứng nhận Ðăng ký kinh doanh hoặc Giấy tờ tương đương khác, Ðiều lệ (đối với pháp nhân trong nước). Ðối với thành viên sáng lập là cá nhân: Bản sao hợp lệ có hợp pháp hóa lãnh sự (bản sao có công chứng không quá 3 tháng trước ngày nộp hồ sơ) của một trong các giấy tờ: Giấy chứng minh nhân dân, Hộ chiếu hoặc giấy tờ chứng thực cá nhân hợp pháp còn hiệu lực. g. Văn bản uỷ quyền của Chủ sở hữu cho người được uỷ quyền đối với trường hợp chủ sở hữu công ty là tổ chức và Bản sao hợp lệ (bản sao có công chứng) một trong các giấy tờ chứng thực cá nhân của người đại diện theo uỷ quyền. h. Hợp đồng liên doanh đối với hình thức đầu tư thành lập tổ chức kinh tế liên doanh giữa nhà đầu tư trong nước và nhà đầu tư nước ngoài. (Tham khảo Ðiều 54, 55 Nghị định 108/2006/NÐ-CP ngày 22/09/2006). i. Trường hợp dự án đầu tư liên doanh có sử dụng vốn Nhà nước thì phải có văn bản chấp thuận việc sử dụng vốn Nhà nước để đầu tư của cơ quan có thẩm quyền. j. Bản sao hợp lệ chứng chỉ hành nghề của Giám đốc (Tổng Giám đốc) và các cá nhân khác quy định tại K.13 Ðiều 4 Luật Doanh nghiệp. 3. Hồ sơ nộp tại :a. Sở Kế hoạch và Ðầu tư phòng doanh nghiệp nước ngoài Phòng Doanh nghiệp nước ngoàib. Số lượng hồ sơ nộp: 8 bộ (trong đó có 1 bộ gốc) Mọi vấn đề còn thắc mắc liên quan đến thủ tục nói trên, xin Quý khách hàng vui lòng liên lạc với công ty chúng tôi để được cung cấp http://brandco.vn/?do=service&mod=category&show=search&kw=ch%E1%BB%A9ng%20nh%E1%BA%ADn%20%C4%91%E1%BA%A7u%20t%C6%B0 dịch vụ tư vấn thành lập công ty có vốn đầu tư nước ngoài tại Việt nam.'), 
(14, ' Là một nhà tư vấn chuyên nghiệp trong lĩnh vực tư vấn đầu tư, Công ty Luật Brandco hiện đang cung cấp nhiều các dịch vụ tư vấn đầu tư hỗ trợ Quý khách hàng, cụ thể: - Tư vấn đầu tư trong và ngoài nước: Tư vấn và giúp khách hàng lựa chọn các hình thức đầu tư tối ưu: đầu tư trực tiếp, đầu tư gián tiếp, thành lập các đơn vị sản xuất kinh doanh như : Thành lập Công ty Liên doanh; Thành lập Doanh nghiệp 100% vốn nước ngoài; Thành lập công ty cổ phần có vốn đầu tư nước ngoài; Hợp đồng hợp tác liên doanh; Lập dự án Đầu tư nước ngoài tại Việt Nam; Cung cấp thông tin về môi trường đầu tư tại Việt Nam; Điều tra vị trí đầu tư, đối tác, cung cấp dịch vụ Tư vấn chuyên nghiệp cho các Doanh nghiệp nước ngoài; Luật sư Đại diện tại Việt Nam cho doanh nghiệp đầu tư nước ngoài tại Việt Nam; Dự án đầu tư trong nước và đầu tư ra nước ngoài; Mở Văn phòng đại diện, chi nhánh công ty tại Việt nam và ở nước ngoài; Cơ cấu lại doanh nghiệp có vốn đầu tư nước ngoài tại Việt Nam; Giải thể, phá sản doanh nghiệp có vốn đầu tư nước ngoài tại ViệtNam; Hợp nhất, sáp nhập doanh nghiệp có vốn đầu tư nước ngoài tại ViệtNam;- Đại diện cho nhà đầu tư liên hệ với các cơ quan chức năng để triển khai Dự án; - Giới thiệu về những ưu đãi đầu tư trong các lĩnh vực, địa bàn đầu tư cũng như điều kiện để nhận được những ưu đãi đó. - Cung cấp các thông tin về các dự án gọi vốn đầu tư nước ngoài, bao gồm các thông tin chi tiết về các lĩnh vực, địa bàn đặc biệt khuyến khích đầu tư, các dự án có thể triển khai ngay. Những thông tin về những dự án quan trọng được cập nhật từ những cơ quan chức năng của Nhà nước Việt Nam. - Lập Hồ sơ xin đăng ký đầu tư và các ưu đãi đầu tư; - Lập Hồ sơ xin cấp Giấy phép đầu tư và các ưu đãi đầu tư; - Lập các Dự án chi tiết; - Dịch các tài liệu pháp lý liên quan đến Dự án đầu tư; - Tham gia đàm phán, xây dựng các Hợp đồng liên doanh, Hợp tác kinh doanh - Nhận sự uỷ quyền của các nhà đầu tư để liên hệ với các cơ quan chức năng Việt Nam hoàn thành các thủ tục đăng ký hoặc xin cấp phép đầu tư. Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với Tư vấn Luật Brandco để được hướng dẫn chi tiết. '), 
(15, '1. Điều kiện cấp Giấy phép thành lập Văn phòng đại diện1. Thương nhân nước ngoài được cấp Giấy phép thành lập Văn phòng đại diện tại Việt Nam khi có đủ các điều kiện sau:a) Là thương nhân được pháp luật nước, vùng lãnh thổ (sau đây gọi chung là nước) nơi thương nhân đó thành lập hoặc đăng ký kinh doanh công nhận hợp pháp;b) Đã hoạt động không dưới 01 năm, kể từ khi được thành lập hoặc đăng ký kinh doanh hợp pháp ở nước của thương nhân.2. Hồ sơ thành lập VPDD:Hồ sơ xin cấp giấy phép thành lập VPDD của Quý khách hàng sẽ gồm các giấy tờ sau đây:1) Đơn đề nghị cấp Giấy phép thành lập văn phòng đại diện bằng tiếng Việt Nam (theo mẫu của Bộ Thương mại) do đại diện có thẩm quyền của thương nhân nước ngoài ký;2) Bản sao Giấy đăng ký kinh doanh hoặc giấy tờ có giá trị tương đương của thương nhân nước ngoài được cơ quan có thẩm quyền nơi thương nhân nước ngoài thành lập xác nhận. Trong trường hợp Giấy đăng ký kinh doanh hoặc giấy tờ có giá trị tương đương có quy định thời hạn hoạt động của thương nhân nước ngoài thì thời hạn đó phải còn ít nhất là một năm;3) Báo cáo tài chính có kiểm toán hoặc tài liệu khác có giá trị tương đương chứng minh được sự tồn tại và hoạt động thực sự của thương nhân nước ngoài trong năm tài chính gần nhất;4) Bản sao Điều lệ hoạt động của thương nhân đối với thương nhân nước ngoài là các tổ chức kinh tế.5) Bản sao hộ chiếu hoặc giấy chứng minh nhân dân (nếu là người ViệtNam); bản sao hộ chiếu (nếu là người nước ngoài) của người đứng đầu văn phòng đại diện;6) Bản sao hợp đồng thuê địa điểm đặt trụ sở văn phòng đại diện.Các giấy tờ quy định tại điểm 2 và 3 được lập bằng tiếng nước nơi thương nhân đăng ký và phải dịch ra tiếng Việt, được cơ quan đại diện ngoại giao, cơ quan lãnh sự của Việt Nam ở nước sở tại chứng nhận và thực hiện việc hợp pháp hóa lãnh sự theo quy định của pháp luật Việt Nam. Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với Tư vấn Luật Brandco để được hướng dẫn chi tiết. '), 
(11, 'I- Lựa chọn ngành, nghề kinh doanh Doanh nghiệp có quyền kinh doanh tất cả các ngành mà pháp luật không cấm trừ kinh doanh các ngành, nghề gây phương hại đến quốc phòng, an ninh, trật tự, an toàn xã hội, truyền thống lịch sử, văn hóa, đạo đức, thuần phong mỹ tục Việt Nam và sức khỏe của nhân dân. Điều 7 của Luật Doanh nghiệp (Luật Doanh nghiệp năm 2005): 1. Doanh nghiệp thuộc mọi thành phần kinh tế có quyền kinh doanh các ngành, nghề mà pháp luật không cấm. 2. Đối với ngành, nghề mà pháp luật về đầu tư và pháp luật có liên quan quy định phải có điều kiện thì doanh nghiệp chỉ được kinh doanh ngành, nghề đó khi có đủ điều kiện theo quy định.Điều kiện kinh doanh là yêu cầu mà doanh nghiệp phải có hoặc phải thực hiện khi kinh doanh ngành, nghề cụ thể, được thể hiện bằng giấy phép kinh doanh, giấy chứng nhận đủ điều kiện kinh doanh, chứng chỉ hành nghề, chứng nhận bảo hiểm trách nhiệm nghề nghiệp, yêu cầu về vốn pháp định hoặc yêu cầu khác. 3. Cấm hoạt động kinh doanh gây phương hại đến quốc phòng, an ninh, trật tự, an toàn xã hội, truyền thống lịch sử, văn hoá, đạo đức, thuần phong mỹ tục Việt Nam và sức khoẻ của nhân dân, làm huỷ hoại tài nguyên, phá huỷ môi trường.Chính phủ quy định cụ thể danh mục ngành, nghề kinh doanh bị cấm. 4. Chính phủ định kỳ rà soát, đánh giá lại toàn bộ hoặc một phần các điều kiện kinh doanh; bãi bỏ hoặc kiến nghị bãi bỏ các điều kiện không còn phù hợp; sửa đổi hoặc kiến nghị sửa đổi các điều kiện bất hợp lý; ban hành hoặc kiến nghị ban hành điều kiện kinh doanh mới theo yêu cầu quản lý nhà nước. 5. Bộ, cơ quan ngang bộ, Hội đồng nhân dân và Uỷ ban nhân dân các cấp không được quy định về ngành, nghề kinh doanh có điều kiện và điều kiện kinh doanh. II- Quyền thành lập, góp vốn, mua cổ phần và quản lý doanh nghiệp: Điều 13 của Luật Doanh nghiệp (Luật Doanh nghiệp năm 2005): 1. Tổ chức, cá nhân Việt Nam, tổ chức, cá nhân nước ngoài có quyền thành lập và quản lý doanh nghiệp tại Việt Nam theo quy định của Luật này, trừ trường hợp quy định tại khoản 2 Điều này. 2. Tổ chức, cá nhân sau đây không được quyền thành lập và quản lý doanh nghiệp tại Việt Nam: a) Cơ quan nhà nước, đơn vị lực lượng vũ trang nhân dân Việt Nam sử dụng tài sản nhà nước để thành lập doanh nghiệp kinh doanh thu lợi riêng cho cơ quan, đơn vị mình; b) Cán bộ, công chức theo quy định của pháp luật về cán bộ, công chức; c) Sĩ quan, hạ sĩ quan, quân nhân chuyên nghiệp, công nhân quốc phòng trong các cơ quan, đơn vị thuộc Quân đội nhân dân Việt Nam; sĩ quan, hạ sĩ quan chuyên nghiệp trong các cơ quan, đơn vị thuộc Công an nhân dân Việt Nam; d) Cán bộ lãnh đạo, quản lý nghiệp vụ trong các doanh nghiệp 100% vốn sở hữu nhà nước, trừ những người được cử làm đại diện theo uỷ quyền để quản lý phần vốn góp của Nhà nước tại doanh nghiệp khác; đ) Người chưa thành niên; người bị hạn chế năng lực hành vi dân sự hoặc bị mất năng lực hành vi dân sự; e) Người đang chấp hành hình phạt tù hoặc đang bị Toà án cấm hành nghề kinh doanh; g) Các trường hợp khác theo quy định của pháp luật về phá sản. 3. Tổ chức, cá nhân có quyền mua cổ phần của công ty cổ phần, góp vốn vào công ty trách nhiệm hữu hạn, công ty hợp danh theo quy định của Luật này, trừ trường hợp quy định tại khoản 4 Điều này. 4. Tổ chức, cá nhân sau đây không được mua cổ phần của công ty cổ phần, góp vốn vào công ty trách nhiệm hữu hạn, công ty hợp danh theo quy định của Luật này: a) Cơ quan nhà nước, đơn vị lực lượng vũ trang nhân dân Việt Nam sử dụng tài sản nhà nước góp vốn vào doanh nghiệp để thu lợi riêng cho cơ quan, đơn vị mình; b) Các đối tượng không được góp vốn vào doanh nghiệp theo quy định của pháp luật về cán bộ, công chức.III- Cách đặt tên của doanh nghiệp:(Tên của doanh nghiệp phải bảo đảm theo quy định tại Điều 31, 32, 33, 34 - Luật Doanh nghiệp năm 2005) Điều 31. Tên doanh nghiệp 1. Tên doanh nghiệp phải viết được bằng tiếng Việt, có thể kèm theo chữ số và ký hiệu, phải phát âm được và có ít nhất hai thành tố sau đây: a) Loại hình doanh nghiệp; b) Tên riêng. 2. Tên doanh nghiệp phải được viết hoặc gắn tại trụ sở chính, chi nhánh, văn phòng đại diện của doanh nghiệp. Tên doanh nghiệp phải được in hoặc viết trên các giấy tờ giao dịch, hồ sơ tài liệu và ấn phẩm do doanh nghiệp phát hành. 3. Căn cứ vào quy định tại Điều này và các điều 32, 33 và 34 của Luật này, cơ quan đăng ký kinh doanh có quyền từ chối chấp thuận tên dự kiến đăng ký của doanh nghiệp. Quyết định của cơ quan đăng ký kinh doanh là quyết định cuối cùng. Điều 32. Những điều cấm trong đặt tên doanh nghiệp 1. Đặt tên trùng hoặc tên gây nhầm lẫn với tên của doanh nghiệp đã đăng ký. 2. Sử dụng tên cơ quan nhà nước, đơn vị lực lượng vũ trang nhân dân, tên của tổ chức chính trị, tổ chức chính trị - xã hội, tổ chức chính trị xã hội - nghề nghiệp, tổ chức xã hội, tổ chức xã hội - nghề nghiệp để làm toàn bộ hoặc một phần tên riêng của doanh nghiệp, trừ trường hợp có sự chấp thuận của cơ quan, đơn vị hoặc tổ chức đó. 3. Sử dụng từ ngữ, ký hiệu vi phạm truyền thống lịch sử, văn hoá, đạo đức và thuần phong mỹ tục của dân tộc. Điều 33. Tên doanh nghiệp viết bằng tiếng nước ngoài và tên viết tắt của doanh nghiệp 1. Tên doanh nghiệp viết bằng tiếng nước ngoài là tên được dịch từ tên bằng tiếng Việt sang tiếng nước ngoài tương ứng. Khi dịch sang tiếng nước ngoài, tên riêng của doanh nghiệp có thể giữ nguyên hoặc dịch theo nghĩa tương ứng sang tiếng nước ngoài. 2. Tên bằng tiếng nước ngoài của doanh nghiệp được in hoặc viết với khổ chữ nhỏ hơn tên bằng tiếng Việt của doanh nghiệp tại cơ sở của doanh nghiệp hoặc trên các giấy tờ giao dịch, hồ sơ tài liệu và ấn phẩm do doanh nghiệp phát hành. 3. Tên viết tắt của doanh nghiệp được viết tắt từ tên bằng tiếng Việt hoặc tên viết bằng tiếng nước ngoài. Điều 34. Tên trùng và tên gây nhầm lẫn 1. Tên trùng là tên của doanh nghiệp yêu cầu đăng ký được viết và đọc bằng tiếng Việt hoàn toàn giống với tên của doanh nghiệp đã đăng ký. 2. Các trường hợp sau đây được coi là tên gây nhầm lẫn với tên của doanh nghiệp đã đăng ký: a) Tên bằng tiếng Việt của doanh nghiệp yêu cầu đăng ký được đọc giống như tên doanh nghiệp đã đăng ký; b) Tên bằng tiếng Việt của doanh nghiệp yêu cầu đăng ký chỉ khác tên doanh nghiệp đã đăng ký bởi ký hiệu “&”; c) Tên viết tắt của doanh nghiệp yêu cầu đăng ký trùng với tên viết tắt của doanh nghiệp đã đăng ký; d) Tên bằng tiếng nước ngoài của doanh nghiệp yêu cầu đăng ký trùng với tên bằng tiếng nước ngoài của doanh nghiệp đã đăng ký; đ) Tên riêng của doanh nghiệp yêu cầu đăng ký khác với tên riêng của doanh nghiệp đã đăng ký bởi số tự nhiên, số thứ tự hoặc các chữ cái tiếng Việt ngay sau tên riêng của doanh nghiệp đó, trừ trường hợp doanh nghiệp yêu cầu đăng ký là công ty con của doanh nghiệp đã đăng ký; e) Tên riêng của doanh nghiệp yêu cầu đăng ký khác với tên riêng của doanh nghiệp đã đăng ký bởi từ “tân” ngay trước hoặc “mới” ngay sau tên riêng của doanh nghiệp đã đăng ký; g) Tên riêng của doanh nghiệp yêu cầu đăng ký chỉ khác tên riêng của doanh nghiệp đã đăng ký bằng các từ “miền bắc”, “miền nam”, “miền trung”, “miền tây”, “miền đông” hoặc các từ có ý nghĩa tương tự, trừ trường hợp doanh nghiệp yêu cầu đăng ký là công ty con của doanh nghiệp đã đăng ký. Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với Tư vấn Luật Brandco để được hướng dẫn chi tiết.'), 
(12, 'A. Thủ tục thành lập doanh nghiệp: Để khởi sự kinh doanh theo quy định của pháp luật, các nhà đầu tư cần tiến hành thủ tục đăng ký kinh doanh để thành lập doanh nghiệp theo quy trình sau: 1. Đăng ký kinh doanh:Doanh nghiệp phải tiến hành nộp hồ sơ đăng ký kinh doanh của Công ty tạiSở kế hoạch và đầu tỉnh thành phố nơi doanh nghiệp đặt trụ sở chính; 2. Đăng ký con dấu pháp nhân:Sau khi có Giấy đăng ký kinh doanh Quý khách hàng phải tiến hành đăng ký sử dụng hợp pháp con dấu pháp nhân của doanh nghiệp tại cơ quan Công an tỉnh thành phố nơi doanh nghiệp đặt trụ sở chính; 3. Đăng ký mã số thuế:Quý khách hàng phải đăng ký sử dụng hợp pháp Mã số thuế, Mã số Hải quan của doanh nghiệp tại Cục Thuế tỉnh thành phố nơi doanh nghiệp đặt trụ sở chính; B. Các dịch vụ hỗ trợ của Công ty luật Brandco:Với tư cách của một nhà tư vấn tận tâm của Quý khách hàng, Công ty luật Brandco sẽ có các hỗ trợ quan trọng dành cho Quý khách hàng, cụ thể: I. Tư vấn, giải đáp các vướng mắc của nhà đầu tư: Tư vấn các vấn đề pháp lý liên quan đến quá trình thành lập, hoạt động, quản lý Doanh nghiệp; Tư vấn cơ cấu nhân sự trong công ty; Tư vấn về các hợp đồng trước khi đăng ký kinh doanh; Tư vấn về việc thiết lập văn bản ràng buộc giữa các thành viên/cổ đông trong công ty; Tư vấn hồ sơ, tài liệu chuẩn bị thành lập Doanh nghiệp; Tư vấn về chọn loại hình doanh nghiệp phù hợp với ngành nghề kinh doanh và quy mô của công ty; Tư vấn cách phân chia lợi nhuận của các thành viên; Tư vấn chi tiết về thủ tục mua hoá đơn lần đầu cho doanh nghiệp; Tư vấn về vốn đầu tư ban đầu, vốn pháp định, vốn điều lệ… Tư vấn cách đặt tên Doanh nghiệp, tên viết tắt phù hợp với nhu cầu và yêu cầu của hoạt động kinh doanh và tiến hành tra cứu tên doanh nghiệp; Tư vấn về đăng ký ngành nghề Đăng ký kinh doanh (lựa chọn, sắp xếp ngành nghề và dự tính ngành nghề kinh doanh sắp tới); Tư vấn những điều kiện trước khi thành lập, những điều kiện sau khi thành lập đối với nghành nghề đăng ký kinh doanh; Tư vấn chi tiết cho doanh nghiệp các vấn đề về thuế, các nghĩa vụ về tài chính sau khi đăng ký kinh doanh và quá trình hoạt động sản xuất kinh doanh ; Tư vấn về cơ cấu nhân sự, quyền hạn, nghĩa vụ của các thành viên/cổ đông trong công ty;II. Tư vấn, soạn thảo tài liệu hò sơ doanh nghiệp: Đơn đăng ký kinh doanh; Danh sách thành viên/cổ đông; Điều lệ công ty; Quyết định bổ nhiệm Kế toán trưởng; Sổ đăng ký thành viên/cổ dông sáng lập. Hợp đồng lao động_nếu có; Biên bản họp công ty về việc góp vốn của sáng lập viên; Giấy chứng nhận góp vốn cho các thành viên/cổ đông; Quyết định bổ nhiệm Giám đốc;III. Thực hiện dịch vụ tư vấn: Đại diện cho khách hàng trên phòng đăng ký kinh doanh của sở kế hoạch và đầu tư để nộp hồ sơ Thành lập Doanh nghiệp; Đại diện cho khách hàng để theo dõi hồ sơ của doanh nghiệp và nhận kết quả trả lời của Phòng đăng ký kinh doanh; Nhận kết quả là Giấy chứng nhận ĐKKD tại Phòng đăng ký kinh doanh; Đại diện tại cơ quan Công an để xin giấy phép sử dụng con dấu; Tiến hành thủ tục để làm con dấu cho Doanh nghiệp (dấu công ty, dấu chức danh, dấu đăng ký mã số thuế); Tiến hành thủ tục đăng ký mã số thuế và mã số hải quan cho doanh nghiệp; IV. Thời gian thực hiện dịch vụ:Thời gian để hoàn thiện thủ tục thành lập doanh nghiệp là 05 - 20 ngày làm việc. Tuy nhiên, thời gian nói trên có thể thay đổi theo yêu cầu của Quý khách hàng. Lưu ý: Trong quá trình thành lập Doanh nghiệp người đại diện theo pháp luật của doanh nghiệp phải 02 lần đến cơ quan đăng ký kinh doanh (1) để ký nhận giấy chứng nhận đăng ký kinh doanh (2) ký lấy dấu pháp nhân của doanh nghiệp)_khách hàng nhớ mang theo một trong hai giấy tờ: CMTND bản gốc hoặc Hộ Chiếu. C.Trách nhiệm của Công ty luật Brandco sau thành lập: Tư vấn chính sách thuế hiện hành liên quan đến hoạt động của doanh nghiệp; Tư vấn các vấn đề liên quan đến tổ chức và hoạt động của doanh nghiệp; Hướng dẫn thủ tục mua hóa đơn thuế Giá trị gia tăng; Tư vấn kê khai thuế; Tư vấn và hoàn thiện Bộ hồ sơ Nội bộ doanh nghiệp, bao gồm: Điều lệ Doanh nghiệp, Danh sách thành viên, Giấy chứng nhận Vốn góp, các Quyết định bổ nhiệm các chức danh quản lý của doanh nghiệp... Note: Đặc biệt, để đồng hành cùng sự phát triển của Cộng đồng doanh nhân Việt. Công ty Luật Brandco cam kết tư vấn miễn phí về chính sách pháp luật hiện hành liên quan đến hoạt động của Công ty 01 năm sau thành lập; Hãy để chúng tôi chuẩn hóa ý tưởng thành lập doanh nghiệp của bạn bằng cách cung cấp thông tin thành lập doanh nghiệp theo mẫu sau: http://www.camnangphapluat.com/Uploaded/admins/YEU%20CAU%20THONG%20TIN%20TL%20CA%20NHAN%20MOI.doc YEU CAU THONG TIN TL CA NHAN MOI.doc =========================Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với Công ty Luật Brandco để được hướng dẫn chi tiết.'), 
(13, 'Việc lựa chọn hình thức doanh nghiệp trước khi bắt đầu công việc kinh doanh là rất quan trọng, nó có ảnh hưởng không nhỏ tới sự tồn tại và phát triển của doanh nghiệp. Về cơ bản, những sự khác biệt tạo ra bởi loại hình doanh nghiệp là: (i) uy tín doanh nghiệp do thói quen tiêu dùng; (ii) khả năng huy động vốn; (iii) rủi ro đầu tư; (iv) tính phức tạp của thủ tục và các chi phí thành lập doanh nghiệp; (v) tổ chức quản lý doanh nghiệp. 1. Công ty cổ phần:- Vốn điều lệ được chia thành nhiều phần bằng nhau gọi là cổ phần (Công ty cổ phần phải có cổ phần phổ thông và có thể có cổ phần ưu đãi. Cổ phần ưu đãi gồm các loại như cổ phần ưu đãi biểu quyết, cổ phần ưu đãi cổ tức, cổ phần ưu đãi hoàn lại và cổ phần ưu đãi khác do Điều lệ công ty quy định);- Cổ đông có thể là tổ chức, cá nhân; số lượng cổ đông tối thiểu là ba và không hạn chế số lượng tối đa;- Cổ đông chỉ chịu trách nhiệm về các khoản nợ và nghĩa vụ tài sản khác của doanh nghiệp trong phạm vi số vốn đã góp vào doanh nghiệp;- Cổ đông có quyền tự do chuyển nhượng cổ phần của mình cho người khác, trừ trường hợp (Cổ đông sở hữu cổ phần ưu đãi biểu quyết không được chuyển nhượng cổ phần đó cho người khác; Trong thời hạn ba năm, kể từ ngày công ty được cấp Giấy chứng nhận đăng ký kinh doanh, cổ đông sáng lập có quyền tự do chuyển nhượng cổ phần phổ thông của mình cho cổ đông sáng lập khác nhưng chỉ được chuyển nhượng cổ phần phổ thông của mình cho người không phải là cổ đông sáng lập nếu được sự chấp thuận của Đại hội đồng cổ đông sau 3 năm mọi hạn chế đối với cổ đông sáng lập bị bãi bỏ).- Công ty cổ phần có quyền phát hành chứng khoán các loại để huy động vốn.- Công ty cổ phần có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh.Ưu điểm:- Chế độ trách nhiệm của công ty cổ phần là trách nhiệm hữu hạn, các cổ đông chỉ chịu trách nhiệm về nợ và các nghĩa vụ tài sản khác của công ty trong phạm vi vốn góp nên mức độ rủi do của các cổ đông không cao;- Khả năng hoạt động của công ty cổ phần rất rộng, trong hầu hết các lịch vực, ngành nghề;- Cơ cấu vốn của công ty cổ phần hết sức linh hoạt tạo điều kiện nhiều người cùng góp vốn vào công ty;- Khả năng huy động vốn của công ty cổ phầnrất cao thông qua việc phát hành cổ phiếu ra công chúng, đây là đặc điểm riêng có của công ty cổ phần;- Việc chuyển nhượng vốn trong công ty cổ phần là tương đối dễ dàng, do vậy phạm vi đối tượng được tham gia công ty cổ phần là rất rộng, ngay cả các cán bộ công chức cũng có quyền mua cổ phiếu của công ty cổ phần.Nhược điểm:Bên cạnh những lợi thế nêu trên, loại hình công ty cổ phần cũng có những hạn chế nhất định như.- Việc quản lý và điều hành công ty cổ phần rất phức tạp do số lượng các cổ đông có thể rất lớn, có nhiều người không hề quen biết nhau và thậm chí có thể có sự phân hóa thành các nhóm cổ động đối kháng nhau về lợi ích;- Việc thành lập và quản lý công ty cổ phần cũng phức tạp hơn các loại hình công ty khác do bị ràng buộc chặt chẽ bởi các quy định của pháp luật, đặc biệt về chế độ tài chính, kế toán. 2. Công ty trách nhiệm hữu hạn 2 thành viên trở lên:- Thành viên có thể là tổ chức, cá nhân; số lượng thành viên không vượt quá năm mươi;- Thành viên chịu trách nhiệm về các khoản nợ và nghĩa vụ tài sản khác của doanh nghiệp trong phạm vi số vốn cam kết góp vào doanh nghiệp;- Phần vốn góp của thành viên được chuyển nhượng cho người khác (Phần vốn góp của thành viên được phép chuyển nhượng toàn bộ hoặc một phần cho các thành viên còn lại trong công ty hoặc cho người không phải là thành viên công ty nếu các thành viên còn lại của công ty không mua hoặc không mua hết. Thành viên công ty cũng có quyền yêu cầu công ty mua lại phần vốn góp của mình nếu không đồng ý với quyết định của Hội đồng thành viên về những vấn đề các vấn đề như sửa đổi, bổ sung Điều lệ công ty liên quan đến quyền và nghĩa vụ của thành viên, quyền và nhiệm vụ của Hội đồng thành viên; tổ chức lại công ty; và các trường hợp khác quy định tại Điều lệ công ty).- Công ty trách nhiệm hữu hạn không được quyền phát hành cổ phần.- Công ty trách nhiệm hữu hạn có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh. 3.Công ty trách nhiệm hữu hạn một thành viên:- Công ty trách nhiệm hữu hạn một thành viên là doanh nghiệp do một tổ chức hoặc một cá nhân làm chủ sở hữu (gọi là chủ sở hữu công ty); chủ sở hữu công ty chịu trách nhiệm về các khoản nợ và nghĩa vụ tài sản khác của công ty trong phạm vi số vốn điều lệ của công ty.- Công ty trách nhiệm hữu hạn một thành viên không được quyền phát hành cổ phần.- Công ty trách nhiệm hữu hạn một thành viên có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh.Ưu điểm- Do có tư cách pháp nhân nên các thành viên công ty chỉ trách nhiệm về các hoạt động của công ty trong phạm vi số vốn góp vào công ty nên ít gây rủi ro cho người góp vốn;- Số lượng thành viên công ty trách nhiệm không nhiều và các thành viên thường là người quen biết, tin cậy nhau, nên việc quản lý, điều hành công ty không quá phức tạp;- Chế độ chuyển nhượng vốn được điều chỉnh chặt chẽ nên nhà đầu tư dễ dàng kiểm soát được việc thay đổi các thành viên, hạn chế sự thâm nhập của người lạ vào công ty.Nhược điểm:- Do chế độ trách nhiệm hữu hạn nên uy tín của công ty trước đối tác, bạn hàng cũng phần nào bị ảnh hưởng;- Công ty trách nhiệm hữu hạn chịu sự điều chỉnh chặt chẽ của pháp luật hơn là doanh nghiệp tư nhân hay công ty hợp danh;- Việc huy động vốn của công ty trách nhiệm hữu hạn bị hạn chế do không có quyền phát hành cổ phiếu. 4. Công ty hợp danh:- Phải có ít nhất hai thành viên là chủ sở hữu chung của công ty, cùng nhau kinh doanh dưới một tên chung (gọi là thành viên hợp danh); ngoài các thành viên hợp danh có thể có thành viên góp vốn (thành viên góp vốn không được tham gia quản lý công ty và hoạt động kinh doanh nhân danh công ty);- Thành viên hợp danh phải là cá nhân, chịu trách nhiệm bằng toàn bộ tài sản của mình về các nghĩa vụ của công ty;- Thành viên góp vốn chỉ chịu trách nhiệm về các khoản nợ của công ty trong phạm vi số vốn đã góp vào công ty.- Công ty hợp danh không được phát hành bất kỳ loại chứng khoán nào.- Công ty hợp danh có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh.Ưu điểm:Ưu điểm của công ty hợp danh là kết hợp được uy tín cá nhân của nhiều người. Do chế độ liên đới chịu trách nhiệm vô hạn của các thành viên hợp danh mà công ty hợp danh dễ dàng tạo được sự tin cậy của các bạn hàng, đối tác kinh doanh. Việc điều hành quản lý công ty không quá phức tạp do số lượng các thành viên ít và là những người có uy tín, tuyệt đối tin tưởng nhau.Nhược điểm:Hạn chế của công ty hợp danh là do chế độ liên đới chịu trách nhiệm vô hạn nên mức độ rủi ro của các thành viên hợp danh là rất cao.Loại hình công ty hợp danh được quy định trong Luật doanh nghiệp năm 1999 và 2005 nhưng trên thực tế loại hình doanh nghiệp này chưa phổ biến. 5. Doanh nghiệp tư nhân:- Doanh nghiệp tư nhân là doanh nghiệp do một cá nhân làm chủ và tự chịu trách nhiệm bằng toàn bộ tài sản của mình về mọi hoạt động của doanh nghiệp.- Doanh nghiệp tư nhân không được phát hành bất kỳ loại chứng khoán nào.- Mỗi cá nhân chỉ được quyền thành lập một doanh nghiệp tư nhân.Ưu điểm:Do là chủ sở hữu duy nhất của doanh nghiệp nên doanh nghiệp tư nhân hoàn toàn chủ động trong việc quyết định các vấn đề liên quan đến hoạt động kinh doanh của Doanh nghiệp. Chế độ trách nhiệm vô hạn của chủ doanh nghiệp tư nhân tạo sự tin tưởng cho đối tác, khách hàng và giúp cho doanh nghiệp ít chịu sự ràng buộc chặt chẽ bởi pháp luật như các loại hình doanh nghiệp khác.Nhược điểm:Do không có tư cách pháp nhân nên mức độ rủi ro của chủ doanh tư nhân cao, chủ doanh nghiệp tư nhân phải chịu trách nhiệm bằng toàn bộ tài sản của doanh nghiệp và của chủ doanh nghiệp chứ không giới hạn số vốn mà chủ doanh nghiệp đã đầu tư vào doanh nghiệp.6. Hợp tác xã.- Hợp tác xã là tổ chức kinh tế tập thể do các cá nhân, hộ gia đình, pháp nhân (gọi chung là xã viên) có nhu cầu, lợi ích chung, tự nguyện góp vốn, góp sức lập ra theo quy định của Luật hợp tác xã để phát huy sức mạnh tập thể của từng xã viên tham gia hợp tác xã, cùng giúp nhau thực hiện có hiệu quả các hoạt động sản xuất, kinh doanh và nâng cao đời sống vật chất, tinh thần, góp phần phát triển kinh tế - xã hội của đất nước.- Hợp tác xã là một loại hình doanh nghiệp đặc biệt, có tư cách pháp nhân, tự chủ, tự chịu trách nhiệm về các nghĩa vụ tài chính trong phạm vi vốn điều lệ, vốn tích luỹ và các nguồn vốn khác của hợp tác xã theo quy định của pháp luật. Nhưng ưu điểm, nhược điểm của Hợp tác xã.Ưu điểm- Có thể thu hút được đông đảo người lao động tham gia;- Việc quản lý hợp tác xã thực hiện trên nguyên tắc dân chủ và bình đẳng nên mọi xã viên đều bình đẳng trong việc tham gia quyết định các vấn đề liên quan đến hoạt động của hợp tác xã không phân biệt nhiều vốn hay ít vốn;- Các xã viên tham gia hợp tác xã chỉ chịu trách nhiệm trước các hoạt động của hợp tác xã trong phạm vi vốn góp vào hợp tác xã.Nhược điểm:Hoạt động kinh doanh theo hình thức hợp tác xã cũng có những hạn chế nhất định như.- Không khuyến khích được người nhiều vốn;- Nhiều kinh nghiệm quản lý, kinh doanh tham gia hợp tác xã do nguyên tắc chia lợi nhuận kết hợp lợi ích của xã viên với sự phát triển của hợp tác xã;- Việc quản lý hợp tác xã phức tạp do số lượng xã viên đông;- Sở hữu manh mún của các xã viên đối tài sản của mình làm hạn chế các quyết định của Hợp tác xã. (Các quy định trên căn cứ theo Luật Doanh nghiệp được Quốc hội thông qua ngày 29/11/2005 có hiệu lực thi hành từ ngày 01/07/2006.)');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_cat`
--

DROP TABLE IF EXISTS `nv3_vi_news_cat`;
CREATE TABLE `nv3_vi_news_cat` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `titlesite` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '',
  `thumbnail` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=42  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_cat`
--

INSERT INTO `nv3_vi_news_cat` VALUES
(23, 0, 'Dịch vụ doanh nghiệp', '', 'Dich-vu-doanh-nghiep', '', '', '', 1, 1, 0, 'viewcat_page_new', 3, '31,32,33', 1, 3, '', '', 1351406131, 1351406131, 0, ''), 
(24, 0, 'Sở hữu trí tuệ', '', 'So-huu-tri-tue', '', '', '', 2, 5, 0, 'viewcat_page_new', 3, '34,35,36', 1, 3, '', '', 1351406152, 1351406152, 0, ''), 
(25, 0, 'Dịch vụ tư vấn', '', 'Dich-vu-tu-van', '', '', '', 3, 9, 0, 'viewcat_page_new', 3, '37,38,39', 1, 3, '', '', 1351406167, 1351406167, 0, ''), 
(26, 0, 'Dịch vụ tài chính', '', 'Dich-vu-tai-chinh', '', '', '', 4, 13, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406212, 1351406212, 0, ''), 
(27, 0, 'Thông tin pháp luật', '', 'Thong-tin-phap-luat', '', '', '', 5, 14, 0, 'viewcat_page_new', 2, '40,41', 1, 3, '', '', 1351406250, 1351406250, 0, ''), 
(28, 0, 'Hỏi đáp pháp luật', '', 'Hoi-dap-phap-luat', '', '', '', 6, 17, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406268, 1351406268, 0, ''), 
(29, 0, 'Kiến thức', '', 'Kien-thuc', '', '', '', 7, 18, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406338, 1351406338, 0, ''), 
(30, 0, 'Thư giãn', '', 'Thu-gian', '', '', '', 8, 19, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406349, 1351406349, 0, ''), 
(31, 23, 'Đăng ký kinh doanh', '', 'Dang-ky-kinh-doanh', '', '', '', 1, 2, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406442, 1351406442, 0, ''), 
(32, 23, 'Đăng ký đầu tư', '', 'Dang-ky-dau-tu', '', '', '', 2, 3, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406477, 1351406477, 0, ''), 
(33, 23, 'Tổ chức doanh nghệp', '', 'To-chuc-doanh-nghep', '', '', '', 3, 4, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406501, 1351406501, 0, ''), 
(34, 24, 'Dịch vụ đăng ký bảo hộ', '', 'Dich-vu-dang-ky-bao-ho', '', '', '', 1, 6, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406546, 1351406546, 0, ''), 
(35, 24, 'Dịch vụ xử lý vi phạm SHTT', '', 'Dich-vu-xu-ly-vi-pham-SHTT', '', '', '', 2, 7, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406577, 1351406577, 0, ''), 
(36, 24, 'Li xăng và nhượng quyền', '', 'Li-xang-va-nhuong-quyen', '', '', '', 3, 8, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406625, 1351406625, 0, ''), 
(37, 25, 'Dịch vụ luật sư', '', 'Dich-vu-luat-su', '', '', '', 1, 10, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406749, 1351406749, 0, ''), 
(38, 25, 'Dịch vụ xin giấy phép', '', 'Dich-vu-xin-giay-phep', '', '', '', 2, 11, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406775, 1351406775, 0, ''), 
(39, 25, 'Hướng dẫn thủ tục', '', 'Huong-dan-thu-tuc', '', '', '', 3, 12, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406794, 1351406794, 0, ''), 
(40, 27, 'Văn bản mới', '', 'Van-ban-moi', '', '', '', 1, 15, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406829, 1351406829, 0, ''), 
(41, 27, 'Tin tức pháp luật', '', 'Tin-tuc-phap-luat', '', '', '', 2, 16, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406850, 1351406850, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_comments`
--

DROP TABLE IF EXISTS `nv3_vi_news_comments`;
CREATE TABLE `nv3_vi_news_comments` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `post_time` (`post_time`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_config_post`
--

DROP TABLE IF EXISTS `nv3_vi_news_config_post`;
CREATE TABLE `nv3_vi_news_config_post` (
  `pid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `member` tinyint(4) NOT NULL,
  `group_id` mediumint(9) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `member` (`member`,`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_rows`
--

DROP TABLE IF EXISTS `nv3_vi_news_rows`;
CREATE TABLE `nv3_vi_news_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=17  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_rows`
--

INSERT INTO `nv3_vi_news_rows` VALUES
(16, 32, '23,32', 0, 1, '', 0, 1351421861, 1351421861, 1, 1351421861, 0, 2, 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 'Tu-van-xin-chung-nhan-dau-tu-thanh-lap-cong-ty-lien-doanh-cong-ty-100-von-dau-tu-nuoc-ngoai-ve-phan-phoi', 'BRANDCO LAWFIRM - Công ty Luật Brandco  tự hào là công ty hàng đầu trong lĩnh vực tư vấn đầu tư và cung cấp các dịch vụ hỗ trợ các nhà đầu tư tại việt nam như: tư vấn thành lập doanh nghiệp liên doanh, công ty 100% vốn nước ngoài, tư vấn lập dự án đầu tư (dự án tiền khả thi và dự án khả thi), tư vấn thủ tục xin ưu đãi đầu tư....', '2012_10/dau-tu.jpeg', '', 'thumb/dau-tu.jpeg.jpg|block/dau-tu.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'công ty,tự hào,hàng đầu,lĩnh vực,tư vấn,hỗ trợ,thành lập,doanh nghiệp,liên doanh,dự án,khả thi,thủ tục'), 
(15, 32, '23,32', 0, 1, '', 0, 1351421742, 1351421742, 1, 1351421742, 0, 2, 'Thành lập văn phòng đại diên của doanh nghiệp nước ngoài&#33;&#33;&#33;', 'Thanh-lap-van-phong-dai-dien-cua-doanh-nghiep-nuoc-ngoai', 'BRANDCO -  Sau sự kiện Việt Nam tham gia vào WTO ngày càng có nhiều thương nhân nước ngoài đến Việt Nam để tìm hiểu môi trường đầu tư, xúc tiến các hoạt động kinh doanh. Là nhà tư vấn chuyên nghiệp trong lĩnh vực doanh nghiệp – thương mại – kinh tế, công ty luật  Brandco xin cung cấp tới quý khách hàng  về điều kiện cấp phép thành lập văn phòng đại diện của thương nhân nước ngoài tại Việt Nam.', '2012_10/vanphongdaidien.jpg', '', 'thumb/vanphongdaidien.jpg|block/vanphongdaidien.jpg', 1, 2, 1, 0, 0, 0, 0, 'sự kiện,tham gia,ngày càng,tìm hiểu,môi trường,xúc tiến,hoạt động,kinh doanh,tư vấn,lĩnh vực,doanh nghiệp,thương mại,kinh tế,công ty,quý khách,thành lập,văn phòng,đại diện'), 
(14, 32, '23,32', 0, 1, '', 0, 1351421497, 1351421554, 1, 1351421497, 0, 2, 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 'Cong-ty-luat-Brandco-Xin-giay-phep-dau-tu', 'BRANDCO - Công ty Luật Brandco  tự hào là công ty hàng đầu trong lĩnh vực tư vấn đầu tư và cung cấp các dịch vụ hỗ trợ các nhà đầu tư tại việt nam như: tư vấn thành lập doanh nghiệp liên doanh, công ty 100% vốn nước ngoài, tư vấn lập dự án đầu tư (dự án tiền khả thi và dự án khả thi), tư vấn thủ tục xin ưu đãi đầu tư....', '2012_10/dau-tu.jpg', '', 'thumb/dau-tu.jpg|block/dau-tu.jpg', 1, 2, 1, 0, 0, 0, 0, 'công ty,tự hào,hàng đầu,lĩnh vực,tư vấn,hỗ trợ,thành lập,doanh nghiệp,liên doanh,dự án,khả thi,thủ tục'), 
(12, 31, '23,31', 0, 1, '', 0, 1351421031, 1351421613, 1, 1351421031, 0, 2, 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Cong-ty-luat-Brandco-Dich-vu-thanh-lap-doanh-nghiep', 'BRANDCO -  Là nhà tư vấn chuyên nghiệp trong lĩnh vực tư vấn đầu tư và tư vấn sở hữu trí tuệ, với nhiều năm kinh nghiệm phục vụ khách hàng, Công ty luật Brandco xin được giới thiệu tới rộng rãi các nhà đầu tư dịch vụ tư vấn thành lập doanh nghiệp do Công ty luật Brandco cung cấp.', '2012_10/dkkd.jpeg', '', 'thumb/dkkd.jpeg.jpg|block/dkkd.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'tư vấn,lĩnh vực,sở hữu,trí tuệ,kinh nghiệm,phục vụ,khách hàng,công ty,giới thiệu,rộng rãi,thành lập,doanh nghiệp'), 
(13, 31, '23,31', 0, 1, '', 0, 1351421252, 1351421641, 1, 1351421252, 0, 2, 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 'Cong-ty-luat-Brandco-Dac-diem-cua-cac-loai-hinh-cac-loai-hinh-doanh-nghiep', 'BRANDCO - Để giúp các bạn khởi sự kinh doanh nhanh chóng và thuận lợi. Brandco xin cung cấp cho quý khách hàng một số kiến thức về sự khác nhau giữa các loại hình doanh nghiệp, để quý khách có được sự lựa chọn tốt nhất', '2012_10/doanh-nghiep.jpeg', '', 'thumb/doanh-nghiep.jpeg.jpg|block/doanh-nghiep.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'khởi sự,kinh doanh,nhanh chóng,thuận lợi,quý khách,kiến thức,loại hình,doanh nghiệp'), 
(11, 31, '23,31', 0, 1, '', 0, 1351408478, 1351421539, 1, 1351408478, 0, 2, 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Nhung-van-de-can-luu-y-khi-thuc-hien-thu-tuc-dang-ky-kinh-doanh', 'BRANDCO - Để giúp các bạn khởi sự kinh doanh nhanh chóng và thuận lợi. Brandco xin cung cấp cho quý khách hàng một số vấn đề cần lưu ý khi thực hiện thủ tục đăng ký doanh nghiệp theo Luật Doanh nghiệp năm 2005.', 'nangly.jpg', '', 'thumb/nangly.jpg|block/nangly.jpg', 1, 2, 1, 1, 0, 5, 1, 'khởi sự,kinh doanh,nhanh chóng,thuận lợi,quý khách,vấn đề,lưu ý,thực hiện,thủ tục,đăng ký,doanh nghiệp');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_sources`
--

DROP TABLE IF EXISTS `nv3_vi_news_sources`;
CREATE TABLE `nv3_vi_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_sources`
--

INSERT INTO `nv3_vi_news_sources` VALUES
(1, 'Báo Hà Nội Mới', 'http://hanoimoi.com.vn', '', 1, 1274989177, 1274989177), 
(2, 'VINADES.,JSC', '', 'http://vinades.vn', 2, 1274989787, 1274989787), 
(3, 'NukeViet', '', 'http://nukeviet.vn', 2, 1274989787, 1274989787), 
(4, 'Báo điện tử Dân Trí', 'http://dantri.com.vn', '', 3, 1322685396, 1322685396);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_topics`
--

DROP TABLE IF EXISTS `nv3_vi_news_topics`;
CREATE TABLE `nv3_vi_news_topics` (
  `topicid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_topics`
--

INSERT INTO `nv3_vi_news_topics` VALUES
(1, 'NukeViet 3', 'NukeViet-3', '', '', 'NukeViet 3', 1, 'NukeViet 3', 1274990212, 1274990212);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_referer_stats`
--

DROP TABLE IF EXISTS `nv3_vi_referer_stats`;
CREATE TABLE `nv3_vi_referer_stats` (
  `host` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_searchkeys`
--

DROP TABLE IF EXISTS `nv3_vi_searchkeys`;
CREATE TABLE `nv3_vi_searchkeys` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `keys` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50) NOT NULL,
  KEY `id` (`id`),
  KEY `keys` (`keys`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_1`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_1`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_2`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_2`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_3`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_3`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_3` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_4`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_4`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_4` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_5`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_5`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_5` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_6`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_6`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_6` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_7`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_7`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_7` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_8`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_8`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_8` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_admins`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_admins`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_admins` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `comment` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_block`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_block`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_block_cat`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_block_cat`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `number` mediumint(4) NOT NULL DEFAULT '10',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_bodyhtml_1`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_bodyhtml_1`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_bodytext`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_bodytext`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_cat`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_cat`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_cat` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `titlesite` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '',
  `thumbnail` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=9  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_thu_vien_van_ban_cat`
--

INSERT INTO `nv3_vi_thu_vien_van_ban_cat` VALUES
(1, 0, 'Pháp luật kinh doanh', '', 'Phap-luat-kinh-doanh', '', '', '', 1, 1, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351407734, 1351407734, 0, ''), 
(2, 0, 'Pháp luật Sở hữu trí tuệ', '', 'Phap-luat-So-huu-tri-tue', '', '', '', 2, 2, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351407753, 1351407763, 0, ''), 
(3, 0, 'Pháp luật dân sự', '', 'Phap-luat-dan-su', '', '', '', 3, 3, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351407776, 1351407776, 0, ''), 
(4, 0, 'Pháp luật đất đai', '', 'Phap-luat-dat-dai', '', '', '', 4, 4, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351407798, 1351407808, 0, ''), 
(5, 0, 'Pháp luật Hình sự', '', 'Phap-luat-Hinh-su', '', '', '', 5, 5, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351407849, 1351407849, 0, ''), 
(6, 0, 'Pháp luật Hành chính', '', 'Phap-luat-Hanh-chinh', '', '', '', 6, 6, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351407860, 1351407860, 0, ''), 
(7, 0, 'Pháp luật Lao động', '', 'Phap-luat-Lao-dong', '', '', '', 7, 7, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351407872, 1351407872, 0, ''), 
(8, 0, 'Điều ước Quốc tế', '', 'Dieu-uoc-Quoc-te', '', '', '', 8, 8, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351407881, 1351407881, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_comments`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_comments`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_comments` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `post_time` (`post_time`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_config_post`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_config_post`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_config_post` (
  `pid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `member` tinyint(4) NOT NULL,
  `group_id` mediumint(9) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `member` (`member`,`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_rows`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_rows`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_sources`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_sources`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_thu_vien_van_ban_topics`
--

DROP TABLE IF EXISTS `nv3_vi_thu_vien_van_ban_topics`;
CREATE TABLE `nv3_vi_thu_vien_van_ban_topics` (
  `topicid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_voting`
--

DROP TABLE IF EXISTS `nv3_vi_voting`;
CREATE TABLE `nv3_vi_voting` (
  `vid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL DEFAULT '',
  `acceptcm` int(2) NOT NULL DEFAULT '1',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL,
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_voting`
--

INSERT INTO `nv3_vi_voting` VALUES
(2, 'Bạn biết gì về NukeViet 3?', '', 1, 1, 0, '0', 1275318563, 0, 1), 
(3, 'Bạn quan tâm gì nhất ở mã nguồn mở?', '', 1, 1, 0, '0', 1275318589, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_voting_rows`
--

DROP TABLE IF EXISTS `nv3_vi_voting_rows`;
CREATE TABLE `nv3_vi_voting_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `hitstotal` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_voting_rows`
--

INSERT INTO `nv3_vi_voting_rows` VALUES
(5, 2, 'Một bộ sourcecode cho web hoàn toàn mới.', '', 0), 
(6, 2, 'Mã nguồn mở, sử dụng miễn phí.', '', 0), 
(7, 2, 'Sử dụng xHTML, CSS và hỗ trợ Ajax', '', 0), 
(8, 2, 'Tất cả các ý kiến trên', '', 0), 
(9, 3, 'Liên tục được cải tiến, sửa đổi bởi cả thế giới.', '', 1), 
(10, 3, 'Được sử dụng miễn phí không mất tiền.', '', 0), 
(11, 3, 'Được tự do khám phá, sửa đổi theo ý thích.', '', 0), 
(12, 3, 'Phù hợp để học tập, nghiên cứu vì được tự do sửa đổi theo ý thích.', '', 0), 
(13, 3, 'Tất cả các ý kiến trên', '', 0);