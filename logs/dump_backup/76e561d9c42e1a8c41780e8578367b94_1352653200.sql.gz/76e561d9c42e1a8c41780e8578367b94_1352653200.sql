-- NUKEVIET 3.0
-- Module: Database
-- http://www.nukeviet.vn
--
-- Host: localhost
-- Generation Time: November 12, 2012, 11:22 AM GMT
-- Server version: 5.5.25
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET SESSION `character_set_client`='utf8';
SET SESSION `character_set_results`='utf8';
SET SESSION `character_set_connection`='utf8';
SET SESSION `collation_connection`='utf8_general_ci';
SET NAMES 'utf8';
ALTER DATABASE DEFAULT CHARACTER SET `utf8` COLLATE `utf8_general_ci`;

--
-- Database: `db_noithatviet`
--


-- ---------------------------------------


--
-- Table structure for table `nv3_authors`
--

DROP TABLE IF EXISTS `nv3_authors`;
CREATE TABLE `nv3_authors` (
  `admin_id` mediumint(8) unsigned NOT NULL,
  `editor` varchar(100) NOT NULL,
  `lev` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `susp_reason` mediumtext NOT NULL,
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_authors`
--

INSERT INTO `nv3_authors` VALUES
(1, 'ckeditor', 1, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', 'acbbeb884b9182f0cfb282c10f7516c899445567', 1352698127, '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; rv:16.0) Gecko/20100101 Firefox/16.0');


-- ---------------------------------------


--
-- Table structure for table `nv3_authors_config`
--

DROP TABLE IF EXISTS `nv3_authors_config`;
CREATE TABLE `nv3_authors_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyname` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_banip`
--

DROP TABLE IF EXISTS `nv3_banip`;
CREATE TABLE `nv3_banip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_banners_click`
--

DROP TABLE IF EXISTS `nv3_banners_click`;
CREATE TABLE `nv3_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) unsigned NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15) NOT NULL,
  `click_country` varchar(10) NOT NULL,
  `click_browse_key` varchar(100) NOT NULL,
  `click_browse_name` varchar(100) NOT NULL,
  `click_os_key` varchar(100) NOT NULL,
  `click_os_name` varchar(100) NOT NULL,
  `click_ref` varchar(255) NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_banners_clients`
--

DROP TABLE IF EXISTS `nv3_banners_clients`;
CREATE TABLE `nv3_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(60) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  `uploadtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_banners_plans`
--

DROP TABLE IF EXISTS `nv3_banners_plans`;
CREATE TABLE `nv3_banners_plans` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `form` varchar(100) NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_banners_plans`
--

INSERT INTO `nv3_banners_plans` VALUES
(1, '', 'Quang cao giua trang', '', 'sequential', 510, 100, 1), 
(2, '', 'Quang cao trai', '', 'sequential', 190, 500, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_banners_rows`
--

DROP TABLE IF EXISTS `nv3_banners_rows`;
CREATE TABLE `nv3_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255) NOT NULL,
  `file_ext` varchar(100) NOT NULL,
  `file_mime` varchar(100) NOT NULL,
  `width` int(4) unsigned NOT NULL DEFAULT '0',
  `height` int(4) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255) NOT NULL,
  `click_url` varchar(255) NOT NULL,
  `file_name_tmp` varchar(255) NOT NULL,
  `file_alt_tmp` varchar(255) NOT NULL,
  `click_url_tmp` varchar(255) NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_banners_rows`
--

INSERT INTO `nv3_banners_rows` VALUES
(1, 'Bo ngoai giao', 2, 0, 'bongoaigiao.jpg', 'jpg', 'image/jpeg', 160, 54, '', 'http://www.mofa.gov.vn', '', '', '', 1351249594, 1351249594, 0, 0, 1, 1), 
(2, 'vinades', 2, 0, 'vinades.jpg', 'jpg', 'image/jpeg', 190, 454, '', 'http://vinades.vn', '', '', '', 1351249594, 1351249594, 0, 0, 1, 2), 
(3, 'Quang cao giua trang', 1, 0, 'webnhanh_vn.gif', 'gif', 'image/gif', 510, 65, '', 'http://webnhanh.vn', '', '', '', 1351249594, 1351249594, 0, 0, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_config`
--

DROP TABLE IF EXISTS `nv3_config`;
CREATE TABLE `nv3_config` (
  `lang` char(3) NOT NULL DEFAULT 'sys',
  `module` varchar(25) NOT NULL DEFAULT 'global',
  `config_name` varchar(30) NOT NULL DEFAULT '',
  `config_value` mediumtext NOT NULL,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_config`
--

INSERT INTO `nv3_config` VALUES
('sys', 'global', 'closed_site', '0'), 
('sys', 'global', 'site_keywords', 'NukeViet, portal, mysql, php'), 
('sys', 'global', 'site_phone', ''), 
('sys', 'global', 'site_lang', 'vi'), 
('sys', 'global', 'admin_theme', 'admin_full'), 
('sys', 'global', 'date_pattern', 'l, d-m-Y'), 
('sys', 'global', 'time_pattern', 'H&#x3A;i'), 
('sys', 'global', 'block_admin_ip', '0'), 
('sys', 'global', 'admfirewall', '0'), 
('sys', 'global', 'online_upd', '1'), 
('sys', 'global', 'statistic', '1'), 
('sys', 'global', 'dump_autobackup', '1'), 
('sys', 'global', 'dump_backup_ext', 'gz'), 
('sys', 'global', 'dump_backup_day', '30'), 
('sys', 'global', 'gfx_chk', '3'), 
('sys', 'global', 'file_allowed_ext', 'adobe,application,archives,audio,documents,flash,images,real,text,video,xml'), 
('sys', 'global', 'forbid_extensions', 'php,php3,php4,php5,phtml,inc'), 
('sys', 'global', 'forbid_mimes', ''), 
('sys', 'global', 'nv_max_size', '2097152'), 
('sys', 'global', 'upload_checking_mode', 'lite'), 
('sys', 'global', 'upload_logo', 'images/logo.png'), 
('sys', 'global', 'str_referer_blocker', '0'), 
('sys', 'global', 'getloadavg', '0'), 
('sys', 'global', 'mailer_mode', ''), 
('sys', 'global', 'smtp_host', 'smtp.gmail.com'), 
('sys', 'global', 'smtp_ssl', '1'), 
('sys', 'global', 'smtp_port', '465'), 
('sys', 'global', 'smtp_username', 'user@gmail.com'), 
('sys', 'global', 'smtp_password', 'userpass'), 
('sys', 'global', 'allowuserreg', '1'), 
('sys', 'global', 'allowuserlogin', '1'), 
('sys', 'global', 'allowloginchange', '0'), 
('sys', 'global', 'allowquestion', '1'), 
('sys', 'global', 'allowuserpublic', '0'), 
('sys', 'global', 'useactivate', '2'), 
('sys', 'global', 'allowmailchange', '1'), 
('sys', 'global', 'allow_sitelangs', 'vi'), 
('sys', 'global', 'allow_adminlangs', 'en,vi'), 
('sys', 'global', 'read_type', '0'), 
('sys', 'global', 'is_url_rewrite', '1'), 
('sys', 'global', 'rewrite_optional', '0'), 
('sys', 'global', 'rewrite_endurl', '/'), 
('sys', 'global', 'rewrite_exturl', '.html'), 
('sys', 'global', 'autocheckupdate', '1'), 
('sys', 'global', 'autologomod', ''), 
('sys', 'global', 'autologosize1', '50'), 
('sys', 'global', 'autologosize2', '40'), 
('sys', 'global', 'autologosize3', '30'), 
('sys', 'global', 'autoupdatetime', '24'), 
('sys', 'global', 'gzip_method', '1'), 
('sys', 'global', 'is_user_forum', '0'), 
('sys', 'global', 'openid_mode', '1'), 
('sys', 'global', 'authors_detail_main', '0'), 
('sys', 'global', 'spadmin_add_admin', '1'), 
('sys', 'global', 'openid_servers', 'yahoo,google,myopenid'), 
('sys', 'global', 'optActive', '0'), 
('sys', 'global', 'googleAnalyticsID', ''), 
('sys', 'global', 'googleAnalyticsSetDomainName', '0'), 
('sys', 'global', 'searchEngineUniqueID', ''), 
('sys', 'global', 'captcha_type', '0'), 
('sys', 'global', 'revision', '1758'), 
('sys', 'global', 'version', '3.4.01'), 
('vi', 'global', 'site_name', 'Nội thất Việt'), 
('vi', 'global', 'site_logo', 'images/logo.png'), 
('vi', 'global', 'site_description', 'NukeViet CMS 3.x Developed by VINADES.,JSC'), 
('vi', 'global', 'site_keywords', ''), 
('vi', 'global', 'site_theme', 'noithatviet'), 
('vi', 'global', 'site_home_module', 'home'), 
('vi', 'global', 'switch_mobi_des', '1'), 
('vi', 'global', 'disable_site_content', 'Vì lý do kỹ thuật website tạm ngưng hoạt động. Thành thật xin lỗi các bạn vì sự bất tiện này!'), 
('vi', 'kien-truc-360', 'st_links', '10'), 
('vi', 'news', 'homewidth', '100'), 
('vi', 'news', 'homeheight', '150'), 
('vi', 'news', 'blockwidth', '52'), 
('vi', 'news', 'blockheight', '75'), 
('vi', 'news', 'imagefull', '460'), 
('vi', 'news', 'setcomm', '2'), 
('vi', 'news', 'copyright', ''), 
('vi', 'news', 'showhometext', '1'), 
('vi', 'news', 'activecomm', '1'), 
('vi', 'news', 'emailcomm', '1'), 
('vi', 'news', 'timecheckstatus', '0'), 
('vi', 'news', 'config_source', '0'), 
('vi', 'kien-truc-360', 'indexfile', 'viewcat_two_column'), 
('sys', 'global', 'site_email', 'tvthanh88hp@gmail.com'), 
('sys', 'global', 'error_send_email', 'tvthanh88hp@gmail.com'), 
('sys', 'global', 'my_domains', 'localhost'), 
('sys', 'global', 'cookie_prefix', 'nv3c_Bxxcg'), 
('sys', 'global', 'session_prefix', 'nv3s_Ef1qcy'), 
('sys', 'global', 'site_timezone', 'byCountry'), 
('sys', 'global', 'statistics_timezone', 'Asia/Bangkok'), 
('sys', 'global', 'proxy_blocker', '0'), 
('sys', 'global', 'lang_multi', '1'), 
('sys', 'global', 'lang_geo', '0'), 
('sys', 'global', 'ftp_server', 'localhost'), 
('sys', 'global', 'ftp_port', '21'), 
('sys', 'global', 'ftp_user_name', ''), 
('sys', 'global', 'ftp_user_pass', ''), 
('sys', 'global', 'ftp_path', '/'), 
('sys', 'global', 'ftp_check_login', '0'), 
('vi', 'news', 'per_page', '20'), 
('vi', 'news', 'st_links', '10'), 
('vi', 'news', 'indexfile', 'viewcat_two_column'), 
('vi', 'news', 'auto_postcomm', '1'), 
('vi', 'kien-truc-360', 'per_page', '20'), 
('vi', 'kien-truc-360', 'emailcomm', '1'), 
('vi', 'kien-truc-360', 'timecheckstatus', '0'), 
('vi', 'kien-truc-360', 'activecomm', '1'), 
('vi', 'kien-truc-360', 'copyright', ''), 
('vi', 'kien-truc-360', 'showhometext', '1'), 
('vi', 'kien-truc-360', 'auto_postcomm', '1'), 
('vi', 'kien-truc-360', 'homewidth', '100'), 
('vi', 'kien-truc-360', 'homeheight', '150'), 
('vi', 'kien-truc-360', 'blockwidth', '52'), 
('vi', 'kien-truc-360', 'blockheight', '75'), 
('vi', 'kien-truc-360', 'imagefull', '460'), 
('vi', 'kien-truc-360', 'setcomm', '2'), 
('vi', 'kien-truc-360', 'config_source', '0'), 
('vi', 'tu-van-kien-truc', 'indexfile', 'viewcat_main_right'), 
('vi', 'tu-van-kien-truc', 'per_page', '20'), 
('vi', 'tu-van-kien-truc', 'st_links', '10'), 
('vi', 'tu-van-kien-truc', 'auto_postcomm', '1'), 
('vi', 'tu-van-kien-truc', 'homewidth', '100'), 
('vi', 'tu-van-kien-truc', 'homeheight', '150'), 
('vi', 'tu-van-kien-truc', 'blockwidth', '52'), 
('vi', 'tu-van-kien-truc', 'blockheight', '75'), 
('vi', 'tu-van-kien-truc', 'imagefull', '460'), 
('vi', 'tu-van-kien-truc', 'setcomm', '2'), 
('vi', 'tu-van-kien-truc', 'copyright', ''), 
('vi', 'tu-van-kien-truc', 'showhometext', '1'), 
('vi', 'tu-van-kien-truc', 'activecomm', '1'), 
('vi', 'tu-van-kien-truc', 'emailcomm', '1'), 
('vi', 'tu-van-kien-truc', 'timecheckstatus', '0'), 
('vi', 'tu-van-kien-truc', 'config_source', '0'), 
('vi', 'news', 'module_logo', 'images/logo.png'), 
('vi', 'news', 'structure_upload', 'Ym'), 
('vi', 'kien-truc-360', 'module_logo', 'images/logo.png'), 
('vi', 'kien-truc-360', 'structure_upload', 'Ym');


-- ---------------------------------------


--
-- Table structure for table `nv3_cronjobs`
--

DROP TABLE IF EXISTS `nv3_cronjobs`;
CREATE TABLE `nv3_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `interval` int(11) unsigned NOT NULL DEFAULT '0',
  `run_file` varchar(255) NOT NULL,
  `run_func` varchar(255) NOT NULL,
  `params` varchar(255) NOT NULL,
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vi_cron_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_cronjobs`
--

INSERT INTO `nv3_cronjobs` VALUES
(1, 1351249594, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1352719345, 1, 'Xóa các dòng ghi trạng thái online đã cũ trong CSDL'), 
(2, 1351249594, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1352698131, 1, 'Tự động lưu CSDL'), 
(3, 1351249594, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1352716162, 1, 'Xóa các file tạm trong thư mục tmp'), 
(4, 1351249594, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1352717421, 1, 'Xóa IP log files Xóa các file logo truy cập'), 
(5, 1351249594, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1352698131, 1, 'Xóa các file error_log quá hạn'), 
(6, 1351249594, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Gửi email các thông báo lỗi cho admin'), 
(7, 1351249594, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1352716162, 1, 'Xóa các referer quá hạn'), 
(8, 1351249594, 1440, 'siteDiagnostic_update.php', 'cron_siteDiagnostic_update', '', 0, 1, 1, 1352698131, 1, 'Cập nhật đánh giá site từ các máy chủ tìm kiếm'), 
(9, 1351249594, 60, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 1352716162, 1, 'Kiểm tra phiên bản NukeViet');


-- ---------------------------------------


--
-- Table structure for table `nv3_groups`
--

DROP TABLE IF EXISTS `nv3_groups`;
CREATE TABLE `nv3_groups` (
  `group_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `users` mediumtext NOT NULL,
  `public` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `title` (`title`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_ipcountry`
--

DROP TABLE IF EXISTS `nv3_ipcountry`;
CREATE TABLE `nv3_ipcountry` (
  `ip_from` int(11) unsigned NOT NULL,
  `ip_to` int(11) unsigned NOT NULL,
  `country` char(2) NOT NULL,
  `ip_file` smallint(5) unsigned NOT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `ip_from` (`ip_from`,`ip_to`),
  KEY `ip_file` (`ip_file`),
  KEY `country` (`country`),
  KEY `time` (`time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_ipcountry`
--

INSERT INTO `nv3_ipcountry` VALUES
(2130706432, 2130771967, 'ZZ', 127, 1351249640);


-- ---------------------------------------


--
-- Table structure for table `nv3_language`
--

DROP TABLE IF EXISTS `nv3_language`;
CREATE TABLE `nv3_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lang_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_language_file`
--

DROP TABLE IF EXISTS `nv3_language_file`;
CREATE TABLE `nv3_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `admin_file` varchar(255) NOT NULL DEFAULT '0',
  `langtype` varchar(50) NOT NULL,
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_logs`
--

DROP TABLE IF EXISTS `nv3_logs`;
CREATE TABLE `nv3_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10) NOT NULL,
  `module_name` varchar(150) NOT NULL,
  `name_key` varchar(255) NOT NULL,
  `note_action` text NOT NULL,
  `link_acess` varchar(255) NOT NULL,
  `userid` int(11) NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=493  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_logs`
--

INSERT INTO `nv3_logs` VALUES
(1, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351249645), 
(2, 'vi', 'themes', 'Thiết lập layout theme: \"phapluat2\"', '', '', 1, 1351249716), 
(3, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351249727), 
(4, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351263515), 
(5, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351263557), 
(6, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351263626), 
(7, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351263627), 
(8, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351263662), 
(9, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351264083), 
(10, 'vi', 'themes', 'Thêm block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1351264321), 
(11, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1351264340), 
(12, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351264350), 
(13, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1351264417), 
(14, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351264434), 
(15, 'vi', 'themes', 'Sửa block', 'Name : Menu', 'Name : Menu', 1, 1351264498), 
(16, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351264758), 
(17, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351264868), 
(18, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351265067), 
(19, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351265389), 
(20, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351267347), 
(21, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351267377), 
(22, 'vi', 'themes', 'Thêm block', 'Name : module block headline', 'Name : module block headline', 1, 1351267429), 
(23, 'vi', 'themes', 'Sửa block', 'Name : module block headline', 'Name : module block headline', 1, 1351267659), 
(24, 'vi', 'themes', 'Thêm block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1351270349), 
(25, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1351270362), 
(26, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351304992), 
(27, 'vi', 'themes', 'Sửa block', 'Name : Menu', 'Name : Menu', 1, 1351305051), 
(28, 'vi', 'themes', 'Thêm block', 'Name : global block category', 'Name : global block category', 1, 1351305191), 
(29, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351306295), 
(30, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351306548), 
(31, 'vi', 'themes', 'Thêm block', 'Name : global block topnews', 'Name : global block topnews', 1, 1351307263), 
(32, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351307891), 
(33, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351307979), 
(34, 'vi', 'themes', 'Thêm block', 'Name : global voting', 'Name : global voting', 1, 1351308143), 
(35, 'vi', 'themes', 'Thêm block', 'Name : global counter', 'Name : global counter', 1, 1351309000), 
(36, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351311914), 
(37, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351311931), 
(38, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351331211), 
(39, 'vi', 'modules', 'Thiết lập module mới shops\"', '', '', 1, 1351331256), 
(40, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1351331358), 
(41, 'vi', 'modules', 'Thứ tự module \"shops\"', '11 -> 3', '11 -> 3', 1, 1351331444), 
(42, 'vi', 'shops', 'log_add_catalog', 'id 1', 'id 1', 1, 1351331584), 
(43, 'vi', 'shops', 'log_add_catalog', 'id 2', 'id 2', 1, 1351331603), 
(44, 'vi', 'shops', 'log_add_catalog', 'id 3', 'id 3', 1, 1351331622), 
(45, 'vi', 'themes', 'Thêm block', 'Name : global block blocknews', 'Name : global block blocknews', 1, 1351333449), 
(46, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351333469), 
(47, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351333760), 
(48, 'vi', 'news', 'Thêm chuyên mục', 'Sản phẩm A', 'Sản phẩm A', 1, 1351336138), 
(49, 'vi', 'news', 'Thêm chuyên mục', 'Sản phẩm B', 'Sản phẩm B', 1, 1351336148), 
(50, 'vi', 'news', 'Thêm chuyên mục', 'Sản phẩm C', 'Sản phẩm C', 1, 1351336157), 
(51, 'vi', 'news', 'Thêm chuyên mục', 'Đối tác  A', 'Đối tác  A', 1, 1351344537), 
(52, 'vi', 'news', 'Thêm chuyên mục', 'Đối tác  B', 'Đối tác  B', 1, 1351344546), 
(53, 'vi', 'news', 'Thêm chuyên mục', 'Tuyển dụng  A', 'Tuyển dụng  A', 1, 1351344582), 
(54, 'vi', 'news', 'Thêm chuyên mục', 'Tuyển dụng  B', 'Tuyển dụng  B', 1, 1351344592), 
(55, 'vi', 'news', 'Thêm chuyên mục', 'Tuyển dụng  C', 'Tuyển dụng  C', 1, 1351344629), 
(56, 'vi', 'news', 'Thêm chuyên mục', 'Tuyển dụng  D', 'Tuyển dụng  D', 1, 1351344639), 
(57, 'vi', 'news', 'Thêm chuyên mục', 'Tuyển dụng  E', 'Tuyển dụng  E', 1, 1351344652), 
(58, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351344867), 
(59, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351344887), 
(60, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351394143), 
(61, 'vi', 'modules', 'Sửa module &ldquo;news&rdquo;', '', '', 1, 1351394927), 
(62, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1351394967), 
(63, 'vi', 'modules', 'Thứ tự module \"about\"', '11 -> 3', '11 -> 3', 1, 1351396596), 
(64, 'vi', 'modules', 'Thứ tự module \"about\"', '11 -> 1', '11 -> 1', 1, 1351396627), 
(65, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351399862), 
(66, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351399916), 
(67, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351400601), 
(68, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351400762), 
(69, 'vi', 'shops', 'log_edit_catalog', 'id 1', 'id 1', 1, 1351404894), 
(70, 'vi', 'shops', 'log_edit_catalog', 'id 2', 'id 2', 1, 1351405016), 
(71, 'vi', 'shops', 'log_edit_catalog', 'id 3', 'id 3', 1, 1351405052), 
(72, 'vi', 'shops', 'log_add_catalog', 'id 4', 'id 4', 1, 1351405323), 
(73, 'vi', 'shops', 'log_add_catalog', 'id 5', 'id 5', 1, 1351405353), 
(74, 'vi', 'shops', 'log_add_catalog', 'id 6', 'id 6', 1, 1351405369), 
(75, 'vi', 'shops', 'log_edit_catalog', 'id 3', 'id 3', 1, 1351405415), 
(76, 'vi', 'shops', 'log_edit_catalog', 'id 2', 'id 2', 1, 1351405429), 
(77, 'vi', 'shops', 'log_edit_catalog', 'id 6', 'id 6', 1, 1351405450), 
(78, 'vi', 'shops', 'log_add_catalog', 'id 7', 'id 7', 1, 1351405478), 
(79, 'vi', 'shops', 'log_add_catalog', 'id 8', 'id 8', 1, 1351405488), 
(80, 'vi', 'themes', 'Sửa block', 'Name : Lĩnh vực hoạt động', 'Name : Lĩnh vực hoạt động', 1, 1351405610), 
(81, 'vi', 'themes', 'Sửa block', 'Name : Thành viên', 'Name : Thành viên', 1, 1351405636), 
(82, 'vi', 'themes', 'Sửa block', 'Name : Thống kê', 'Name : Thống kê', 1, 1351405659), 
(83, 'vi', 'themes', 'Sửa block', 'Name : Thăm dò ý kiến', 'Name : Thăm dò ý kiến', 1, 1351405685), 
(84, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Sản phẩm C', 'Sản phẩm C', 1, 1351405946), 
(85, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Sản phẩm B', 'Sản phẩm B', 1, 1351405950), 
(86, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Sản phẩm A', 'Sản phẩm A', 1, 1351405954), 
(87, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Sản phẩm', 'Sản phẩm', 1, 1351405980), 
(88, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng  E', 'Tuyển dụng  E', 1, 1351405999), 
(89, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng  D', 'Tuyển dụng  D', 1, 1351406004), 
(90, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng  C', 'Tuyển dụng  C', 1, 1351406011), 
(91, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng  B', 'Tuyển dụng  B', 1, 1351406015), 
(92, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng  A', 'Tuyển dụng  A', 1, 1351406020), 
(93, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng', 'Tuyển dụng', 1, 1351406028), 
(94, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Đối tác  B', 'Đối tác  B', 1, 1351406044), 
(95, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Đối tác  A', 'Đối tác  A', 1, 1351406051), 
(96, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Đối tác', 'Đối tác', 1, 1351406063), 
(97, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tin công nghệ', 'Tin công nghệ', 1, 1351406071), 
(98, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Bản tin nội bộ', 'Bản tin nội bộ', 1, 1351406078), 
(99, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Thông cáo báo chí', 'Thông cáo báo chí', 1, 1351406083), 
(100, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tin tức', 'Tin tức', 1, 1351406102), 
(101, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ doanh nghiệp', 'Dịch vụ doanh nghiệp', 1, 1351406129), 
(102, 'vi', 'news', 'Thêm chuyên mục', 'Sở hữu trí tuệ', 'Sở hữu trí tuệ', 1, 1351406149), 
(103, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ tư vấn', 'Dịch vụ tư vấn', 1, 1351406165), 
(104, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ tài chính', 'Dịch vụ tài chính', 1, 1351406210), 
(105, 'vi', 'news', 'Thêm chuyên mục', 'Thông tin pháp luật', 'Thông tin pháp luật', 1, 1351406248), 
(106, 'vi', 'news', 'Thêm chuyên mục', 'Hỏi đáp pháp luật', 'Hỏi đáp pháp luật', 1, 1351406266), 
(107, 'vi', 'news', 'Thêm chuyên mục', 'Kiến thức', 'Kiến thức', 1, 1351406336), 
(108, 'vi', 'news', 'Thêm chuyên mục', 'Thư giãn', 'Thư giãn', 1, 1351406347), 
(109, 'vi', 'news', 'Thêm chuyên mục', 'Đăng ký kinh doanh', 'Đăng ký kinh doanh', 1, 1351406440), 
(110, 'vi', 'news', 'Thêm chuyên mục', 'Đăng ký đầu tư', 'Đăng ký đầu tư', 1, 1351406475), 
(111, 'vi', 'news', 'Thêm chuyên mục', 'Tổ chức doanh nghệp', 'Tổ chức doanh nghệp', 1, 1351406499), 
(112, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ đăng ký bảo hộ', 'Dịch vụ đăng ký bảo hộ', 1, 1351406544), 
(113, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ xử lý vi phạm SHTT', 'Dịch vụ xử lý vi phạm SHTT', 1, 1351406576), 
(114, 'vi', 'news', 'Thêm chuyên mục', 'Li xăng và nhượng quyền', 'Li xăng và nhượng quyền', 1, 1351406623), 
(115, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ luật sư', 'Dịch vụ luật sư', 1, 1351406748), 
(116, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ xin giấy phép', 'Dịch vụ xin giấy phép', 1, 1351406773), 
(117, 'vi', 'news', 'Thêm chuyên mục', 'Hướng dẫn thủ tục', 'Hướng dẫn thủ tục', 1, 1351406792), 
(118, 'vi', 'news', 'Thêm chuyên mục', 'Văn bản mới', 'Văn bản mới', 1, 1351406827), 
(119, 'vi', 'news', 'Thêm chuyên mục', 'Tin tức pháp luật', 'Tin tức pháp luật', 1, 1351406848), 
(120, 'vi', 'modules', 'Thêm module ảo \"shop\"', '', '', 1, 1351406929), 
(121, 'vi', 'modules', 'Thiết lập module mới shop\"', '', '', 1, 1351406940), 
(122, 'vi', 'modules', 'Sửa module &ldquo;shop&rdquo;', '', '', 1, 1351406956), 
(123, 'vi', 'modules', 'Xóa module \"shop\"', '', '', 1, 1351406981), 
(124, 'vi', 'users', 'log_add_user', 'userid 2', 'userid 2', 1, 1351407241), 
(125, 'vi', 'shops', 'log_del_catalog', 'id 1', 'id 1', 1, 1351407467), 
(126, 'vi', 'shops', 'log_del_catalog', 'id 8', 'id 8', 1, 1351407471), 
(127, 'vi', 'shops', 'log_del_catalog', 'id 7', 'id 7', 1, 1351407474), 
(128, 'vi', 'shops', 'log_del_catalog', 'id 6', 'id 6', 1, 1351407476), 
(129, 'vi', 'shops', 'log_del_catalog', 'id 5', 'id 5', 1, 1351407477), 
(130, 'vi', 'shops', 'log_del_catalog', 'id 4', 'id 4', 1, 1351407478), 
(131, 'vi', 'shops', 'log_del_catalog', 'id 3', 'id 3', 1, 1351407479), 
(132, 'vi', 'shops', 'log_del_catalog', 'id 2', 'id 2', 1, 1351407479), 
(133, 'vi', 'modules', 'Xóa module \"shops\"', '', '', 1, 1351407508), 
(134, 'vi', 'modules', 'Thêm module ảo \"thu_vien_van_ban\"', '', '', 1, 1351407578), 
(135, 'vi', 'modules', 'Thiết lập module mới thu-vien-van-ban\"', '', '', 1, 1351407590), 
(136, 'vi', 'modules', 'Sửa module &ldquo;thu-vien-van-ban&rdquo;', '', '', 1, 1351407614), 
(137, 'vi', 'modules', 'Thứ tự module \"thu-vien-van-ban\"', '11 -> 3', '11 -> 3', 1, 1351407641), 
(138, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật kinh doanh', 'Pháp luật kinh doanh', 1, 1351407732), 
(139, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật Sở hữu trí tuệ', 'Pháp luật Sở hữu trí tuệ', 1, 1351407751), 
(140, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật dân sự', 'Pháp luật dân sự', 1, 1351407774), 
(141, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật đất đai', 'Pháp luật đất đai', 1, 1351407797), 
(142, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật Hình sự', 'Pháp luật Hình sự', 1, 1351407847), 
(143, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật Hành chính', 'Pháp luật Hành chính', 1, 1351407858), 
(144, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật Lao động', 'Pháp luật Lao động', 1, 1351407870), 
(145, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Điều ước Quốc tế', 'Điều ước Quốc tế', 1, 1351407879), 
(146, 'vi', 'themes', 'Sửa block', 'Name : Lĩnh vực hoạt động', 'Name : Lĩnh vực hoạt động', 1, 1351407947), 
(147, 'vi', 'themes', 'Thêm block', 'Name : global block category', 'Name : global block category', 1, 1351407977), 
(148, 'vi', 'themes', 'Sửa block', 'Name : Thư viện văn bản', 'Name : Thư viện văn bản', 1, 1351408049), 
(149, 'vi', 'themes', 'Sửa block', 'Name : Lĩnh vực hoạt động', 'Name : Lĩnh vực hoạt động', 1, 1351408093), 
(150, 'vi', 'news', 'Thêm bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351408478), 
(151, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351408529), 
(152, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351408662), 
(153, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351408768), 
(154, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/logo1.jpg', 'uploads/news/2012_10/logo1.jpg', 1, 1351416669), 
(155, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/dkkd.jpeg', 'uploads/news/2012_10/dkkd.jpeg', 1, 1351417471), 
(156, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351417512), 
(157, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351419218), 
(158, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351419254), 
(159, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1351419579), 
(160, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1351419612), 
(161, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351419775), 
(162, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351419913), 
(163, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/thanhlapdoanhnghiep.jpeg', 'uploads/news/2012_10/thanhlapdoanhnghiep.jpeg', 1, 1351421000), 
(164, 'vi', 'news', 'Thêm bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 1, 1351421031), 
(165, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 1, 1351421089), 
(166, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/doanh-nghiep.jpeg', 'uploads/news/2012_10/doanh-nghiep.jpeg', 1, 1351421217), 
(167, 'vi', 'news', 'Thêm bài viết', 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 1, 1351421252), 
(168, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 1, 1351421316), 
(169, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351421331), 
(170, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/dau-tu.jpg', 'uploads/news/2012_10/dau-tu.jpg', 1, 1351421481), 
(171, 'vi', 'news', 'Thêm bài viết', 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 1, 1351421497), 
(172, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351421538), 
(173, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 1, 1351421553), 
(174, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 1, 1351421611), 
(175, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 1, 1351421640), 
(176, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/vanphongdaidien.jpg', 'uploads/news/2012_10/vanphongdaidien.jpg', 1, 1351421726), 
(177, 'vi', 'news', 'Thêm bài viết', 'Thành lập văn phòng đại diên của doanh nghiệp nước ngoài&#33;&#33;&#33;', 'Thành lập văn phòng đại diên của doanh nghiệp nước ngoài&#33;&#33;&#33;', 1, 1351421742), 
(178, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/dau-tu.jpeg', 'uploads/news/2012_10/dau-tu.jpeg', 1, 1351421845), 
(179, 'vi', 'news', 'Thêm bài viết', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 1, 1351421861), 
(180, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351436505), 
(181, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/to-chuc-doanh-nghiep.jpg', 'uploads/news/2012_10/to-chuc-doanh-nghiep.jpg', 1, 1351436696), 
(182, 'vi', 'news', 'Thêm bài viết', 'Tư vấn thành lập, tổ chức, quản lý doanh nghiệp theo mô hình tập đoàn kinh tế', 'Tư vấn thành lập, tổ chức, quản lý doanh nghiệp theo mô hình tập đoàn kinh tế', 1, 1351436724), 
(183, 'vi', 'news', 'Thêm bài viết', 'Tái cơ cấu&#x3A; Sáng tạo để tiếp tục đổi mới', 'Tái cơ cấu&#x3A; Sáng tạo để tiếp tục đổi mới', 1, 1351436786), 
(184, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351436835), 
(185, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351436853), 
(186, 'vi', 'news', 'Sửa bài viết', 'Tái cơ cấu&#x3A; Sáng tạo để tiếp tục đổi mới', 'Tái cơ cấu&#x3A; Sáng tạo để tiếp tục đổi mới', 1, 1351436888), 
(187, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351436953), 
(188, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 1, 1351437154), 
(189, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/hanggia.jpg', 'uploads/news/2012_10/hanggia.jpg', 1, 1351437264), 
(190, 'vi', 'news', 'Thêm bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ đăng ký bảo hộ quyền tác giả.', 'Công ty luật Brandco&#x3A; Dịch vụ đăng ký bảo hộ quyền tác giả.', 1, 1351437291), 
(191, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/sang-che.jpg', 'uploads/news/2012_10/sang-che.jpg', 1, 1351437397), 
(192, 'vi', 'news', 'Thêm bài viết', 'Công ty luật Brandco&#x3A; Đăng ký bảo hộ độc quyền sáng chế&#33;', 'Công ty luật Brandco&#x3A; Đăng ký bảo hộ độc quyền sáng chế&#33;', 1, 1351437427), 
(193, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/xemay.jpg', 'uploads/news/2012_10/xemay.jpg', 1, 1351437496), 
(194, 'vi', 'news', 'Thêm bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ Bảo hộ Kiểu dáng công nghiệp', 'Công ty luật Brandco&#x3A; Dịch vụ Bảo hộ Kiểu dáng công nghiệp', 1, 1351437554), 
(195, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/xulyviphamshtt.jpg', 'uploads/news/2012_10/xulyviphamshtt.jpg', 1, 1351437906), 
(196, 'vi', 'news', 'Thêm bài viết', 'Khiếu nại &amp; xử lý vi phạm quyền sở hữu trí tuệ', 'Khiếu nại &amp; xử lý vi phạm quyền sở hữu trí tuệ', 1, 1351437917), 
(197, 'vi', 'news', 'Sửa bài viết', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 1, 1351437970), 
(198, 'vi', 'news', 'Sửa bài viết', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 1, 1351438126), 
(199, 'vi', 'news', 'Sửa bài viết', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 1, 1351438316), 
(200, 'vi', 'news', 'Thêm bài viết', 'Tư vấn soạn thảo quy chế, nội quy lao động của doanh nghiệp', 'Tư vấn soạn thảo quy chế, nội quy lao động của doanh nghiệp', 1, 1351438502), 
(201, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351484422), 
(202, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/tu-van-hop-dong.jpeg', 'uploads/news/2012_10/tu-van-hop-dong.jpeg', 1, 1351484586), 
(203, 'vi', 'news', 'Thêm bài viết', 'Công ty Luật Brandco&#x3A; Dịch vụ tư vấn hợp đồng', 'Công ty Luật Brandco&#x3A; Dịch vụ tư vấn hợp đồng', 1, 1351484608), 
(204, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/dich-vu-thua-ke.jpg', 'uploads/news/2012_10/dich-vu-thua-ke.jpg', 1, 1351484677), 
(205, 'vi', 'news', 'Thêm bài viết', 'Tư vấn về thừa kế tài sản theo quy định của bộ luật dân sự', 'Tư vấn về thừa kế tài sản theo quy định của bộ luật dân sự', 1, 1351484700), 
(206, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/thuocla.jpg', 'uploads/news/2012_10/thuocla.jpg', 1, 1351484790), 
(207, 'vi', 'news', 'Thêm bài viết', 'Tư vấn xin giấy phép sản xuất thuốc lá', 'Tư vấn xin giấy phép sản xuất thuốc lá', 1, 1351484820), 
(208, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/dien1.jpg', 'uploads/news/2012_10/dien1.jpg', 1, 1351484881), 
(209, 'vi', 'news', 'Thêm bài viết', 'Tư vấn xin giấy phép hoạt động điện lực', 'Tư vấn xin giấy phép hoạt động điện lực', 1, 1351484905), 
(210, 'vi', 'news', 'Sửa bài viết', 'Tư vấn xin giấy phép hoạt động điện lực', 'Tư vấn xin giấy phép hoạt động điện lực', 1, 1351485525), 
(211, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/2004.bmp', 'uploads/news/2012_10/2004.bmp', 1, 1351485598), 
(212, 'vi', 'news', 'Thêm bài viết', 'Quy định về việc thu, nộp, quản lý và sử dụng phí bán đấu giá cổ phần', 'Quy định về việc thu, nộp, quản lý và sử dụng phí bán đấu giá cổ phần', 1, 1351485646), 
(213, 'vi', 'news', 'Thêm bài viết', 'Thủ tục thanh toán chi phí khám bệnh, chữa bệnh đối với người tham gia bảo hiểm y tế bị tai nạn giao thông', 'Thủ tục thanh toán chi phí khám bệnh, chữa bệnh đối với người tham gia bảo hiểm y tế bị tai nạn giao thông', 1, 1351485834), 
(214, 'vi', 'news', 'Thêm bài viết', 'Rút ngắn thời gian cấp Giấy miễn thị thực xuống 5 ngày', 'Rút ngắn thời gian cấp Giấy miễn thị thực xuống 5 ngày', 1, 1351485905), 
(215, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/1394335.jpg', 'uploads/news/2012_10/1394335.jpg', 1, 1351485962), 
(216, 'vi', 'news', 'Thêm bài viết', 'Hướng dẫn quyết toán thuế thu nhập cá nhân năm 2011', 'Hướng dẫn quyết toán thuế thu nhập cá nhân năm 2011', 1, 1351485981), 
(217, 'vi', 'news', 'Thêm bài viết', 'Phân biệt về dịch vụ Kê khai thuế qua mạng và Chữ ký số', 'Phân biệt về dịch vụ Kê khai thuế qua mạng và Chữ ký số', 1, 1351486200), 
(218, 'vi', 'news', 'Thêm bài viết', 'Khấu trừ, hoàn thuế GTGT đối với trường hợp Gđốc hoặc Tổng gđốc của Cty không được đồng thời làm Gđốc hoặc Tổng gđốc của DN khác', 'Khấu trừ, hoàn thuế GTGT đối với trường hợp Gđốc hoặc Tổng gđốc của Cty không được đồng thời làm Gđốc hoặc Tổng gđốc của DN khác', 1, 1351486248), 
(219, 'vi', 'news', 'Thêm bài viết', 'Từ 1&#x002F;1&#x002F;2012&#x3A; Cơ quan Thuế không bán hóa đơn cho doanh nghiệp', 'Từ 1&#x002F;1&#x002F;2012&#x3A; Cơ quan Thuế không bán hóa đơn cho doanh nghiệp', 1, 1351486288), 
(220, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/luongtoithieu.jpg', 'uploads/news/2012_10/luongtoithieu.jpg', 1, 1351497532), 
(221, 'vi', 'news', 'Thêm bài viết', 'Lương tối thiểu dự kiến tăng 35&#x25;', 'Lương tối thiểu dự kiến tăng 35&#x25;', 1, 1351498289), 
(222, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/03_dool_tt_091203_p4_1.jpg', 'uploads/news/2012_10/03_dool_tt_091203_p4_1.jpg', 1, 1351498350), 
(223, 'vi', 'news', 'Thêm bài viết', 'Miễn, giảm thuế sử dụng đất phi nông nghiệp', 'Miễn, giảm thuế sử dụng đất phi nông nghiệp', 1, 1351498364), 
(224, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/bat_dong_.jpg', 'uploads/news/2012_10/bat_dong_.jpg', 1, 1351498418), 
(225, 'vi', 'news', 'Thêm bài viết', 'Thuế TNDN từ chuyển nhượng bất động sản được xác định theo giá hợp đồng', 'Thuế TNDN từ chuyển nhượng bất động sản được xác định theo giá hợp đồng', 1, 1351498432), 
(226, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/htx.jpg', 'uploads/news/2012_10/htx.jpg', 1, 1351499026), 
(227, 'vi', 'news', 'Thêm bài viết', 'Không biến hợp tác xã thành mô hình tự cung tự cấp', 'Không biến hợp tác xã thành mô hình tự cung tự cấp', 1, 1351499047), 
(228, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/imagesca8lezqn.jpg', 'uploads/news/2012_10/imagesca8lezqn.jpg', 1, 1351499107), 
(229, 'vi', 'news', 'Thêm bài viết', 'Cơ chế giải quyết tranh chấp không rõ sẽ rất phức tạp', 'Cơ chế giải quyết tranh chấp không rõ sẽ rất phức tạp', 1, 1351499127), 
(230, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/images663125_ngan_hang_480.jpg', 'uploads/news/2012_10/images663125_ngan_hang_480.jpg', 1, 1351499199), 
(231, 'vi', 'news', 'Thêm bài viết', 'Lấp “lỗ hổng” lớn trong xử lý tội phạm thuế, tài chính', 'Lấp “lỗ hổng” lớn trong xử lý tội phạm thuế, tài chính', 1, 1351499221), 
(232, 'vi', 'news', 'Thêm bài viết', 'Doanh nghiệp nước ngoài tiếp tục than phiền về Nghị định 46', 'Doanh nghiệp nước ngoài tiếp tục than phiền về Nghị định 46', 1, 1351499374), 
(233, 'vi', 'news', 'Thêm bài viết', 'Nghị định 70&#x002F;2011&#x002F;NĐ-CP quy định mức lương tối thiểu vùng đối với người lao động', 'Nghị định 70&#x002F;2011&#x002F;NĐ-CP quy định mức lương tối thiểu vùng đối với người lao động', 1, 1351499425), 
(234, 'vi', 'news', 'Thêm bài viết', 'Cơ quan Thuế không bán hóa đơn cho doanh nghiệp', 'Cơ quan Thuế không bán hóa đơn cho doanh nghiệp', 1, 1351499616), 
(235, 'vi', 'news', 'Thêm bài viết', 'Dự thảo Luật Hợp tác xã &#40;sửa đổi&#41; - Băn khoăn về mức góp vốn và giới hạn quyền cung ứng sản phẩm, dịch vụ', 'Dự thảo Luật Hợp tác xã &#40;sửa đổi&#41; - Băn khoăn về mức góp vốn và giới hạn quyền cung ứng sản phẩm, dịch vụ', 1, 1351499674), 
(236, 'vi', 'news', 'Thêm bài viết', 'Trao đổi về phạm vi hòa giải ở cơ sở', 'Trao đổi về phạm vi hòa giải ở cơ sở', 1, 1351499772), 
(237, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/hang-20f1d.jpg', 'uploads/news/2012_10/hang-20f1d.jpg', 1, 1351499836), 
(238, 'vi', 'news', 'Thêm bài viết', 'Dựng lại tường lửa ngăn sở hữu chéo ngân hàng', 'Dựng lại tường lửa ngăn sở hữu chéo ngân hàng', 1, 1351499846), 
(239, 'vi', 'news', 'log_del_topic', 'topicid 1', 'topicid 1', 1, 1351500465), 
(240, 'vi', 'news', 'Thêm bài viết', 'Luật sư và người chăn lừa', 'Luật sư và người chăn lừa', 1, 1351501275), 
(241, 'vi', 'news', 'Thêm bài viết', 'Lý luận của luật sư', 'Lý luận của luật sư', 1, 1351501314), 
(242, 'vi', 'news', 'Thêm bài viết', 'Từ thị trường USD tự do nghĩ về chính sách tỷ giá', 'Từ thị trường USD tự do nghĩ về chính sách tỷ giá', 1, 1351501355), 
(243, 'vi', 'upload', 'Upload file', 'uploads/thu-vien-van-ban/2012_10/hoi-thao-thue.jpg', 'uploads/thu-vien-van-ban/2012_10/hoi-thao-thue.jpg', 1, 1351501561), 
(244, 'vi', 'thu-vien-van-ban', 'Thêm bài viết', 'Một số khoản chi được trừ khi xác định thu nhập chịu thuế Thu nhập doanh nghiệp theo nghị định 122&#x002F;2011&#x002F;NĐ-CP', 'Một số khoản chi được trừ khi xác định thu nhập chịu thuế Thu nhập doanh nghiệp theo nghị định 122&#x002F;2011&#x002F;NĐ-CP', 1, 1351501593), 
(245, 'vi', 'modules', 'Cài đặt gói Module + Block', 'nv3_module_home.zip', 'nv3_module_home.zip', 1, 1351505326), 
(246, 'vi', 'modules', 'Thiết lập module mới home\"', '', '', 1, 1351505334), 
(247, 'vi', 'modules', 'Sửa module &ldquo;home&rdquo;', '', '', 1, 1351505339), 
(248, 'vi', 'modules', 'Thứ tự module \"home\"', '12 -> 1', '12 -> 1', 1, 1351505347), 
(249, 'vi', 'modules', 'Sửa module &ldquo;home&rdquo;', '', '', 1, 1351505368), 
(250, 'vi', 'modules', 'Kích hoạt module \"home\"', 'Không', 'Không', 1, 1351505514), 
(251, 'vi', 'modules', 'Sửa module &ldquo;rss&rdquo;', '', '', 1, 1351506647), 
(252, 'vi', 'modules', 'Sửa module &ldquo;news&rdquo;', '', '', 1, 1351506780), 
(253, 'vi', 'modules', 'Thứ tự module \"news\"', '12 -> 1', '12 -> 1', 1, 1351506795), 
(254, 'vi', 'modules', 'Cài đặt gói Module + Block', 'nv3_module_archives.zip', 'nv3_module_archives.zip', 1, 1351506908), 
(255, 'vi', 'modules', 'Thiết lập module mới archives\"', '', '', 1, 1351506920), 
(256, 'vi', 'modules', 'Sửa module &ldquo;archives&rdquo;', '', '', 1, 1351506944), 
(257, 'vi', 'themes', 'Sửa block', 'Name : Xem nhiều nhất', 'Name : Xem nhiều nhất', 1, 1351507055), 
(258, 'vi', 'modules', 'Thứ tự module \"archives\"', '13 -> 3', '13 -> 3', 1, 1351507916), 
(259, 'vi', 'modules', 'Xóa module \"home\"', '', '', 1, 1351507998), 
(260, 'vi', 'modules', 'Thứ tự module \"about\"', '12 -> 2', '12 -> 2', 1, 1351508007), 
(261, 'vi', 'about', 'De-lete about', 'ID:  2', 'ID:  2', 1, 1351508023), 
(262, 'vi', 'about', 'Edit about', 'ID:  1', 'ID:  1', 1, 1351508155), 
(263, 'vi', 'about', 'Edit about', 'ID:  1', 'ID:  1', 1, 1351508229), 
(264, 'vi', 'archives', 'Thêm loại văn bản', 'Pháp luật kinh doanh', 'Pháp luật kinh doanh', 1, 1351509858), 
(265, 'vi', 'archives', 'Thêm văn bản', 'Thông tư số 05/2012/TT-BTC', 'Thông tư số 05/2012/TT-BTC', 1, 1351513411), 
(266, 'vi', 'archives', 'Thêm loại văn bản', 'Pháp luật Sở hữu trí tuệ', 'Pháp luật Sở hữu trí tuệ', 1, 1351513844), 
(267, 'vi', 'archives', 'Thêm loại văn bản', 'Pháp luật Hình sự', 'Pháp luật Hình sự', 1, 1351513861), 
(268, 'vi', 'archives', 'Thêm loại văn bản', 'Pháp luật dân sự', 'Pháp luật dân sự', 1, 1351513894), 
(269, 'vi', 'archives', 'Thêm loại văn bản', 'Pháp luật Lao động', 'Pháp luật Lao động', 1, 1351513913), 
(270, 'vi', 'archives', 'Thêm loại văn bản', 'Văn bản pháp luật khác', 'Văn bản pháp luật khác', 1, 1351513967), 
(271, 'vi', 'upload', 'Upload file', 'uploads/archives/2012_10/luat-canh-tranh-2004.doc', 'uploads/archives/2012_10/luat-canh-tranh-2004.doc', 1, 1351514680), 
(272, 'vi', 'archives', 'Thêm văn bản', 'LUAT CANH TRANH 2004', 'LUAT CANH TRANH 2004', 1, 1351515090), 
(273, 'vi', 'archives', '', '1', '1', 1, 1351515235), 
(274, 'vi', 'upload', 'Upload file', 'uploads/archives/2012_10/kinh-doanh-bat-dong-san.doc', 'uploads/archives/2012_10/kinh-doanh-bat-dong-san.doc', 1, 1351515429), 
(275, 'vi', 'archives', 'Thêm văn bản', 'KINH DOANH BẤT ĐỘNG SẢN', 'KINH DOANH BẤT ĐỘNG SẢN', 1, 1351515527), 
(276, 'vi', 'upload', 'Upload file', 'uploads/archives/2012_10/luat-dau-tu.doc', 'uploads/archives/2012_10/luat-dau-tu.doc', 1, 1351515818), 
(277, 'vi', 'archives', 'Thêm văn bản', 'LUẬT ĐẦU TƯ', 'LUẬT ĐẦU TƯ', 1, 1351515875), 
(278, 'vi', 'upload', 'Upload file', 'uploads/archives/2012_10/luat-so-huu-tri-tue-2005.doc', 'uploads/archives/2012_10/luat-so-huu-tri-tue-2005.doc', 1, 1351516231), 
(279, 'vi', 'archives', 'Thêm văn bản', 'Sở hữu trí tuệ', 'Sở hữu trí tuệ', 1, 1351516282), 
(280, 'vi', 'modules', 'Xóa module \"thu-vien-van-ban\"', '', '', 1, 1351516318), 
(281, 'vi', 'themes', 'Sửa block', 'Name : Lĩnh vực hoạt động', 'Name : Lĩnh vực hoạt động', 1, 1351516363), 
(282, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351517409), 
(283, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351842326), 
(284, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1352187732), 
(285, 'vi', 'themes', 'Kích hoạt theme: \"noithatviet\"', '', '', 1, 1352188067), 
(286, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1352188176), 
(287, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1352188205), 
(288, 'vi', 'themes', 'Thiết lập layout theme: \"noithatviet\"', '', '', 1, 1352188230), 
(289, 'vi', 'themes', 'Thiết lập layout theme: \"noithatviet\"', '', '', 1, 1352188300), 
(290, 'vi', 'themes', 'Kích hoạt theme: \"noithatviet\"', '', '', 1, 1352188306), 
(291, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1352190181), 
(292, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1352192069), 
(293, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1352192703), 
(294, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1352193719), 
(295, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1352193753), 
(296, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1352193888), 
(297, 'vi', 'themes', 'Kích hoạt theme: \"noithatviet\"', '', '', 1, 1352195032), 
(298, 'vi', 'themes', 'Thêm block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1352195774), 
(299, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1352196128), 
(300, 'vi', 'themes', 'Kích hoạt theme: \"noithatviet\"', '', '', 1, 1352196167), 
(301, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1352197107), 
(302, 'vi', 'themes', 'Kích hoạt theme: \"noithatviet\"', '', '', 1, 1352198161), 
(303, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1352200820), 
(304, 'vi', 'themes', 'Kích hoạt theme: \"noithatviet\"', '', '', 1, 1352200846), 
(305, 'vi', 'themes', 'Kích hoạt theme: \"phapluat2\"', '', '', 1, 1352203466), 
(306, 'vi', 'themes', 'Kích hoạt theme: \"noithatviet\"', '', '', 1, 1352203713), 
(307, 'vi', 'themes', 'Kích hoạt theme: \"noithatviet\"', '', '', 1, 1352203715), 
(308, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1352367756), 
(309, 'vi', 'modules', 'Cài lại module \"news\"', '', '', 1, 1352373265), 
(310, 'vi', 'modules', 'Cài lại module \"news\"', '', '', 1, 1352373280), 
(311, 'vi', 'modules', 'Thiết lập module mới shops\"', '', '', 1, 1352380729), 
(312, 'vi', 'modules', 'Sửa module &ldquo;news&rdquo;', '', '', 1, 1352380889), 
(313, 'vi', 'modules', 'Sửa module &ldquo;news&rdquo;', '', '', 1, 1352380939), 
(314, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1352381160), 
(315, 'vi', 'modules', 'Thêm module ảo \"thiet_ke_noi_that\"', '', '', 1, 1352381228), 
(316, 'vi', 'modules', 'Thiết lập module mới thiet-ke-noi-that\"', '', '', 1, 1352381237), 
(317, 'vi', 'modules', 'Sửa module &ldquo;thiet-ke-noi-that&rdquo;', '', '', 1, 1352381258), 
(318, 'vi', 'modules', 'Xóa module \"thiet-ke-noi-that\"', '', '', 1, 1352382087), 
(319, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1352382172), 
(320, 'vi', 'shops', 'log_add_catalog', 'id 1', 'id 1', 1, 1352382226), 
(321, 'vi', 'shops', 'log_add_catalog', 'id 2', 'id 2', 1, 1352382244), 
(322, 'vi', 'shops', 'log_add_catalog', 'id 3', 'id 3', 1, 1352382266), 
(323, 'vi', 'shops', 'log_add_catalog', 'id 4', 'id 4', 1, 1352382308), 
(324, 'vi', 'shops', 'log_add_catalog', 'id 5', 'id 5', 1, 1352382346), 
(325, 'vi', 'modules', 'Thứ tự module \"shops\"', '12 -> 3', '12 -> 3', 1, 1352382395), 
(326, 'vi', 'modules', 'Thứ tự module \"news\"', '12 -> 2', '12 -> 2', 1, 1352382430), 
(327, 'vi', 'modules', 'Cài đặt gói Module + Block', 'nv3_module_home.zip', 'nv3_module_home.zip', 1, 1352382803), 
(328, 'vi', 'modules', 'Thiết lập module mới home\"', '', '', 1, 1352382864), 
(329, 'vi', 'modules', 'Sửa module &ldquo;home&rdquo;', '', '', 1, 1352382870), 
(330, 'vi', 'modules', 'Thứ tự module \"home\"', '13 -> 1', '13 -> 1', 1, 1352382882), 
(331, 'vi', 'modules', 'Sửa module &ldquo;home&rdquo;', '', '', 1, 1352382938), 
(332, 'vi', 'modules', 'Sửa module &ldquo;news&rdquo;', '', '', 1, 1352383001), 
(333, 'vi', 'modules', 'Xóa module \"home\"', '', '', 1, 1352383250), 
(334, 'vi', 'modules', 'Thiết lập module mới home\"', '', '', 1, 1352384266), 
(335, 'vi', 'modules', 'Sửa module &ldquo;home&rdquo;', '', '', 1, 1352384276), 
(336, 'vi', 'modules', 'Thứ tự module \"home\"', '13 -> 1', '13 -> 1', 1, 1352384314), 
(337, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1352453654), 
(338, 'vi', 'themes', 'Thêm block', 'Name : global about', 'Name : global about', 1, 1352454196), 
(339, 'vi', 'themes', 'Thêm block', 'Name : global block category', 'Name : global block category', 1, 1352455268), 
(340, 'vi', 'themes', 'Sửa block', 'Name : global block category', 'Name : global block category', 1, 1352455832), 
(341, 'vi', 'themes', 'Sửa block', 'Name : global block category', 'Name : global block category', 1, 1352456086), 
(342, 'vi', 'themes', 'Sửa block', 'Name : global block category', 'Name : global block category', 1, 1352456507), 
(343, 'vi', 'themes', 'Thêm block', 'Name : global block catalogs2', 'Name : global block catalogs2', 1, 1352456621), 
(344, 'vi', 'themes', 'Sửa block', 'Name : global block catalogs2', 'Name : global block catalogs2', 1, 1352456648), 
(345, 'vi', 'themes', 'Thêm block', 'Name : module block catepro', 'Name : module block catepro', 1, 1352458686), 
(346, 'vi', 'upload', 'Upload file', 'uploads/shops/2012_11/untitled-12.jpg', 'uploads/shops/2012_11/untitled-12.jpg', 1, 1352459035), 
(347, 'vi', 'shops', 'log_add_product', 'id 1', 'id 1', 1, 1352459076), 
(348, 'vi', 'themes', 'Thêm block', 'Name : module block catepro', 'Name : module block catepro', 1, 1352459386), 
(349, 'vi', 'themes', 'Thêm block', 'Name : module block catepro', 'Name : module block catepro', 1, 1352459459), 
(350, 'vi', 'shops', 'log_edit_product', 'id 1', 'id 1', 1, 1352459487), 
(351, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1352542341), 
(352, 'vi', 'shops', 'log_add_product', 'id 2', 'id 2', 1, 1352545808), 
(353, 'vi', 'shops', 'log_add_product', 'id 3', 'id 3', 1, 1352545847), 
(354, 'vi', 'shops', 'log_add_product', 'id 4', 'id 4', 1, 1352545875), 
(355, 'vi', 'shops', 'log_add_product', 'id 5', 'id 5', 1, 1352545903), 
(356, 'vi', 'shops', 'log_edit_product', 'id 3', 'id 3', 1, 1352545929), 
(357, 'vi', 'shops', 'log_edit_product', 'id 3', 'id 3', 1, 1352545967), 
(358, 'vi', 'shops', 'log_edit_product', 'id 2', 'id 2', 1, 1352545995), 
(359, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1352606607), 
(360, 'vi', 'themes', 'Sửa block', 'Name : module block catepro', 'Name : module block catepro', 1, 1352606778), 
(361, 'vi', 'themes', 'Thêm block', 'Name : module block catepro', 'Name : module block catepro', 1, 1352607691), 
(362, 'vi', 'themes', 'Thêm block', 'Name : module block catepro', 'Name : module block catepro', 1, 1352607843), 
(363, 'vi', 'themes', 'Sửa block', 'Name : module block catepro', 'Name : module block catepro', 1, 1352607867), 
(364, 'vi', 'shops', 'log_edit_product', 'id 5', 'id 5', 1, 1352607932), 
(365, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', 1, 1352608097), 
(366, 'vi', 'upload', 'Upload file', 'uploads/shops/2012_11/293807_433695250020473_590873335_n.jpg', 'uploads/shops/2012_11/293807_433695250020473_590873335_n.jpg', 1, 1352609324), 
(367, 'vi', 'shops', 'log_add_product', 'id 6', 'id 6', 1, 1352609333), 
(368, 'vi', 'shops', 'log_add_product', 'id 7', 'id 7', 1, 1352613809), 
(369, 'vi', 'shops', 'log_add_product', 'id 8', 'id 8', 1, 1352613880), 
(370, 'vi', 'shops', 'log_add_product', 'id 9', 'id 9', 1, 1352613925), 
(371, 'vi', 'shops', 'log_add_catalog', 'id 6', 'id 6', 1, 1352614172), 
(372, 'vi', 'shops', 'log_add_product', 'id 10', 'id 10', 1, 1352614217), 
(373, 'vi', 'themes', 'Sửa block', 'Name : module block catepro', 'Name : module block catepro', 1, 1352614256), 
(374, 'vi', 'shops', 'Cấu hình module', 'setting', 'setting', 1, 1352614342), 
(375, 'vi', 'themes', 'Thêm block', 'Name : module block catepro', 'Name : module block catepro', 1, 1352615697), 
(376, 'vi', 'themes', 'Thiết lập layout theme: \"noithatviet\"', '', '', 1, 1352615863), 
(377, 'vi', 'themes', 'Thiết lập layout theme: \"noithatviet\"', '', '', 1, 1352616686), 
(378, 'vi', 'news', 'Thêm chuyên mục', 'Tin tức pháp luật', 'Tin tức pháp luật', 1, 1352616792), 
(379, 'vi', 'news', 'Thêm chuyên mục', 'tin tuc noi that', 'tin tuc noi that', 1, 1352616818), 
(380, 'vi', 'news', 'Thêm bài viết', 'ádsdasd', 'ádsdasd', 1, 1352616880), 
(381, 'vi', 'themes', 'Thiết lập layout theme: \"noithatviet\"', '', '', 1, 1352616996), 
(382, 'vi', 'themes', 'Thiết lập layout theme: \"noithatviet\"', '', '', 1, 1352617101), 
(383, 'vi', 'themes', 'Thiết lập layout theme: \"noithatviet\"', '', '', 1, 1352617987), 
(384, 'vi', 'shops', 'Cấu hình module', 'setting', 'setting', 1, 1352619310), 
(385, 'vi', 'modules', 'Xóa module \"news\"', '', '', 1, 1352623023), 
(386, 'vi', 'modules', 'Xóa module \"archives\"', '', '', 1, 1352623162), 
(387, 'vi', 'shops', 'Cấu hình module', 'setting', 'setting', 1, 1352623223), 
(388, 'vi', 'modules', 'Thiết lập module mới news\"', '', '', 1, 1352624996), 
(389, 'vi', 'modules', 'Sửa module &ldquo;news&rdquo;', '', '', 1, 1352625016), 
(390, 'vi', 'modules', 'Thêm module ảo \"kien_truc_360\"', '', '', 1, 1352625121), 
(391, 'vi', 'modules', 'Thiết lập module mới kien-truc-360\"', '', '', 1, 1352625128), 
(392, 'vi', 'modules', 'Sửa module &ldquo;kien-truc-360&rdquo;', '', '', 1, 1352625141), 
(393, 'vi', 'modules', 'Thêm module ảo \"tu_van_kien_truc\"', '', '', 1, 1352625241), 
(394, 'vi', 'modules', 'Thiết lập module mới tu-van-kien-truc\"', '', '', 1, 1352625446), 
(395, 'vi', 'modules', 'Sửa module &ldquo;tu-van-kien-truc&rdquo;', '', '', 1, 1352625462), 
(396, 'vi', 'modules', 'Thứ tự module \"news\"', '14 -> 3', '14 -> 3', 1, 1352625566), 
(397, 'vi', 'modules', 'Thứ tự module \"kien-truc-360\"', '14 -> 4', '14 -> 4', 1, 1352625568), 
(398, 'vi', 'modules', 'Thứ tự module \"tu-van-kien-truc\"', '14 -> 5', '14 -> 5', 1, 1352625575), 
(399, 'vi', 'news', 'Thêm chuyên mục', 'Nhà ở', 'Nhà ở', 1, 1352625618), 
(400, 'vi', 'news', 'Thêm chuyên mục', 'Nội thất', 'Nội thất', 1, 1352625652), 
(401, 'vi', 'news', 'Thêm chuyên mục', 'Nhà cao tầng', 'Nhà cao tầng', 1, 1352625669), 
(402, 'vi', 'news', 'Thêm chuyên mục', 'Nhà vườn - resort', 'Nhà vườn - resort', 1, 1352625722), 
(403, 'vi', 'news', 'Thêm chuyên mục', 'Công trình công cộng', 'Công trình công cộng', 1, 1352625747), 
(404, 'vi', 'news', 'Thêm chuyên mục', 'Quy hoạch dự án', 'Quy hoạch dự án', 1, 1352625760), 
(405, 'vi', 'kien-truc-360', 'Thêm chuyên mục', 'Không gian sống', 'Không gian sống', 1, 1352625795), 
(406, 'vi', 'kien-truc-360', 'Thêm chuyên mục', 'Phong thuỷ', 'Phong thuỷ', 1, 1352625906), 
(407, 'vi', 'kien-truc-360', 'Thêm chuyên mục', 'Kiến trúc lạ', 'Kiến trúc lạ', 1, 1352625921), 
(408, 'vi', 'kien-truc-360', 'Thêm chuyên mục', 'KTS nổi tiếng', 'KTS nổi tiếng', 1, 1352625945), 
(409, 'vi', 'kien-truc-360', 'Thêm chuyên mục', 'Công trình kiến trúc nổi tiếng', 'Công trình kiến trúc nổi tiếng', 1, 1352625974), 
(410, 'vi', 'tu-van-kien-truc', 'Thêm chuyên mục', 'Tư vấn thiết kế', 'Tư vấn thiết kế', 1, 1352626027), 
(411, 'vi', 'tu-van-kien-truc', 'Thêm chuyên mục', 'Tư vấn phong thuỷ', 'Tư vấn phong thuỷ', 1, 1352626041), 
(412, 'vi', 'tu-van-kien-truc', 'Thêm chuyên mục', 'Thủ tục pháp lý', 'Thủ tục pháp lý', 1, 1352626062), 
(413, 'vi', 'themes', 'Thêm block', 'Name : global block catalogs2', 'Name : global block catalogs2', 1, 1352626296), 
(414, 'vi', 'themes', 'Thêm block', 'Name : global block catalogs2', 'Name : global block catalogs2', 1, 1352626775), 
(415, 'vi', 'themes', 'Sửa block', 'Name : global block catalogs2', 'Name : global block catalogs2', 1, 1352626884), 
(416, 'vi', 'themes', 'Sửa block', 'Name : global block catalogs2', 'Name : global block catalogs2', 1, 1352626941), 
(417, 'vi', 'themes', 'Sửa block', 'Name : global block catalogs2', 'Name : global block catalogs2', 1, 1352627099), 
(418, 'vi', 'themes', 'Thêm block', 'Name : global block catalogs2', 'Name : global block catalogs2', 1, 1352627231), 
(419, 'vi', 'themes', 'Thêm block', 'Name : global block catalogs2', 'Name : global block catalogs2', 1, 1352627255), 
(420, 'vi', 'themes', 'Sửa block', 'Name : global block catalogs2', 'Name : global block catalogs2', 1, 1352627370), 
(421, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1352698127), 
(422, 'vi', 'upload', 'Upload file', 'uploads/news/2012_11/113.jpg', 'uploads/news/2012_11/113.jpg', 1, 1352698419), 
(423, 'vi', 'news', 'Thêm bài viết', 'Một số công trình nhà đẹp mà ADKientruc đã thi công', 'Một số công trình nhà đẹp mà ADKientruc đã thi công', 1, 1352698488), 
(424, 'vi', 'upload', 'Upload file', 'uploads/news/2012_11/phong-khach-hien-dai-sang-trong-1.jpg', 'uploads/news/2012_11/phong-khach-hien-dai-sang-trong-1.jpg', 1, 1352698611), 
(425, 'vi', 'news', 'Thêm bài viết', 'Mẫu thiết kế phòng khách hiện đại – sang trọng', 'Mẫu thiết kế phòng khách hiện đại – sang trọng', 1, 1352698623), 
(426, 'vi', 'upload', 'Upload file', 'uploads/news/2012_11/124.jpg', 'uploads/news/2012_11/124.jpg', 1, 1352698665), 
(427, 'vi', 'news', 'Thêm bài viết', 'Khách Sạn Mini Cao Bằng', 'Khách Sạn Mini Cao Bằng', 1, 1352698698), 
(428, 'vi', 'upload', 'Upload file', 'uploads/news/2012_11/139.jpg', 'uploads/news/2012_11/139.jpg', 1, 1352698729), 
(429, 'vi', 'news', 'Thêm bài viết', 'Mẫu nhà vườn đẹp tặng bạn', 'Mẫu nhà vườn đẹp tặng bạn', 1, 1352698760), 
(430, 'vi', 'upload', 'Upload file', 'uploads/news/2012_11/136.jpg', 'uploads/news/2012_11/136.jpg', 1, 1352698805), 
(431, 'vi', 'news', 'Thêm bài viết', 'Trung tâm game giải trí', 'Trung tâm game giải trí', 1, 1352698831), 
(432, 'vi', 'upload', 'Upload file', 'uploads/news/2012_11/4_resize.jpg', 'uploads/news/2012_11/4_resize.jpg', 1, 1352698868), 
(433, 'vi', 'news', 'Thêm bài viết', 'Công viên Mai Dịch', 'Công viên Mai Dịch', 1, 1352698890), 
(434, 'vi', 'news', 'Thêm bài viết', 'ádsds', 'ádsds', 1, 1352699000), 
(435, 'vi', 'themes', 'Thiết lập layout theme: \"noithatviet\"', '', '', 1, 1352699219), 
(436, 'vi', 'themes', 'Thêm block', 'Name : global block catalogs2', 'Name : global block catalogs2', 1, 1352699668), 
(437, 'vi', 'themes', 'Thêm block', 'Name : global block catalogs2', 'Name : global block catalogs2', 1, 1352699802), 
(438, 'vi', 'themes', 'Thêm block', 'Name : global login', 'Name : global login', 1, 1352700029), 
(439, 'vi', 'themes', 'Thêm block', 'Name : global block catalogs2', 'Name : global block catalogs2', 1, 1352700105), 
(440, 'vi', 'news', 'Xóa Bài viết', ' ádsds', ' ádsds', 1, 1352700327), 
(441, 'vi', 'upload', 'Upload file', 'uploads/kien-truc-360/2012_11/bep-xanh-tot-cho-suc-khoe-1.jpg', 'uploads/kien-truc-360/2012_11/bep-xanh-tot-cho-suc-khoe-1.jpg', 1, 1352700350), 
(442, 'vi', 'kien-truc-360', 'Thêm bài viết', 'Không gian nhà bếp nổi bật 2012', 'Không gian nhà bếp nổi bật 2012', 1, 1352700391), 
(443, 'vi', 'themes', 'Thiết lập layout theme: \"noithatviet\"', '', '', 1, 1352705900), 
(444, 'vi', 'upload', 'Upload file', 'uploads/kien-truc-360/2012_11/kinh-doanh-va-thuat-phong-thuy.jpg', 'uploads/kien-truc-360/2012_11/kinh-doanh-va-thuat-phong-thuy.jpg', 1, 1352706014), 
(445, 'vi', 'kien-truc-360', 'Thêm bài viết', 'Chọn cửa hàng kinh doanh theo Phong thủy', 'Chọn cửa hàng kinh doanh theo Phong thủy', 1, 1352706043), 
(446, 'vi', 'upload', 'Upload file', 'uploads/kien-truc-360/2012_11/ngoi-nha-dut-gay-doc-dao1.jpg', 'uploads/kien-truc-360/2012_11/ngoi-nha-dut-gay-doc-dao1.jpg', 1, 1352706073), 
(447, 'vi', 'kien-truc-360', 'Thêm bài viết', 'Ngôi nhà nứt làm ba', 'Ngôi nhà nứt làm ba', 1, 1352706123), 
(448, 'vi', 'upload', 'Upload file', 'uploads/kien-truc-360/2012_11/image001-749833.jpg', 'uploads/kien-truc-360/2012_11/image001-749833.jpg', 1, 1352706168), 
(449, 'vi', 'kien-truc-360', 'Thêm bài viết', 'Kiến trúc sư Ludwig Mies van der Rohe', 'Kiến trúc sư Ludwig Mies van der Rohe', 1, 1352706194), 
(450, 'vi', 'upload', 'Upload file', 'uploads/kien-truc-360/2012_11/691343.jpeg', 'uploads/kien-truc-360/2012_11/691343.jpeg', 1, 1352706245), 
(451, 'vi', 'kien-truc-360', 'Thêm bài viết', 'Điểm danh 7 khách sạn, khu nghỉ dưỡng đẹp nhất của các sao', 'Điểm danh 7 khách sạn, khu nghỉ dưỡng đẹp nhất của các sao', 1, 1352706268), 
(452, 'vi', 'themes', 'Thêm block', 'Name : global block catalogs2', 'Name : global block catalogs2', 1, 1352706646), 
(453, 'vi', 'themes', 'Thêm block', 'Name : global block catalogs2', 'Name : global block catalogs2', 1, 1352706882), 
(454, 'vi', 'upload', 'Upload file', 'uploads/tu-van-kien-truc/2012_11/pc.jpg', 'uploads/tu-van-kien-truc/2012_11/pc.jpg', 1, 1352708255), 
(455, 'vi', 'tu-van-kien-truc', 'Thêm bài viết', 'Tư vấn xây nhà 3 tầng trên mảnh đất 120m2', 'Tư vấn xây nhà 3 tầng trên mảnh đất 120m2', 1, 1352708476), 
(456, 'vi', 'upload', 'Upload file', 'uploads/tu-van-kien-truc/2012_11/house3.jpg', 'uploads/tu-van-kien-truc/2012_11/house3.jpg', 1, 1352708535), 
(457, 'vi', 'tu-van-kien-truc', 'Thêm bài viết', 'Tư vấn hóa giải hướng nhà không tốt cho gia chủ', 'Tư vấn hóa giải hướng nhà không tốt cho gia chủ', 1, 1352708558), 
(458, 'vi', 'upload', 'Upload file', 'uploads/tu-van-kien-truc/2012_11/tuvannhavuon.bmp', 'uploads/tu-van-kien-truc/2012_11/tuvannhavuon.bmp', 1, 1352708605), 
(459, 'vi', 'upload', 'Upload file', 'uploads/tu-van-kien-truc/2012_11/tuvannhavuon_1.bmp', 'uploads/tu-van-kien-truc/2012_11/tuvannhavuon_1.bmp', 1, 1352708645), 
(460, 'vi', 'tu-van-kien-truc', 'Thêm bài viết', 'Giấy tờ để tách thửa', 'Giấy tờ để tách thửa', 1, 1352708698), 
(461, 'vi', 'themes', 'Thiết lập layout theme: \"noithatviet\"', '', '', 1, 1352708794), 
(462, 'vi', 'themes', 'Thiết lập layout theme: \"noithatviet\"', '', '', 1, 1352708855), 
(463, 'vi', 'tu-van-kien-truc', 'Thêm bài viết', 'hfgfhgfhfhg', 'hfgfhgfhfhg', 1, 1352708952), 
(464, 'vi', 'themes', 'Thêm block', 'Name : global block category', 'Name : global block category', 1, 1352709419), 
(465, 'vi', 'themes', 'Sửa block', 'Name : global block category', 'Name : global block category', 1, 1352709455), 
(466, 'vi', 'themes', 'Thêm block', 'Name : global block category', 'Name : global block category', 1, 1352709512), 
(467, 'vi', 'themes', 'Sửa block', 'Name : global block category', 'Name : global block category', 1, 1352709535), 
(468, 'vi', 'themes', 'Sửa block', 'Name : global block category', 'Name : global block category', 1, 1352709555), 
(469, 'vi', 'themes', 'Sửa block', 'Name : global block category', 'Name : global block category', 1, 1352709703), 
(470, 'vi', 'themes', 'Sửa block', 'Name : global block category', 'Name : global block category', 1, 1352709814), 
(471, 'vi', 'themes', 'Sửa block', 'Name : global block category', 'Name : global block category', 1, 1352709863), 
(472, 'vi', 'themes', 'Thêm block', 'Name : global block tophits', 'Name : global block tophits', 1, 1352709883), 
(473, 'vi', 'themes', 'Thêm block', 'Name : global block tophits', 'Name : global block tophits', 1, 1352709910), 
(474, 'vi', 'themes', 'Sửa block', 'Name : global block category', 'Name : global block category', 1, 1352710511), 
(475, 'vi', 'themes', 'Sửa block', 'Name : global block category', 'Name : global block category', 1, 1352710556), 
(476, 'vi', 'themes', 'Sửa block', 'Name : global block category', 'Name : global block category', 1, 1352711141), 
(477, 'vi', 'themes', 'Sửa block', 'Name : global block category', 'Name : global block category', 1, 1352712348), 
(478, 'vi', 'themes', 'Sửa block', 'Name : global block category', 'Name : global block category', 1, 1352713953), 
(479, 'vi', 'themes', 'Thêm block', 'Name : global block tophits', 'Name : global block tophits', 1, 1352714251), 
(480, 'vi', 'themes', 'Sửa block', 'Name : global block tophits', 'Name : global block tophits', 1, 1352714272), 
(481, 'vi', 'themes', 'Sửa block', 'Name : global block tophits', 'Name : global block tophits', 1, 1352714305), 
(482, 'vi', 'themes', 'Sửa block', 'Name : Kiến trúc 360', 'Name : Kiến trúc 360', 1, 1352714335), 
(483, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm', 'Name : Sản phẩm', 1, 1352714399), 
(484, 'vi', 'themes', 'Sửa block', 'Name : Kiến trúc 360', 'Name : Kiến trúc 360', 1, 1352714425), 
(485, 'vi', 'themes', 'Thêm block', 'Name : Tư vấn kiến trúc', 'Name : Tư vấn kiến trúc', 1, 1352714507), 
(486, 'vi', 'themes', 'Sửa block', 'Name : Tư vấn kiến trúc', 'Name : Tư vấn kiến trúc', 1, 1352714523), 
(487, 'vi', 'modules', 'Xóa module \"shops\"', '', '', 1, 1352718128), 
(488, 'vi', 'themes', 'Thêm block', 'Name : global counter', 'Name : global counter', 1, 1352718192), 
(489, 'vi', 'themes', 'Sửa block', 'Name : global counter', 'Name : global counter', 1, 1352718209), 
(490, 'vi', 'themes', 'Sửa block', 'Name : Thống kê', 'Name : Thống kê', 1, 1352718226), 
(491, 'vi', 'themes', 'Sửa block', 'Name : Thành viên', 'Name : Thành viên', 1, 1352718267), 
(492, 'vi', 'themes', 'Thêm block', 'Name : Thăm dò ý kiến', 'Name : Thăm dò ý kiến', 1, 1352718341);


-- ---------------------------------------


--
-- Table structure for table `nv3_sessions`
--

DROP TABLE IF EXISTS `nv3_sessions`;
CREATE TABLE `nv3_sessions` (
  `session_id` varchar(50) DEFAULT NULL,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(100) NOT NULL,
  `onl_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_sessions`
--

INSERT INTO `nv3_sessions` VALUES
('5685ffa195dbfa4f674613370e62b05c2130706433', 1, 'admin', 1352719335);


-- ---------------------------------------


--
-- Table structure for table `nv3_setup`
--

DROP TABLE IF EXISTS `nv3_setup`;
CREATE TABLE `nv3_setup` (
  `lang` char(2) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tables` varchar(255) NOT NULL,
  `version` varchar(100) NOT NULL,
  `setup_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_setup_language`
--

DROP TABLE IF EXISTS `nv3_setup_language`;
CREATE TABLE `nv3_setup_language` (
  `lang` char(2) NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_setup_language`
--

INSERT INTO `nv3_setup_language` VALUES
('vi', 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_setup_modules`
--

DROP TABLE IF EXISTS `nv3_setup_modules`;
CREATE TABLE `nv3_setup_modules` (
  `title` varchar(55) NOT NULL,
  `is_sysmod` tinyint(1) NOT NULL DEFAULT '0',
  `virtual` tinyint(1) NOT NULL DEFAULT '0',
  `module_file` varchar(50) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `mod_version` varchar(50) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_setup_modules`
--

INSERT INTO `nv3_setup_modules` VALUES
('about', 0, 1, 'about', 'about', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('banners', 1, 0, 'banners', 'banners', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('contact', 0, 1, 'contact', 'contact', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('news', 0, 1, 'news', 'news', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('voting', 0, 0, 'voting', 'voting', '3.1.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('forum', 0, 0, 'forum', 'forum', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('search', 1, 0, 'search', 'search', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('users', 1, 0, 'users', 'users', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('download', 0, 1, 'download', 'download', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('weblinks', 0, 1, 'weblinks', 'weblinks', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('statistics', 0, 0, 'statistics', 'statistics', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('faq', 0, 1, 'faq', 'faq', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('menu', 0, 1, 'menu', 'menu', '3.1.00 1273225635', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('rss', 1, 0, 'rss', 'rss', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''), 
('shops', 0, 1, 'shops', 'shops', '3.3.00 1273830435', 1351331249, 'VINADES (contact@vinades.vn)', ''), 
('home', 0, 1, 'home', 'home', '3.0.01 1287532800', 1351505331, 'PCD-GROUP (dinhpc.it@gmail.com)', ''), 
('archives', 0, 1, 'archives', 'archives', '3.2.0.0 1273225635', 1351506914, 'PCD-GROUP (contact@dinhpc.com)', ''), 
('kien-truc-360', 0, 0, 'news', 'kien_truc_360', '', 1352625121, '', ''), 
('tu-van-kien-truc', 0, 0, 'news', 'tu_van_kien_truc', '', 1352625241, '', '');


-- ---------------------------------------


--
-- Table structure for table `nv3_users`
--

DROP TABLE IF EXISTS `nv3_users`;
CREATE TABLE `nv3_users` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `gender` char(1) NOT NULL,
  `photo` varchar(255) NOT NULL DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `website` varchar(255) NOT NULL DEFAULT '',
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL DEFAULT '',
  `telephone` varchar(100) NOT NULL DEFAULT '',
  `fax` varchar(100) NOT NULL DEFAULT '',
  `mobile` varchar(100) NOT NULL DEFAULT '',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `passlostkey` varchar(40) NOT NULL DEFAULT '',
  `view_mail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255) NOT NULL DEFAULT '',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` varchar(40) NOT NULL DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) NOT NULL DEFAULT '',
  `last_agent` varchar(255) NOT NULL DEFAULT '',
  `last_openid` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_users`
--

INSERT INTO `nv3_users` VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '4a467cdf5df6317340f339d54321b0b3d926cd73', 'tvthanh88hp@gmail.com', 'admin', '', '', 0, NULL, 1351249634, '', '', '', '', '', '', 'abc', 'abc', '', 0, 1, '', 1, '', 1351249634, '', '', ''), 
(2, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', '4a467cdf5df6317340f339d54321b0b3d926cd73', 'trinhthanh9688@gmail.com', '', '', '', 0, '', 1351407241, '', '', '', '', '', '', 'abc', 'abc', '', 0, 1, '', 1, '', 0, '', '', '');


-- ---------------------------------------


--
-- Table structure for table `nv3_users_config`
--

DROP TABLE IF EXISTS `nv3_users_config`;
CREATE TABLE `nv3_users_config` (
  `config` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_users_config`
--

INSERT INTO `nv3_users_config` VALUES
('registertype', '1', 1351249594), 
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1351249594), 
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1351249594), 
('siteterms_vi', '<p> Để trở thành thành viên, bạn phải cam kết đồng ý với các điều khoản dưới đây. Chúng tôi có thể thay đổi lại những điều khoản này vào bất cứ lúc nào và chúng tôi sẽ cố gắng thông báo đến bạn kịp thời.<br  /> <br  /> Bạn cam kết không gửi bất cứ bài viết có nội dung lừa đảo, thô tục, thiếu văn hoá; vu khống, khiêu khích, đe doạ người khác; liên quan đến các vấn đề tình dục hay bất cứ nội dung nào vi phạm luật pháp của quốc gia mà bạn đang sống, luật pháp của quốc gia nơi đặt máy chủ của website này hay luật pháp quốc tế. Nếu vẫn cố tình vi phạm, ngay lập tức bạn sẽ bị cấm tham gia vào website. Địa chỉ IP của tất cả các bài viết đều được ghi nhận lại để bảo vệ các điều khoản cam kết này trong trường hợp bạn không tuân thủ.<br  /> <br  /> Bạn đồng ý rằng website có quyền gỡ bỏ, sửa, di chuyển hoặc khoá bất kỳ bài viết nào trong website vào bất cứ lúc nào tuỳ theo nhu cầu công việc.<br  /> <br  /> Đăng ký làm thành viên của chúng tôi, bạn cũng phải đồng ý rằng, bất kỳ thông tin cá nhân nào mà bạn cung cấp đều được lưu trữ trong cơ sở dữ liệu của hệ thống. Mặc dù những thông tin này sẽ không được cung cấp cho bất kỳ người thứ ba nào khác mà không được sự đồng ý của bạn, chúng tôi không chịu trách nhiệm về việc những thông tin cá nhân này của bạn bị lộ ra bên ngoài từ những kẻ phá hoại có ý đồ xấu tấn công vào cơ sở dữ liệu của hệ thống.</p>', 1274757129);


-- ---------------------------------------


--
-- Table structure for table `nv3_users_openid`
--

DROP TABLE IF EXISTS `nv3_users_openid`;
CREATE TABLE `nv3_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `opid` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_users_question`
--

DROP TABLE IF EXISTS `nv3_users_question`;
CREATE TABLE `nv3_users_question` (
  `qid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `lang` char(2) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_users_question`
--

INSERT INTO `nv3_users_question` VALUES
(1, 'Bạn thích môn thể thao nào nhất', 'vi', 1, 1274840238, 1274840238), 
(2, 'Món ăn mà bạn yêu thích', 'vi', 2, 1274840250, 1274840250), 
(3, 'Thần tượng điện ảnh của bạn', 'vi', 3, 1274840257, 1274840257), 
(4, 'Bạn thích nhạc sỹ nào nhất', 'vi', 4, 1274840264, 1274840264), 
(5, 'Quê ngoại của bạn ở đâu', 'vi', 5, 1274840270, 1274840270), 
(6, 'Tên cuốn sách &quot;gối đầu giường&quot;', 'vi', 6, 1274840278, 1274840278), 
(7, 'Ngày lễ mà bạn luôn mong đợi', 'vi', 7, 1274840285, 1274840285);


-- ---------------------------------------


--
-- Table structure for table `nv3_users_reg`
--

DROP TABLE IF EXISTS `nv3_users_reg`;
CREATE TABLE `nv3_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `regdate` int(11) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `checknum` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_about`
--

DROP TABLE IF EXISTS `nv3_vi_about`;
CREATE TABLE `nv3_vi_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `bodytext` mediumtext NOT NULL,
  `keywords` mediumtext NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_about`
--

INSERT INTO `nv3_vi_about` VALUES
(1, 'Vinagon.com', 'Vinagon-com', '<h2 class=\"title_about\" style=\"color: rgb(9, 67, 174);font-size:14px; margin-top:5px\"> Giới thiệu Công ty TNHH Công Nghệ Số VINAGON</h2><p align=\"center\"> <b><font color=\"rgb(51, 102, 204);\" size=\"4\">Giới thiệu Công ty TNHH Công Nghệ Số VINAGON</font></b></p><div> <a><font color=\"rgb(51, 102, 204);\">VinaGon</font></a><font color=\"rgb(51, 102, 204);\"> là công ty chuyên nghiệp trong cung cấp các giải pháp về phát triển Website ứng dụng trên nền Web, bao gồm: thiết kế, lập trình và các dịch vụ tư vấn khác về ứng dụng Web. </font><a><font color=\"rgb(51, 102, 204);\">VinaGon</font></a><font color=\"rgb(51, 102, 204);\"> còn là nhà cung cấp các giải pháp phát triển ứng dụng phần mềm và thương mại điện tử. VinaGon luôn có tầm nhìn và bắt kịp với sự phát triển về công nghệ cũng như giải pháp cho nhu cầu thực tế.</font></div><div> <a><font color=\"rgb(51, 102, 204);\">VinaGon</font></a><font color=\"rgb(51, 102, 204);\"> xác định mình phải góp phần vào sự phát triển ngành CNTT vốn còn non trẻ của đất nước, với tiêu chí hướng đến mọi người sử dụng chúng tôi đã đầu tư công sức và nhân lực tập trung phát triển những ứng dụng trên nền Website để có được những sản phẩm tốt nhất mang tính ứng dụng cao nhất, đáp ứng được mọi sự kỳ vọng của người sử dụng.<br  /> <br  /> Bên cạnh những dịch vụ Website với chi phí thấp chúng tôi còn cung cấp những hệ thống quản lý chuyên nghiệp mang tính công nghệ và ứng dụng cao, giúp các doanh nghiệp tích kiệm được kinh phí và nhân lực.</font> <p> &nbsp;</p></div><table align=\"center\" border=\"0\"> <tbody> <tr> <td style=\"text-align: center;\"> <a><font color=\"rgb(51, 102, 204);\"><img border=\"0\" src=\"http://dinhpc.com/uploads/dich-vu-san-pham/2011_07/rg.jpg\" style=\"width: 177px; height: 136px;\" /></font></a></td> <td align=\"center\"> <a><font color=\"rgb(51, 102, 204);\"><img border=\"0\" src=\"http://dinhpc.com/uploads/dich-vu-san-pham/2011_07/nahnhang.jpg\" style=\"width: 175px; height: 133px;\" /></font></a></td> <td align=\"center\"> <a><font color=\"rgb(51, 102, 204);\"><img border=\"0\" src=\"http://dinhpc.com/uploads/dich-vu-san-pham/2011_07/manage.jpg\" style=\"width: 173px; height: 136px;\" /></font></a></td> </tr> <tr> <td align=\"center\"> <b><a><font color=\"rgb(51, 102, 204);\">Hệ thống quản lý xuất bản tạp chí</font></a></b></td> <td align=\"center\"> <b><a><font color=\"rgb(51, 102, 204);\">Hệ thống quản lý nhà hàng</font></a></b></td> <td align=\"center\"> <b><a><font color=\"rgb(51, 102, 204);\">Hệ thống quản lý câu lạc bộ Billiard</font></a></b></td> </tr> </tbody></table><ul> <li style=\"TEXT-ALIGN:justify\"> <span style=\"FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px\"><font color=\"rgb(51, 102, 204);\">TNHH VINAGON đã có kinh nghiệm triển khai rất nhiều dự án </font><strong><a href=\"http://web.vinagon.com/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">thiết kế website</font></a></strong><font color=\"rgb(51, 102, 204);\">, <strong>Giải pháp seo </strong>thành công. Và </font><a href=\"http://vinagon.com/about/about/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">công ty TNHH VINAGON</font></a><font color=\"rgb(51, 102, 204);\"> cũng sẽ đảm bảo mang đến thành công cho công ty bạn.</font></span></li></ul><ul> <li style=\"TEXT-ALIGN:justify\"> <span style=\"FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px\"><font color=\"rgb(51, 102, 204);\">Với một quy trình làm việc hiệu quả, khả năng nắm bắt những yêu cầu tinh tế nhất của khách hàng và việc xây dựng mối quan hệ cộng tác một cách chặt chẽ, uyển chuyển đã tạo nên ưu thế trong việc cung cấp dịch vụ của </font><a href=\"http://vinagon.com/about/about/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">công ty TNHH VINAGON</font></a><font color=\"rgb(51, 102, 204);\">.</font></span></li></ul><p style=\"TEXT-ALIGN:justify;MARGIN-LEFT:80px\"> <font color=\"rgb(51, 102, 204);\"><span style=\"FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px\"><strong>1. Chúng tôi đặt tiêu chí phục vụ khách hàng lên hàng đầu</strong>:</span></font></p><p style=\"TEXT-ALIGN:justify;MARGIN-LEFT:80px\"> <font color=\"rgb(51, 102, 204);\"><span style=\"FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px\">Toàn bộ đội ngũ nhân viên của chúng tôi thấu hiểu một điều rằng thành công của chúng tôi nằm trong những giá trị mà chúng tôi đem lại cho khách hàng. Chính vì lẽ đó chúng tôi luôn cam kết mang lại cho khách hàng những giá trị nhiều hơn sự mong đợi.</span></font></p><p style=\"TEXT-ALIGN:justify;MARGIN-LEFT:80px\"> <font color=\"rgb(51, 102, 204);\"><span style=\"FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px\"><strong>2..</strong> <strong>Sản phẩm của bạn sẽ được hoàn thành bởi những chuyên gia</strong></span></font></p><p style=\"TEXT-ALIGN:justify;MARGIN-LEFT:80px\"> <span style=\"FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px\"><font color=\"rgb(51, 102, 204);\">Đội ngũ lập trình của </font><a href=\"http://vinagon.com/about/about/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">công ty TNHH VINAGON</font></a><font color=\"rgb(51, 102, 204);\"> đã có kinh nghiệm tham gia nhiều dự án và qua mỗi dự án chúng tôi học hỏi, trau dồi và tìm kiếm tri thức mới để vững vàng hơn, trưởng thành hơn, trở thành những chuyên gia. </font></span></p><p style=\"TEXT-ALIGN:justify;MARGIN-LEFT:80px\"> <font color=\"rgb(51, 102, 204);\"><span style=\"FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px\"><strong>3. Chúng tôi làm việc với niềm say mê và cảm hứng sáng tạo</strong></span></font></p><p style=\"TEXT-ALIGN:justify;MARGIN-LEFT:80px\"> <span style=\"FONT-FAMILY:&#039;times new roman&#039;,times,serif\"><span style=\"FONT-SIZE:14px\"><font color=\"rgb(51, 102, 204);\">Chúng tôi nhận ra rằng những doanh nghiệp thành công là nhờ những con người ưu tú. Mỗi thành viên của </font><a href=\"http://vinagon.com/about/about/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">công ty TNHH VINAGON</font></a><font color=\"rgb(51, 102, 204);\"> đều là những chuyên gia trong lĩnh vực của mình. Thân thiện, giầu cảm hứng sáng tạo, có động lực làm việc mạnh mẽ đó chính là điểm khác biệt của họ.</font></span></span></p><p style=\"TEXT-ALIGN:justify;MARGIN-LEFT:80px\"> <span style=\"FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px\"><strong><font color=\"rgb(51, 102, 204);\">4. </font><a href=\"http://vinagon.com/about/about/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">Công ty TNHH VINAGON</font></a></strong><font color=\"rgb(51, 102, 204);\"> <strong>là lựa chọn tốt nhất của nhiều các doanh nghiệp vừa và nhỏ</strong></font></span></p><p style=\"TEXT-ALIGN:justify;MARGIN-LEFT:80px\"> <span style=\"FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px\"><a href=\"http://vinagon.com/about/about/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">Công ty TNHH VINAGON</font></a><font color=\"rgb(51, 102, 204);\"> giúp các doanh nghiệp vừa và nhỏ tiết kiệm thời gian và chi phí của mình bằng cách đưa ra các gói dịch vụ phù hợp, tư vấn tận tình, cặn kẽ những gì doanh nghiệp cần và sử dụng một quy trình nghiệp vụ đã được tối ưu hóa.</font></span></p><p style=\"TEXT-ALIGN:justify;MARGIN-LEFT:80px\"> <span style=\"FONT-FAMILY:&#039;times new roman&#039;,times,serif\"><span style=\"FONT-SIZE:14px\"><strong><font color=\"rgb(51, 102, 204);\">5. </font><a href=\"http://vinagon.com/about/about/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">Công ty TNHH VINAGON</font></a><font color=\"rgb(51, 102, 204);\"> luôn coi trọng mới quan hệ lâu dài </font></strong></span></span></p><p style=\"TEXT-ALIGN:justify;MARGIN-LEFT:80px\"> <span style=\"FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px\"><a href=\"http://vinagon.com/about/about/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">Công ty TNHH VINAGON</font></a><font color=\"rgb(51, 102, 204);\"> bắt đầu bằng việc khởi tạo mối quan hệ hợp tác tin tưởng, và hoàn thành công việc bằng việc duy trì quan hệ dài lâu. Chính sách hỗ trợ, hậu mãi tạo cho khách hàng niềm tin hoàn toàn khi trao công việc cho </font><a href=\"http://vinagon.com/about/about/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">Công ty TNHH VINAGON</font></a><font color=\"rgb(51, 102, 204);\">. </font></span></p><p> <strong><span style=\"FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px\"><font color=\"rgb(51, 102, 204);\">Các gói </font><a href=\"http://web.vinagon.com/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">thiết kế website</font></a><font color=\"rgb(51, 102, 204);\"> của </font><a href=\"http://vinagon.com/about/about/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">Công ty TNHH VINAGON</font></a><font color=\"rgb(51, 102, 204);\"> phục vụ quý khách hàng :</font></span></strong></p><div align=\"center\"> <table style=\"BORDER-BOTTOM:rgb(51, 102, 204); 2px solid;BORDER-LEFT:rgb(51, 102, 204); 2px solid;BORDER-TOP:rgb(51, 102, 204); 2px solid;BORDER-RIGHT:rgb(51, 102, 204); 2px solid\" width=\"50%\"> <tbody> <tr> <td align=\"center\"> <font color=\"rgb(51, 102, 204);\"><img border=\"0\" src=\"http://web.vinagon.com/uploads/shops/thumb/wweb-tt-034-b.jpg\" /></font></td> <td align=\"center\"> <font color=\"rgb(51, 102, 204);\"><img border=\"0\" src=\"http://web.vinagon.com/uploads/shops/thumb/aweb-gt-018-a.jpg\" /></font></td> <td align=\"center\"> <font color=\"rgb(51, 102, 204);\"><img border=\"0\" src=\"http://web.vinagon.com/uploads/shops/thumb/computers-magento-template.jpg\" /></font></td> </tr> <tr> <td align=\"center\"> <b><a href=\"http://web.vinagon.com/shops/Web-tin-tuc/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">Website Tin Tức</font></a></b></td> <td align=\"center\"> <b><a href=\"http://web.vinagon.com/shops/Web-Company/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">Website Doanh Nghiệp</font></a></b></td> <td align=\"center\"> <b><a href=\"http://web.vinagon.com/shops/Web-ban-hang/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">Website Thương Mại</font></a></b></td> </tr> </tbody> </table></div><p> <font color=\"rgb(51, 102, 204);\">Ngoài những sản phẩm trên, </font><a><font color=\"rgb(51, 102, 204);\">Công ty TNHH VINAGON</font></a><font color=\"rgb(51, 102, 204);\"> hiện đang cung cấp một kênh quảng cáo hoàn toàn miễn phí giúp công ty và doanh nghiệp khẳng định thương hiệu trên thị trường.<br  /> Quý khách hàng có thể truy cập địa chỉ sau để đăng tải sản phẩm của mình tới người tiêu dùng:</font></p><p align=\"center\"> <b><font color=\"rgb(51, 102, 204);\" size=\"4\"><a href=\"http://ads.dinhpc.com/\" target=\"_blank\">http://ads.dinhpc.com</a></font></b></p><p align=\"center\"> <font color=\"rgb(51, 102, 204);\"><img src=\"http://vinagon.com/uploads/about/adsdinhpc1.jpg\" style=\"border-width: 0pt; border-style: solid; width: 621px; height: 299px;\" /></font></p><p align=\"center\"> <b><a><font color=\"rgb(51, 102, 204);\">ADS Dinh PC</font></a></b></p><p align=\"center\"> <font color=\"rgb(51, 102, 204);\"><img src=\"http://vinagon.com/uploads/about/adsdinhpc2.jpg\" style=\"border-width: 0pt; border-style: solid; width: 621px; height: 299px;\" /></font></p><p align=\"center\"> <b><a><font color=\"rgb(51, 102, 204);\">Quản lý tin đã đăng</font></a></b></p><p align=\"center\"> <font color=\"rgb(51, 102, 204);\"><img src=\"http://vinagon.com/uploads/about/adsdinhpc3.jpg\" style=\"border-width: 0pt; border-style: solid; width: 621px; height: 299px;\" /></font></p><p align=\"center\"> <b><a><font color=\"rgb(51, 102, 204);\">Đăng tin rao vặt mới</font></a></b></p><p style=\"TEXT-ALIGN:justify\"> <span style=\"FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px\"><font color=\"rgb(51, 102, 204);\">Hãy lựa chọn </font><a href=\"http://vinagon.com/about/about/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">Công ty TNHH VINAGON</font></a><font color=\"rgb(51, 102, 204);\"> để quý khách hàng có được lựa chọn tốt nhất cho cơ hội kinh doanh online của mình nhé!</font></span></p><p style=\"TEXT-ALIGN:justify\"> <span style=\"FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px\"><font color=\"rgb(51, 102, 204);\">Cảm ơn quý khách hàng đã chú ý tới </font><strong><a href=\"http://web.vinagon.com/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">dịch vụ thiết kế website</font></a><font color=\"rgb(51, 102, 204);\"> </font></strong><font color=\"rgb(51, 102, 204);\">của chúng tôi. </font><a href=\"http://vinagon.com/about/about/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">Công ty TNHH VINAGON</font></a><font color=\"rgb(51, 102, 204);\"> luôn luôn mong muốn được phục vụ theo yêu cầu và cung cấp giá trị hiệu quả nhất tới quý khách hàng.</font></span></p><table border=\"0\" width=\"100%\"> <tbody> <tr> <td> &nbsp;</td> <td> <font face=\"Times New Roman\"><font color=\"rgb(51, 102, 204);\">Văn phòng Hà Nội: <b>Số 34/28, 180 Nam Dư, Lĩnh Nam, Hoàng Mai, Hà Nội</b><br  /> Email: </font><a href=\"http://hoichogiaodich.com/link.aspx?url=mailto:info@vinagon.com\" target=\"_blank\"><b><font color=\"rgb(51, 102, 204);\">info@vinagon.com</font></b></a><font color=\"rgb(51, 102, 204);\"> | Website: </font><a href=\"http://hoichogiaodich.com/link.aspx?url=http://www.vinagon.com/\" target=\"_blank\"><b><font color=\"rgb(51, 102, 204);\">www.vinagon.com</font></b></a><font color=\"rgb(51, 102, 204);\"> - </font><b><a href=\"http://hoichogiaodich.com/link.aspx?url=http://web.vinagon.com/\" target=\"_blank\"><font color=\"rgb(51, 102, 204);\">web.vinagon.com</font></a></b><font color=\"rgb(51, 102, 204);\">| Điện thoại: <b>(+844) 6. 32.979.36 </b>| Hotline: <b>0903 218 933 - 0942 8888 04</b></font></font></td> </tr> </tbody></table><br  />', 'thế hệ,hoàn toàn,phát triển,tài chính,nhân lực,thời gian,kết quả,sử dụng,cho phép,uyển chuyển,công nghệ,tận dụng,thành tựu,đảm bảo,nền tảng,có nghĩa,phụ thuộc,quá trình,có thể,tự lập,đồng nghĩa', 1, 1, 1275320174, 1351508229, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_blocks_groups`
--

DROP TABLE IF EXISTS `nv3_vi_blocks_groups`;
CREATE TABLE `nv3_vi_blocks_groups` (
  `bid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(55) NOT NULL,
  `module` varchar(55) NOT NULL,
  `file_name` varchar(55) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `template` varchar(55) DEFAULT NULL,
  `position` varchar(55) DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` tinyint(4) DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text,
  PRIMARY KEY (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=58  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_blocks_groups`
--

INSERT INTO `nv3_vi_blocks_groups` VALUES
(2, 'default', 'statistics', 'global.counter.php', 'Thống kê truy cập', '', '', '[LEFT]', 0, 1, '0', 1, 2, ''), 
(3, 'default', 'banners', 'global.banners.php', 'Quảng cáo trái', '', '', '[LEFT]', 0, 1, '0', 1, 3, 'a:1:{s:12:\"idplanbanner\";i:2;}'), 
(4, 'default', 'about', 'global.about.php', 'Giới thiệu', '', 'orange', '[RIGHT]', 0, 1, '0', 1, 1, ''), 
(5, 'default', 'users', 'global.login.php', 'Đăng nhập thành viên', '', '', '[RIGHT]', 0, 1, '0', 1, 2, ''), 
(6, 'default', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '0', 1, 3, ''), 
(10, 'modern', 'about', 'global.about.php', 'Giới thiệu', '', 'no_title_html', '[RIGHT]', 0, 1, '0', 1, 1, ''), 
(11, 'modern', 'users', 'global.login.php', 'Đăng nhập', '', '', '[RIGHT]', 0, 1, '0', 1, 2, ''), 
(12, 'modern', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '0', 1, 3, ''), 
(13, 'modern', 'statistics', 'global.counter.php', 'Bộ đếm', '', '', '[RIGHT]', 0, 1, '0', 1, 4, ''), 
(15, 'modern', 'banners', 'global.banners.php', 'Quảng cáo top banner', '', 'no_title', '[TOPADV]', 0, 1, '0', 1, 1, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(16, 'modern', 'menu', 'global.menu_theme_modern.php', 'global menu theme modern', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''), 
(17, 'default', 'menu', 'global.menu_theme_default.php', 'global menu theme default', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''), 
(18, 'modern', 'global', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '0', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:274:\"© Copyright NukeViet 3. All right reserved.<br  />Xây dựng trên nền tảng <a href=\"http://nukeviet.vn/\" title=\"Mã nguồn mở NukeViet\">Mã nguồn mở NukeViet</a>. <a href=\"http://vinades.vn/\" title=\"Thiết kế web\">Thiết kế website</a> bởi VINADES.,JSC\";}'), 
(19, 'default', 'global', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '0', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:231:\"<p class=\"footer\"> © Copyright NukeViet 3. All right reserved.</p><p> Powered by <a href=\"http://nukeviet.vn/\" title=\"NukeViet CMS\">NukeViet CMS</a>. Design by <a href=\"http://vinades.vn/\" title=\"VINADES.,JSC\">VINADES.,JSC</a></p>\";}'), 
(20, 'mobile_nukeviet', 'menu', 'global.menu_theme_default.php', 'global menu theme default', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''), 
(21, 'phapluat2', 'users', 'global.login.php', 'Thành viên', '', '', '[RIGHT]', 0, 1, '0', 1, 1, ''), 
(23, 'phapluat2', 'menu', 'global.menu_theme_default.php', 'global menu theme default', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''), 
(26, 'phapluat2', 'voting', 'global.voting.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '0', 1, 3, 'a:1:{s:3:\"vid\";i:3;}'), 
(27, 'phapluat2', 'statistics', 'global.counter.php', 'Thống kê', '', '', '[LEFT]', 0, 1, '0', 1, 2, ''), 
(30, 'noithatviet', 'menu', 'global.menu_theme_default.php', 'global menu theme default', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''), 
(31, 'noithatviet', 'about', 'global.about.php', 'global about', '', 'no_title', '[RIGHT]', 0, 1, '0', 1, 1, ''), 
(46, 'noithatviet', 'users', 'global.login.php', 'Thành viên', '', '', '[RIGHT]', 0, 1, '0', 1, 2, ''), 
(51, 'noithatviet', 'news', 'global.block_tophits.php', 'Sản phẩm', '', '', '[TOP]', 0, 1, '0', 0, 1, 'a:2:{s:10:\"number_day\";i:365;s:6:\"numrow\";i:4;}'), 
(54, 'noithatviet', 'kien-truc-360', 'global.block_tophits.php', 'Kiến trúc 360', '', '', '[TOP]', 0, 1, '0', 0, 2, 'a:2:{s:10:\"number_day\";i:365;s:6:\"numrow\";i:4;}'), 
(55, 'noithatviet', 'tu-van-kien-truc', 'global.block_tophits.php', 'Tư vấn kiến trúc', '', '', '[TOP]', 0, 1, '0', 0, 3, 'a:2:{s:10:\"number_day\";i:365;s:6:\"numrow\";i:10;}'), 
(56, 'noithatviet', 'statistics', 'global.counter.php', 'Thống kê', '', '', '[RIGHT]', 0, 1, '0', 1, 3, ''), 
(57, 'noithatviet', 'voting', 'global.voting.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '0', 1, 4, 'a:1:{s:3:\"vid\";i:3;}');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_blocks_weight`
--

DROP TABLE IF EXISTS `nv3_vi_blocks_weight`;
CREATE TABLE `nv3_vi_blocks_weight` (
  `bid` int(11) NOT NULL DEFAULT '0',
  `func_id` int(11) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_blocks_weight`
--

INSERT INTO `nv3_vi_blocks_weight` VALUES
(2, 2, 1), 
(2, 36, 1), 
(2, 39, 1), 
(2, 42, 1), 
(2, 43, 1), 
(2, 27, 1), 
(2, 5, 2), 
(2, 6, 2), 
(2, 7, 2), 
(2, 13, 2), 
(2, 15, 2), 
(2, 16, 2), 
(2, 47, 1), 
(2, 46, 1), 
(2, 28, 1), 
(2, 29, 1), 
(2, 30, 1), 
(2, 31, 1), 
(2, 32, 1), 
(2, 33, 1), 
(2, 34, 1), 
(2, 17, 1), 
(2, 25, 1), 
(2, 24, 1), 
(2, 23, 1), 
(2, 22, 1), 
(2, 21, 1), 
(2, 20, 1), 
(2, 19, 1), 
(2, 18, 1), 
(2, 26, 1), 
(3, 2, 2), 
(3, 36, 2), 
(3, 39, 2), 
(3, 42, 2), 
(3, 43, 2), 
(3, 27, 2), 
(3, 5, 3), 
(3, 6, 3), 
(3, 7, 3), 
(3, 13, 3), 
(3, 15, 3), 
(3, 16, 3), 
(3, 47, 2), 
(3, 46, 2), 
(3, 28, 2), 
(3, 29, 2), 
(3, 30, 2), 
(3, 31, 2), 
(3, 32, 2), 
(3, 33, 2), 
(3, 34, 2), 
(3, 17, 2), 
(3, 25, 2), 
(3, 24, 2), 
(3, 23, 2), 
(3, 22, 2), 
(3, 21, 2), 
(3, 20, 2), 
(3, 19, 2), 
(3, 18, 2), 
(3, 26, 2), 
(4, 2, 1), 
(4, 36, 1), 
(4, 39, 1), 
(4, 42, 1), 
(4, 43, 1), 
(4, 27, 1), 
(4, 5, 1), 
(4, 6, 1), 
(4, 7, 1), 
(4, 13, 1), 
(4, 15, 1), 
(4, 16, 1), 
(4, 47, 1), 
(4, 46, 1), 
(4, 28, 1), 
(4, 29, 1), 
(4, 30, 1), 
(4, 31, 1), 
(4, 32, 1), 
(4, 33, 1), 
(4, 34, 1), 
(4, 17, 1), 
(4, 25, 1), 
(4, 24, 1), 
(4, 23, 1), 
(4, 22, 1), 
(4, 21, 1), 
(4, 20, 1), 
(4, 19, 1), 
(4, 18, 1), 
(4, 26, 1), 
(5, 2, 2), 
(5, 36, 2), 
(5, 39, 2), 
(5, 42, 2), 
(5, 43, 2), 
(5, 27, 2), 
(5, 5, 2), 
(5, 6, 2), 
(5, 7, 2), 
(5, 13, 2), 
(5, 15, 2), 
(5, 16, 2), 
(5, 47, 2), 
(5, 46, 2), 
(5, 28, 2), 
(5, 29, 2), 
(5, 30, 2), 
(5, 31, 2), 
(5, 32, 2), 
(5, 33, 2), 
(5, 34, 2), 
(5, 17, 2), 
(5, 25, 2), 
(5, 24, 2), 
(5, 23, 2), 
(5, 22, 2), 
(5, 21, 2), 
(5, 20, 2), 
(5, 19, 2), 
(5, 18, 2), 
(5, 26, 2), 
(6, 2, 3), 
(6, 36, 3), 
(6, 39, 3), 
(6, 42, 3), 
(6, 43, 3), 
(6, 27, 3), 
(6, 5, 3), 
(6, 6, 3), 
(6, 7, 3), 
(6, 13, 3), 
(6, 15, 3), 
(6, 16, 3), 
(6, 47, 3), 
(6, 46, 3), 
(6, 28, 3), 
(6, 29, 3), 
(6, 30, 3), 
(6, 31, 3), 
(6, 32, 3), 
(6, 33, 3), 
(6, 34, 3), 
(6, 17, 3), 
(6, 25, 3), 
(6, 24, 3), 
(6, 23, 3), 
(6, 22, 3), 
(6, 21, 3), 
(6, 20, 3), 
(6, 19, 3), 
(6, 18, 3), 
(6, 26, 3), 
(10, 2, 1), 
(10, 36, 1), 
(10, 39, 1), 
(10, 42, 1), 
(10, 43, 1), 
(10, 27, 1), 
(10, 5, 1), 
(10, 6, 1), 
(10, 7, 1), 
(10, 13, 1), 
(10, 15, 1), 
(10, 16, 1), 
(10, 47, 1), 
(10, 46, 1), 
(10, 28, 1), 
(10, 29, 1), 
(10, 30, 1), 
(10, 31, 1), 
(10, 32, 1), 
(10, 33, 1), 
(10, 34, 1), 
(10, 17, 1), 
(10, 25, 1), 
(10, 24, 1), 
(10, 23, 1), 
(10, 22, 1), 
(10, 21, 1), 
(10, 20, 1), 
(10, 19, 1), 
(10, 18, 1), 
(10, 26, 1), 
(11, 2, 2), 
(11, 36, 2), 
(11, 39, 2), 
(11, 42, 2), 
(11, 43, 2), 
(11, 27, 2), 
(11, 5, 2), 
(11, 6, 2), 
(11, 7, 2), 
(11, 13, 2), 
(11, 15, 2), 
(11, 16, 2), 
(11, 47, 2), 
(11, 46, 2), 
(11, 28, 2), 
(11, 29, 2), 
(11, 30, 2), 
(11, 31, 2), 
(11, 32, 2), 
(11, 33, 2), 
(11, 34, 2), 
(11, 17, 2), 
(11, 25, 2), 
(11, 24, 2), 
(11, 23, 2), 
(11, 22, 2), 
(11, 21, 2), 
(11, 20, 2), 
(11, 19, 2), 
(11, 18, 2), 
(11, 26, 2), 
(12, 2, 3), 
(12, 36, 3), 
(12, 39, 3), 
(12, 42, 3), 
(12, 43, 3), 
(12, 27, 3), 
(12, 5, 3), 
(12, 6, 3), 
(12, 7, 3), 
(12, 13, 3), 
(12, 15, 3), 
(12, 16, 3), 
(12, 47, 3), 
(12, 46, 3), 
(12, 28, 3), 
(12, 29, 3), 
(12, 30, 3), 
(12, 31, 3), 
(12, 32, 3), 
(12, 33, 3), 
(12, 34, 3), 
(12, 17, 3), 
(12, 25, 3), 
(12, 24, 3), 
(12, 23, 3), 
(12, 22, 3), 
(12, 21, 3), 
(12, 20, 3), 
(12, 19, 3), 
(12, 18, 3), 
(12, 26, 3), 
(13, 2, 4), 
(13, 36, 4), 
(13, 39, 4), 
(13, 42, 4), 
(13, 43, 4), 
(13, 27, 4), 
(13, 5, 4), 
(13, 6, 4), 
(13, 7, 4), 
(13, 13, 4), 
(13, 15, 4), 
(13, 16, 4), 
(13, 47, 4), 
(13, 46, 4), 
(13, 28, 4), 
(13, 29, 4), 
(13, 30, 4), 
(13, 31, 4), 
(13, 32, 4), 
(13, 33, 4), 
(13, 34, 4), 
(13, 17, 4), 
(13, 25, 4), 
(13, 24, 4), 
(13, 23, 4), 
(13, 22, 4), 
(13, 21, 4), 
(13, 20, 4), 
(13, 19, 4), 
(13, 18, 4), 
(13, 26, 4), 
(31, 176, 1), 
(31, 185, 1), 
(31, 177, 1), 
(31, 178, 1), 
(31, 187, 1), 
(15, 2, 1), 
(15, 36, 1), 
(15, 39, 1), 
(15, 42, 1), 
(15, 43, 1), 
(15, 27, 1), 
(15, 5, 1), 
(15, 6, 1), 
(15, 7, 1), 
(15, 13, 1), 
(15, 15, 1), 
(15, 16, 1), 
(15, 47, 1), 
(15, 46, 1), 
(15, 28, 1), 
(15, 29, 1), 
(15, 30, 1), 
(15, 31, 1), 
(15, 32, 1), 
(15, 33, 1), 
(15, 34, 1), 
(15, 17, 1), 
(15, 25, 1), 
(15, 24, 1), 
(15, 23, 1), 
(15, 22, 1), 
(15, 21, 1), 
(15, 20, 1), 
(15, 19, 1), 
(15, 18, 1), 
(15, 26, 1), 
(16, 2, 1), 
(16, 36, 1), 
(16, 39, 1), 
(16, 42, 1), 
(16, 43, 1), 
(16, 27, 1), 
(16, 5, 1), 
(16, 6, 1), 
(16, 7, 1), 
(16, 13, 1), 
(16, 15, 1), 
(16, 16, 1), 
(16, 47, 1), 
(16, 46, 1), 
(16, 33, 1), 
(16, 32, 1), 
(16, 30, 1), 
(16, 29, 1), 
(16, 31, 1), 
(16, 28, 1), 
(16, 34, 1), 
(16, 24, 1), 
(16, 20, 1), 
(16, 21, 1), 
(16, 26, 1), 
(16, 23, 1), 
(16, 18, 1), 
(16, 25, 1), 
(16, 17, 1), 
(16, 22, 1), 
(16, 19, 1), 
(17, 2, 1), 
(17, 36, 1), 
(17, 39, 1), 
(17, 42, 1), 
(17, 43, 1), 
(17, 27, 1), 
(17, 5, 1), 
(17, 6, 1), 
(17, 7, 1), 
(17, 13, 1), 
(17, 15, 1), 
(17, 16, 1), 
(17, 47, 1), 
(17, 46, 1), 
(17, 33, 1), 
(17, 32, 1), 
(17, 30, 1), 
(17, 29, 1), 
(17, 31, 1), 
(17, 28, 1), 
(17, 34, 1), 
(17, 24, 1), 
(17, 20, 1), 
(17, 21, 1), 
(17, 26, 1), 
(17, 23, 1), 
(17, 18, 1), 
(17, 25, 1), 
(17, 17, 1), 
(17, 22, 1), 
(17, 19, 1), 
(18, 2, 1), 
(18, 36, 1), 
(18, 39, 1), 
(18, 42, 1), 
(18, 43, 1), 
(18, 27, 1), 
(18, 5, 1), 
(18, 6, 1), 
(18, 7, 1), 
(18, 13, 1), 
(18, 15, 1), 
(18, 16, 1), 
(18, 47, 1), 
(18, 46, 1), 
(18, 33, 1), 
(18, 32, 1), 
(18, 30, 1), 
(18, 29, 1), 
(18, 31, 1), 
(18, 28, 1), 
(18, 34, 1), 
(18, 24, 1), 
(18, 20, 1), 
(18, 21, 1), 
(18, 26, 1), 
(18, 23, 1), 
(18, 18, 1), 
(18, 25, 1), 
(18, 17, 1), 
(18, 22, 1), 
(18, 19, 1), 
(19, 2, 1), 
(19, 36, 1), 
(19, 39, 1), 
(19, 42, 1), 
(19, 43, 1), 
(19, 27, 1), 
(19, 5, 1), 
(19, 6, 1), 
(19, 7, 1), 
(19, 13, 1), 
(19, 15, 1), 
(19, 16, 1), 
(19, 47, 1), 
(19, 46, 1), 
(19, 33, 1), 
(19, 32, 1), 
(19, 30, 1), 
(19, 29, 1), 
(19, 31, 1), 
(19, 28, 1), 
(19, 34, 1), 
(19, 24, 1), 
(19, 20, 1), 
(19, 21, 1), 
(19, 26, 1), 
(19, 23, 1), 
(19, 18, 1), 
(19, 25, 1), 
(19, 17, 1), 
(19, 22, 1), 
(19, 19, 1), 
(19, 48, 1), 
(2, 48, 1), 
(3, 48, 2), 
(17, 48, 1), 
(4, 48, 1), 
(5, 48, 2), 
(6, 48, 3), 
(18, 48, 1), 
(16, 48, 1), 
(10, 48, 1), 
(11, 48, 2), 
(12, 48, 3), 
(13, 48, 4), 
(15, 48, 1), 
(20, 2, 1), 
(20, 36, 1), 
(20, 39, 1), 
(20, 42, 1), 
(20, 43, 1), 
(20, 27, 1), 
(20, 5, 1), 
(20, 6, 1), 
(20, 7, 1), 
(20, 13, 1), 
(20, 15, 1), 
(20, 16, 1), 
(20, 47, 1), 
(20, 46, 1), 
(20, 33, 1), 
(20, 32, 1), 
(20, 30, 1), 
(20, 29, 1), 
(20, 31, 1), 
(20, 28, 1), 
(20, 34, 1), 
(20, 48, 1), 
(20, 24, 1), 
(20, 20, 1), 
(20, 21, 1), 
(20, 26, 1), 
(20, 23, 1), 
(20, 18, 1), 
(20, 25, 1), 
(20, 17, 1), 
(20, 22, 1), 
(20, 19, 1), 
(16, 35, 1), 
(10, 35, 1), 
(11, 35, 2), 
(12, 35, 3), 
(13, 35, 4), 
(15, 35, 1), 
(18, 35, 1), 
(17, 35, 1), 
(19, 35, 1), 
(2, 35, 1), 
(3, 35, 2), 
(4, 35, 1), 
(5, 35, 2), 
(6, 35, 3), 
(20, 35, 1), 
(16, 50, 1), 
(10, 50, 1), 
(11, 50, 2), 
(12, 50, 3), 
(13, 50, 4), 
(15, 50, 1), 
(18, 50, 1), 
(17, 50, 1), 
(19, 50, 1), 
(2, 50, 1), 
(3, 50, 2), 
(4, 50, 1), 
(5, 50, 2), 
(6, 50, 3), 
(20, 50, 1), 
(21, 2, 1), 
(21, 36, 1), 
(21, 39, 1), 
(21, 42, 1), 
(21, 43, 1), 
(21, 27, 1), 
(21, 5, 1), 
(21, 6, 1), 
(21, 7, 1), 
(21, 13, 1), 
(21, 15, 1), 
(21, 16, 1), 
(21, 50, 1), 
(21, 47, 1), 
(21, 46, 1), 
(21, 33, 1), 
(21, 32, 1), 
(21, 30, 1), 
(21, 29, 1), 
(21, 31, 1), 
(21, 28, 1), 
(21, 34, 1), 
(21, 48, 1), 
(21, 24, 1), 
(21, 20, 1), 
(21, 21, 1), 
(21, 26, 1), 
(21, 23, 1), 
(21, 18, 1), 
(21, 25, 1), 
(21, 17, 1), 
(21, 22, 1), 
(21, 19, 1), 
(21, 35, 1), 
(23, 2, 1), 
(23, 36, 1), 
(23, 39, 1), 
(23, 42, 1), 
(23, 43, 1), 
(23, 27, 1), 
(23, 5, 1), 
(23, 6, 1), 
(23, 7, 1), 
(23, 13, 1), 
(23, 15, 1), 
(23, 16, 1), 
(23, 50, 1), 
(23, 47, 1), 
(23, 46, 1), 
(23, 33, 1), 
(23, 32, 1), 
(23, 30, 1), 
(23, 29, 1), 
(23, 31, 1), 
(23, 28, 1), 
(23, 34, 1), 
(23, 48, 1), 
(23, 24, 1), 
(23, 20, 1), 
(23, 21, 1), 
(23, 26, 1), 
(23, 23, 1), 
(23, 18, 1), 
(23, 25, 1), 
(23, 17, 1), 
(23, 22, 1), 
(23, 19, 1), 
(23, 35, 1), 
(31, 188, 1), 
(31, 179, 1), 
(30, 176, 1), 
(30, 185, 1), 
(30, 177, 1), 
(30, 178, 1), 
(30, 187, 1), 
(30, 188, 1), 
(30, 179, 1), 
(15, 176, 1), 
(15, 185, 1), 
(15, 177, 1), 
(15, 178, 1), 
(15, 187, 1), 
(15, 188, 1), 
(15, 179, 1), 
(13, 176, 4), 
(13, 185, 4), 
(13, 177, 4), 
(13, 178, 4), 
(13, 187, 4), 
(13, 188, 4), 
(13, 179, 4), 
(12, 176, 3), 
(12, 185, 3), 
(12, 177, 3), 
(12, 178, 3), 
(12, 187, 3), 
(12, 188, 3), 
(12, 179, 3), 
(11, 176, 2), 
(11, 185, 2), 
(11, 177, 2), 
(11, 178, 2), 
(11, 187, 2), 
(11, 188, 2), 
(11, 179, 2), 
(10, 176, 1), 
(10, 185, 1), 
(10, 177, 1), 
(10, 178, 1), 
(10, 187, 1), 
(10, 188, 1), 
(10, 179, 1), 
(16, 176, 1), 
(16, 185, 1), 
(16, 177, 1), 
(16, 178, 1), 
(16, 187, 1), 
(16, 188, 1), 
(16, 179, 1), 
(18, 176, 1), 
(18, 185, 1), 
(18, 177, 1), 
(18, 178, 1), 
(18, 187, 1), 
(18, 188, 1), 
(18, 179, 1), 
(20, 176, 1), 
(20, 185, 1), 
(20, 177, 1), 
(20, 178, 1), 
(20, 187, 1), 
(20, 188, 1), 
(20, 179, 1), 
(6, 176, 3), 
(6, 185, 3), 
(6, 177, 3), 
(26, 2, 3), 
(26, 36, 3), 
(26, 39, 3), 
(26, 42, 3), 
(26, 43, 3), 
(26, 27, 3), 
(26, 5, 3), 
(26, 6, 3), 
(26, 7, 3), 
(26, 13, 3), 
(26, 15, 3), 
(26, 16, 3), 
(26, 50, 3), 
(26, 47, 3), 
(26, 46, 3), 
(26, 33, 3), 
(26, 32, 3), 
(26, 30, 3), 
(26, 29, 3), 
(26, 31, 3), 
(26, 28, 3), 
(26, 34, 3), 
(26, 48, 3), 
(26, 24, 3), 
(26, 20, 3), 
(26, 21, 3), 
(26, 26, 3), 
(26, 23, 3), 
(26, 18, 3), 
(26, 25, 3), 
(26, 17, 3), 
(26, 22, 3), 
(26, 19, 3), 
(26, 35, 3), 
(27, 2, 2), 
(27, 36, 2), 
(27, 39, 2), 
(27, 42, 2), 
(27, 43, 2), 
(27, 27, 2), 
(27, 5, 2), 
(27, 6, 2), 
(27, 7, 2), 
(27, 13, 2), 
(27, 15, 2), 
(27, 16, 2), 
(27, 50, 2), 
(27, 47, 2), 
(27, 46, 2), 
(27, 33, 2), 
(27, 32, 2), 
(27, 30, 2), 
(27, 29, 2), 
(27, 31, 2), 
(27, 28, 2), 
(27, 34, 2), 
(27, 48, 2), 
(27, 24, 2), 
(27, 20, 2), 
(27, 21, 2), 
(27, 26, 2), 
(27, 23, 2), 
(27, 18, 2), 
(27, 25, 2), 
(27, 17, 2), 
(27, 22, 2), 
(27, 19, 2), 
(27, 35, 2), 
(19, 62, 1), 
(19, 74, 1), 
(19, 58, 1), 
(19, 70, 1), 
(19, 53, 1), 
(19, 63, 1), 
(19, 64, 1), 
(19, 55, 1), 
(19, 60, 1), 
(19, 59, 1), 
(2, 62, 1), 
(2, 74, 1), 
(2, 58, 1), 
(2, 70, 1), 
(2, 53, 1), 
(2, 63, 1), 
(2, 64, 1), 
(2, 55, 1), 
(2, 60, 1), 
(2, 59, 1), 
(3, 62, 2), 
(3, 74, 2), 
(3, 58, 2), 
(3, 70, 2), 
(3, 53, 2), 
(3, 63, 2), 
(3, 64, 2), 
(3, 55, 2), 
(3, 60, 2), 
(3, 59, 2), 
(17, 62, 1), 
(17, 74, 1), 
(17, 58, 1), 
(17, 70, 1), 
(17, 53, 1), 
(17, 63, 1), 
(17, 64, 1), 
(17, 55, 1), 
(17, 60, 1), 
(17, 59, 1), 
(4, 62, 1), 
(4, 74, 1), 
(4, 58, 1), 
(4, 70, 1), 
(4, 53, 1), 
(4, 63, 1), 
(4, 64, 1), 
(4, 55, 1), 
(4, 60, 1), 
(4, 59, 1), 
(5, 62, 2), 
(5, 74, 2), 
(5, 58, 2), 
(5, 70, 2), 
(5, 53, 2), 
(5, 63, 2), 
(5, 64, 2), 
(5, 55, 2), 
(5, 60, 2), 
(5, 59, 2), 
(6, 62, 3), 
(6, 74, 3), 
(6, 58, 3), 
(6, 70, 3), 
(6, 53, 3), 
(6, 63, 3), 
(6, 64, 3), 
(6, 55, 3), 
(6, 60, 3), 
(6, 59, 3), 
(20, 62, 1), 
(20, 74, 1), 
(20, 58, 1), 
(20, 70, 1), 
(20, 53, 1), 
(20, 63, 1), 
(20, 64, 1), 
(20, 55, 1), 
(20, 60, 1), 
(20, 59, 1), 
(18, 62, 1), 
(18, 74, 1), 
(18, 58, 1), 
(18, 70, 1), 
(18, 53, 1), 
(18, 63, 1), 
(18, 64, 1), 
(18, 55, 1), 
(18, 60, 1), 
(18, 59, 1), 
(16, 62, 1), 
(16, 74, 1), 
(16, 58, 1), 
(16, 70, 1), 
(16, 53, 1), 
(16, 63, 1), 
(16, 64, 1), 
(16, 55, 1), 
(16, 60, 1), 
(16, 59, 1), 
(10, 62, 1), 
(10, 74, 1), 
(10, 58, 1), 
(10, 70, 1), 
(10, 53, 1), 
(10, 63, 1), 
(10, 64, 1), 
(10, 55, 1), 
(10, 60, 1), 
(10, 59, 1), 
(11, 62, 2), 
(11, 74, 2), 
(11, 58, 2), 
(11, 70, 2), 
(11, 53, 2), 
(11, 63, 2), 
(11, 64, 2), 
(11, 55, 2), 
(11, 60, 2), 
(11, 59, 2), 
(12, 62, 3), 
(12, 74, 3), 
(12, 58, 3), 
(12, 70, 3), 
(12, 53, 3), 
(12, 63, 3), 
(12, 64, 3), 
(12, 55, 3), 
(12, 60, 3), 
(12, 59, 3), 
(13, 62, 4), 
(13, 74, 4), 
(13, 58, 4), 
(13, 70, 4), 
(13, 53, 4), 
(13, 63, 4), 
(13, 64, 4), 
(13, 55, 4), 
(13, 60, 4), 
(13, 59, 4), 
(15, 62, 1), 
(15, 74, 1), 
(15, 58, 1), 
(15, 70, 1), 
(15, 53, 1), 
(15, 63, 1), 
(15, 64, 1), 
(15, 55, 1), 
(15, 60, 1), 
(15, 59, 1), 
(16, 114, 1), 
(13, 114, 4), 
(6, 178, 3), 
(15, 114, 1), 
(6, 187, 3), 
(27, 114, 1), 
(12, 114, 3), 
(6, 188, 3), 
(6, 179, 3), 
(5, 176, 2), 
(27, 62, 2), 
(27, 74, 2), 
(27, 58, 2), 
(27, 70, 2), 
(27, 53, 2), 
(27, 63, 2), 
(27, 64, 2), 
(27, 55, 2), 
(27, 60, 2), 
(27, 59, 2), 
(23, 62, 1), 
(23, 74, 1), 
(23, 58, 1), 
(23, 70, 1), 
(23, 53, 1), 
(23, 63, 1), 
(23, 64, 1), 
(23, 55, 1), 
(23, 60, 1), 
(23, 59, 1), 
(21, 62, 1), 
(21, 74, 1), 
(21, 58, 1), 
(21, 70, 1), 
(21, 53, 1), 
(21, 63, 1), 
(21, 64, 1), 
(21, 55, 1), 
(21, 60, 1), 
(21, 59, 1), 
(26, 62, 3), 
(26, 74, 3), 
(26, 58, 3), 
(26, 70, 3), 
(26, 53, 3), 
(26, 63, 3), 
(26, 64, 3), 
(26, 55, 3), 
(26, 60, 3), 
(26, 59, 3), 
(19, 86, 1), 
(19, 98, 1), 
(19, 82, 1), 
(19, 94, 1), 
(19, 77, 1), 
(19, 87, 1), 
(19, 88, 1), 
(19, 79, 1), 
(19, 84, 1), 
(19, 83, 1), 
(2, 86, 1), 
(2, 98, 1), 
(2, 82, 1), 
(2, 94, 1), 
(2, 77, 1), 
(2, 87, 1), 
(2, 88, 1), 
(2, 79, 1), 
(2, 84, 1), 
(2, 83, 1), 
(3, 86, 2), 
(3, 98, 2), 
(3, 82, 2), 
(3, 94, 2), 
(3, 77, 2), 
(3, 87, 2), 
(3, 88, 2), 
(3, 79, 2), 
(3, 84, 2), 
(3, 83, 2), 
(17, 86, 1), 
(17, 98, 1), 
(17, 82, 1), 
(17, 94, 1), 
(17, 77, 1), 
(17, 87, 1), 
(17, 88, 1), 
(17, 79, 1), 
(17, 84, 1), 
(17, 83, 1), 
(4, 86, 1), 
(4, 98, 1), 
(4, 82, 1), 
(4, 94, 1), 
(4, 77, 1), 
(4, 87, 1), 
(4, 88, 1), 
(4, 79, 1), 
(4, 84, 1), 
(4, 83, 1), 
(5, 86, 2), 
(5, 98, 2), 
(5, 82, 2), 
(5, 94, 2), 
(5, 77, 2), 
(5, 87, 2), 
(5, 88, 2), 
(5, 79, 2), 
(5, 84, 2), 
(5, 83, 2), 
(6, 86, 3), 
(6, 98, 3), 
(6, 82, 3), 
(6, 94, 3), 
(6, 77, 3), 
(6, 87, 3), 
(6, 88, 3), 
(6, 79, 3), 
(6, 84, 3), 
(6, 83, 3), 
(20, 86, 1), 
(20, 98, 1), 
(20, 82, 1), 
(20, 94, 1), 
(20, 77, 1), 
(20, 87, 1), 
(20, 88, 1), 
(20, 79, 1), 
(20, 84, 1), 
(20, 83, 1), 
(18, 86, 1), 
(18, 98, 1), 
(18, 82, 1), 
(18, 94, 1), 
(18, 77, 1), 
(18, 87, 1), 
(18, 88, 1), 
(18, 79, 1), 
(18, 84, 1), 
(18, 83, 1), 
(16, 86, 1), 
(16, 98, 1), 
(16, 82, 1), 
(16, 94, 1), 
(16, 77, 1), 
(16, 87, 1), 
(16, 88, 1), 
(16, 79, 1), 
(16, 84, 1), 
(16, 83, 1), 
(10, 86, 1), 
(10, 98, 1), 
(10, 82, 1), 
(10, 94, 1), 
(10, 77, 1), 
(10, 87, 1), 
(10, 88, 1), 
(10, 79, 1), 
(10, 84, 1), 
(10, 83, 1), 
(11, 86, 2), 
(11, 98, 2), 
(11, 82, 2), 
(11, 94, 2), 
(11, 77, 2), 
(11, 87, 2), 
(11, 88, 2), 
(11, 79, 2), 
(11, 84, 2), 
(11, 83, 2), 
(12, 86, 3), 
(12, 98, 3), 
(12, 82, 3), 
(12, 94, 3), 
(12, 77, 3), 
(12, 87, 3), 
(12, 88, 3), 
(12, 79, 3), 
(12, 84, 3), 
(12, 83, 3), 
(13, 86, 4), 
(13, 98, 4), 
(13, 82, 4), 
(13, 94, 4), 
(13, 77, 4), 
(13, 87, 4), 
(13, 88, 4), 
(13, 79, 4), 
(13, 84, 4), 
(13, 83, 4), 
(15, 86, 1), 
(15, 98, 1), 
(15, 82, 1), 
(15, 94, 1), 
(15, 77, 1), 
(15, 87, 1), 
(15, 88, 1), 
(15, 79, 1), 
(15, 84, 1), 
(15, 83, 1), 
(19, 115, 1), 
(2, 123, 1), 
(17, 114, 1), 
(2, 120, 1), 
(11, 114, 2), 
(2, 117, 1), 
(2, 119, 1), 
(10, 114, 1), 
(19, 114, 1), 
(3, 114, 2), 
(27, 86, 2), 
(27, 98, 2), 
(27, 82, 2), 
(27, 94, 2), 
(27, 77, 2), 
(27, 87, 2), 
(27, 88, 2), 
(27, 79, 2), 
(27, 84, 2), 
(27, 83, 2), 
(23, 86, 1), 
(23, 98, 1), 
(23, 82, 1), 
(23, 94, 1), 
(23, 77, 1), 
(23, 87, 1), 
(23, 88, 1), 
(23, 79, 1), 
(23, 84, 1), 
(23, 83, 1), 
(21, 86, 1), 
(21, 98, 1), 
(21, 82, 1), 
(21, 94, 1), 
(21, 77, 1), 
(21, 87, 1), 
(21, 88, 1), 
(21, 79, 1), 
(21, 84, 1), 
(21, 83, 1), 
(5, 185, 2), 
(26, 86, 3), 
(26, 98, 3), 
(26, 82, 3), 
(26, 94, 3), 
(26, 77, 3), 
(26, 87, 3), 
(26, 88, 3), 
(26, 79, 3), 
(26, 84, 3), 
(26, 83, 3), 
(19, 104, 1), 
(19, 113, 1), 
(19, 112, 1), 
(19, 103, 1), 
(19, 102, 1), 
(19, 110, 1), 
(19, 101, 1), 
(2, 104, 1), 
(2, 113, 1), 
(2, 112, 1), 
(2, 103, 1), 
(2, 102, 1), 
(2, 110, 1), 
(2, 101, 1), 
(3, 104, 2), 
(3, 113, 2), 
(3, 112, 2), 
(3, 103, 2), 
(3, 102, 2), 
(3, 110, 2), 
(3, 101, 2), 
(17, 104, 1), 
(17, 113, 1), 
(17, 112, 1), 
(17, 103, 1), 
(17, 102, 1), 
(17, 110, 1), 
(17, 101, 1), 
(4, 104, 1), 
(4, 113, 1), 
(4, 112, 1), 
(4, 103, 1), 
(4, 102, 1), 
(4, 110, 1), 
(4, 101, 1), 
(5, 104, 2), 
(5, 113, 2), 
(5, 112, 2), 
(5, 103, 2), 
(5, 102, 2), 
(5, 110, 2), 
(5, 101, 2), 
(6, 104, 3), 
(6, 113, 3), 
(6, 112, 3), 
(6, 103, 3), 
(6, 102, 3), 
(6, 110, 3), 
(6, 101, 3), 
(20, 104, 1), 
(20, 113, 1), 
(20, 112, 1), 
(20, 103, 1), 
(20, 102, 1), 
(20, 110, 1), 
(20, 101, 1), 
(18, 104, 1), 
(18, 113, 1), 
(18, 112, 1), 
(18, 103, 1), 
(18, 102, 1), 
(18, 110, 1), 
(18, 101, 1), 
(16, 104, 1), 
(16, 113, 1), 
(16, 112, 1), 
(16, 103, 1), 
(16, 102, 1), 
(16, 110, 1), 
(16, 101, 1), 
(10, 104, 1), 
(10, 113, 1), 
(10, 112, 1), 
(10, 103, 1), 
(10, 102, 1), 
(10, 110, 1), 
(10, 101, 1), 
(11, 104, 2), 
(11, 113, 2), 
(11, 112, 2), 
(11, 103, 2), 
(11, 102, 2), 
(11, 110, 2), 
(11, 101, 2), 
(12, 104, 3), 
(12, 113, 3), 
(12, 112, 3), 
(12, 103, 3), 
(12, 102, 3), 
(12, 110, 3), 
(12, 101, 3), 
(13, 104, 4), 
(13, 113, 4), 
(13, 112, 4), 
(13, 103, 4), 
(13, 102, 4), 
(13, 110, 4), 
(13, 101, 4), 
(15, 104, 1), 
(15, 113, 1), 
(15, 112, 1), 
(15, 103, 1), 
(15, 102, 1), 
(15, 110, 1), 
(15, 101, 1), 
(5, 114, 2), 
(2, 122, 1), 
(20, 114, 1), 
(4, 114, 1), 
(23, 114, 1), 
(6, 114, 3), 
(2, 121, 1), 
(27, 104, 2), 
(27, 113, 2), 
(27, 112, 2), 
(27, 103, 2), 
(27, 102, 2), 
(27, 110, 2), 
(27, 101, 2), 
(23, 104, 1), 
(23, 113, 1), 
(23, 112, 1), 
(23, 103, 1), 
(23, 102, 1), 
(23, 110, 1), 
(23, 101, 1), 
(21, 104, 1), 
(21, 113, 1), 
(21, 112, 1), 
(21, 103, 1), 
(21, 102, 1), 
(21, 110, 1), 
(21, 101, 1), 
(5, 177, 2), 
(5, 178, 2), 
(5, 187, 2), 
(5, 188, 2), 
(5, 179, 2), 
(4, 176, 1), 
(4, 185, 1), 
(26, 104, 3), 
(26, 113, 3), 
(26, 112, 3), 
(26, 103, 3), 
(26, 102, 3), 
(26, 110, 3), 
(26, 101, 3), 
(4, 177, 1), 
(4, 178, 1), 
(2, 114, 1), 
(26, 114, 3), 
(19, 123, 1), 
(19, 120, 1), 
(21, 114, 1), 
(19, 117, 1), 
(19, 122, 1), 
(4, 187, 1), 
(19, 118, 1), 
(19, 119, 1), 
(19, 121, 1), 
(18, 114, 1), 
(2, 118, 1), 
(2, 115, 1), 
(3, 117, 2), 
(3, 119, 2), 
(3, 120, 2), 
(3, 123, 2), 
(3, 121, 2), 
(3, 122, 2), 
(3, 118, 2), 
(3, 115, 2), 
(17, 117, 1), 
(17, 119, 1), 
(17, 120, 1), 
(17, 123, 1), 
(17, 121, 1), 
(17, 122, 1), 
(17, 118, 1), 
(17, 115, 1), 
(4, 117, 1), 
(4, 119, 1), 
(4, 120, 1), 
(4, 123, 1), 
(4, 121, 1), 
(4, 122, 1), 
(4, 118, 1), 
(4, 115, 1), 
(5, 117, 2), 
(5, 119, 2), 
(5, 120, 2), 
(5, 123, 2), 
(5, 121, 2), 
(5, 122, 2), 
(5, 118, 2), 
(5, 115, 2), 
(6, 117, 3), 
(6, 119, 3), 
(6, 120, 3), 
(6, 123, 3), 
(6, 121, 3), 
(6, 122, 3), 
(6, 118, 3), 
(6, 115, 3), 
(20, 117, 1), 
(20, 119, 1), 
(20, 120, 1), 
(20, 123, 1), 
(20, 121, 1), 
(20, 122, 1), 
(20, 118, 1), 
(20, 115, 1), 
(18, 117, 1), 
(18, 119, 1), 
(18, 120, 1), 
(18, 123, 1), 
(18, 121, 1), 
(18, 122, 1), 
(18, 118, 1), 
(18, 115, 1), 
(16, 117, 1), 
(16, 119, 1), 
(16, 120, 1), 
(16, 123, 1), 
(16, 121, 1), 
(16, 122, 1), 
(16, 118, 1), 
(16, 115, 1), 
(10, 117, 1), 
(10, 119, 1), 
(10, 120, 1), 
(10, 123, 1), 
(10, 121, 1), 
(10, 122, 1), 
(10, 118, 1), 
(10, 115, 1), 
(11, 117, 2), 
(11, 119, 2), 
(11, 120, 2), 
(11, 123, 2), 
(11, 121, 2), 
(11, 122, 2), 
(11, 118, 2), 
(11, 115, 2), 
(12, 117, 3), 
(12, 119, 3), 
(12, 120, 3), 
(12, 123, 3), 
(12, 121, 3), 
(12, 122, 3), 
(12, 118, 3), 
(12, 115, 3), 
(13, 117, 4), 
(13, 119, 4), 
(13, 120, 4), 
(13, 123, 4), 
(13, 121, 4), 
(13, 122, 4), 
(13, 118, 4), 
(13, 115, 4), 
(15, 117, 1), 
(15, 119, 1), 
(15, 120, 1), 
(15, 123, 1), 
(15, 121, 1), 
(15, 122, 1), 
(15, 118, 1), 
(15, 115, 1), 
(27, 117, 2), 
(27, 119, 1), 
(27, 120, 1), 
(27, 123, 1), 
(27, 121, 1), 
(27, 122, 1), 
(27, 118, 1), 
(27, 115, 1), 
(23, 117, 1), 
(23, 119, 1), 
(23, 120, 1), 
(23, 123, 1), 
(23, 121, 1), 
(23, 122, 1), 
(23, 118, 1), 
(23, 115, 1), 
(21, 117, 1), 
(21, 119, 1), 
(21, 120, 1), 
(21, 123, 1), 
(21, 121, 1), 
(21, 122, 1), 
(21, 118, 1), 
(21, 115, 1), 
(4, 188, 1), 
(4, 179, 1), 
(17, 176, 1), 
(17, 185, 1), 
(17, 177, 1), 
(17, 178, 1), 
(17, 187, 1), 
(17, 188, 1), 
(26, 117, 3), 
(26, 119, 3), 
(26, 120, 3), 
(26, 123, 3), 
(26, 121, 3), 
(26, 122, 3), 
(26, 118, 3), 
(26, 115, 3), 
(30, 2, 1), 
(30, 117, 1), 
(30, 119, 1), 
(30, 120, 1), 
(30, 123, 1), 
(30, 121, 1), 
(30, 122, 1), 
(30, 118, 1), 
(30, 115, 1), 
(30, 36, 1), 
(30, 39, 1), 
(30, 42, 1), 
(30, 43, 1), 
(30, 27, 1), 
(30, 5, 1), 
(30, 6, 1), 
(30, 7, 1), 
(30, 13, 1), 
(30, 15, 1), 
(30, 16, 1), 
(30, 50, 1), 
(30, 47, 1), 
(30, 46, 1), 
(30, 33, 1), 
(30, 32, 1), 
(30, 30, 1), 
(30, 29, 1), 
(30, 31, 1), 
(30, 28, 1), 
(30, 34, 1), 
(30, 48, 1), 
(30, 24, 1), 
(30, 20, 1), 
(30, 21, 1), 
(30, 26, 1), 
(30, 23, 1), 
(30, 18, 1), 
(30, 25, 1), 
(30, 17, 1), 
(30, 22, 1), 
(30, 19, 1), 
(30, 35, 1), 
(19, 135, 1), 
(19, 147, 1), 
(19, 131, 1), 
(19, 143, 1), 
(19, 126, 1), 
(19, 136, 1), 
(19, 137, 1), 
(19, 128, 1), 
(19, 133, 1), 
(19, 132, 1), 
(2, 135, 1), 
(2, 147, 1), 
(2, 131, 1), 
(2, 143, 1), 
(2, 126, 1), 
(2, 136, 1), 
(2, 137, 1), 
(2, 128, 1), 
(2, 133, 1), 
(2, 132, 1), 
(3, 135, 2), 
(3, 147, 2), 
(3, 131, 2), 
(3, 143, 2), 
(3, 126, 2), 
(3, 136, 2), 
(3, 137, 2), 
(3, 128, 2), 
(3, 133, 2), 
(3, 132, 2), 
(17, 135, 1), 
(17, 147, 1), 
(17, 131, 1), 
(17, 143, 1), 
(17, 126, 1), 
(17, 136, 1), 
(17, 137, 1), 
(17, 128, 1), 
(17, 133, 1), 
(17, 132, 1), 
(4, 135, 1), 
(4, 147, 1), 
(4, 131, 1), 
(4, 143, 1), 
(4, 126, 1), 
(4, 136, 1), 
(4, 137, 1), 
(4, 128, 1), 
(4, 133, 1), 
(4, 132, 1), 
(5, 135, 2), 
(5, 147, 2), 
(5, 131, 2), 
(5, 143, 2), 
(5, 126, 2), 
(5, 136, 2), 
(5, 137, 2), 
(5, 128, 2), 
(5, 133, 2), 
(5, 132, 2), 
(6, 135, 3), 
(6, 147, 3), 
(6, 131, 3), 
(6, 143, 3), 
(6, 126, 3), 
(6, 136, 3), 
(6, 137, 3), 
(6, 128, 3), 
(6, 133, 3), 
(6, 132, 3), 
(20, 135, 1), 
(20, 147, 1), 
(20, 131, 1), 
(20, 143, 1), 
(20, 126, 1), 
(20, 136, 1), 
(20, 137, 1), 
(20, 128, 1), 
(20, 133, 1), 
(20, 132, 1), 
(18, 135, 1), 
(18, 147, 1), 
(18, 131, 1), 
(18, 143, 1), 
(18, 126, 1), 
(18, 136, 1), 
(18, 137, 1), 
(18, 128, 1), 
(18, 133, 1), 
(18, 132, 1), 
(16, 135, 1), 
(16, 147, 1), 
(16, 131, 1), 
(16, 143, 1), 
(16, 126, 1), 
(16, 136, 1), 
(16, 137, 1), 
(16, 128, 1), 
(16, 133, 1), 
(16, 132, 1), 
(10, 135, 1), 
(10, 147, 1), 
(10, 131, 1), 
(10, 143, 1), 
(10, 126, 1), 
(10, 136, 1), 
(10, 137, 1), 
(10, 128, 1), 
(10, 133, 1), 
(10, 132, 1), 
(11, 135, 2), 
(11, 147, 2), 
(11, 131, 2), 
(11, 143, 2), 
(11, 126, 2), 
(11, 136, 2), 
(11, 137, 2), 
(11, 128, 2), 
(11, 133, 2), 
(11, 132, 2), 
(12, 135, 3), 
(12, 147, 3), 
(12, 131, 3), 
(12, 143, 3), 
(12, 126, 3), 
(12, 136, 3), 
(12, 137, 3), 
(12, 128, 3), 
(12, 133, 3), 
(12, 132, 3), 
(13, 135, 4), 
(13, 147, 4), 
(13, 131, 4), 
(13, 143, 4), 
(13, 126, 4), 
(13, 136, 4), 
(13, 137, 4), 
(13, 128, 4), 
(13, 133, 4), 
(13, 132, 4), 
(15, 135, 1), 
(15, 147, 1), 
(15, 131, 1), 
(15, 143, 1), 
(15, 126, 1), 
(15, 136, 1), 
(15, 137, 1), 
(15, 128, 1), 
(15, 133, 1), 
(15, 132, 1), 
(30, 135, 1), 
(30, 147, 1), 
(30, 131, 1), 
(30, 143, 1), 
(30, 126, 1), 
(30, 136, 1), 
(30, 137, 1), 
(30, 128, 1), 
(30, 133, 1), 
(30, 132, 1), 
(27, 135, 1), 
(27, 147, 1), 
(27, 131, 1), 
(27, 143, 1), 
(27, 126, 1), 
(27, 136, 1), 
(27, 137, 1), 
(27, 128, 1), 
(27, 133, 1), 
(27, 132, 1), 
(23, 135, 1), 
(23, 147, 1), 
(23, 131, 1), 
(23, 143, 1), 
(23, 126, 1), 
(23, 136, 1), 
(23, 137, 1), 
(23, 128, 1), 
(23, 133, 1), 
(23, 132, 1), 
(21, 135, 1), 
(21, 147, 1), 
(21, 131, 1), 
(21, 143, 1), 
(21, 126, 1), 
(21, 136, 1), 
(21, 137, 1), 
(21, 128, 1), 
(21, 133, 1), 
(21, 132, 1), 
(17, 179, 1), 
(3, 176, 2), 
(3, 185, 2), 
(3, 177, 2), 
(3, 178, 2), 
(3, 187, 2), 
(3, 188, 2), 
(3, 179, 2), 
(2, 176, 1), 
(2, 185, 1), 
(26, 135, 3), 
(26, 147, 3), 
(26, 131, 3), 
(26, 143, 3), 
(26, 126, 3), 
(26, 136, 3), 
(26, 137, 3), 
(26, 128, 3), 
(26, 133, 3), 
(26, 132, 3), 
(19, 159, 1), 
(19, 171, 1), 
(19, 155, 1), 
(19, 167, 1), 
(19, 150, 1), 
(19, 160, 1), 
(19, 161, 1), 
(19, 152, 1), 
(19, 157, 1), 
(19, 156, 1), 
(2, 159, 1), 
(2, 171, 1), 
(2, 155, 1), 
(2, 167, 1), 
(2, 150, 1), 
(2, 160, 1), 
(2, 161, 1), 
(2, 152, 1), 
(2, 157, 1), 
(2, 156, 1), 
(3, 159, 2), 
(3, 171, 2), 
(3, 155, 2), 
(3, 167, 2), 
(3, 150, 2), 
(3, 160, 2), 
(3, 161, 2), 
(3, 152, 2), 
(3, 157, 2), 
(3, 156, 2), 
(17, 159, 1), 
(17, 171, 1), 
(17, 155, 1), 
(17, 167, 1), 
(17, 150, 1), 
(17, 160, 1), 
(17, 161, 1), 
(17, 152, 1), 
(17, 157, 1), 
(17, 156, 1), 
(4, 159, 1), 
(4, 171, 1), 
(4, 155, 1), 
(4, 167, 1), 
(4, 150, 1), 
(4, 160, 1), 
(4, 161, 1), 
(4, 152, 1), 
(4, 157, 1), 
(4, 156, 1), 
(5, 159, 2), 
(5, 171, 2), 
(5, 155, 2), 
(5, 167, 2), 
(5, 150, 2), 
(5, 160, 2), 
(5, 161, 2), 
(5, 152, 2), 
(5, 157, 2), 
(5, 156, 2), 
(6, 159, 3), 
(6, 171, 3), 
(6, 155, 3), 
(6, 167, 3), 
(6, 150, 3), 
(6, 160, 3), 
(6, 161, 3), 
(6, 152, 3), 
(6, 157, 3), 
(6, 156, 3), 
(20, 159, 1), 
(20, 171, 1), 
(20, 155, 1), 
(20, 167, 1), 
(20, 150, 1), 
(20, 160, 1), 
(20, 161, 1), 
(20, 152, 1), 
(20, 157, 1), 
(20, 156, 1), 
(18, 159, 1), 
(18, 171, 1), 
(18, 155, 1), 
(18, 167, 1), 
(18, 150, 1), 
(18, 160, 1), 
(18, 161, 1), 
(18, 152, 1), 
(18, 157, 1), 
(18, 156, 1), 
(16, 159, 1), 
(16, 171, 1), 
(16, 155, 1), 
(16, 167, 1), 
(16, 150, 1), 
(16, 160, 1), 
(16, 161, 1), 
(16, 152, 1), 
(16, 157, 1), 
(16, 156, 1), 
(10, 159, 1), 
(10, 171, 1), 
(10, 155, 1), 
(10, 167, 1), 
(10, 150, 1), 
(10, 160, 1), 
(10, 161, 1), 
(10, 152, 1), 
(10, 157, 1), 
(10, 156, 1), 
(11, 159, 2), 
(11, 171, 2), 
(11, 155, 2), 
(11, 167, 2), 
(11, 150, 2), 
(11, 160, 2), 
(11, 161, 2), 
(11, 152, 2), 
(11, 157, 2), 
(11, 156, 2), 
(12, 159, 3), 
(12, 171, 3), 
(12, 155, 3), 
(12, 167, 3), 
(12, 150, 3), 
(12, 160, 3), 
(12, 161, 3), 
(12, 152, 3), 
(12, 157, 3), 
(12, 156, 3), 
(13, 159, 4), 
(13, 171, 4), 
(13, 155, 4), 
(13, 167, 4), 
(13, 150, 4), 
(13, 160, 4), 
(13, 161, 4), 
(13, 152, 4), 
(13, 157, 4), 
(13, 156, 4), 
(15, 159, 1), 
(15, 171, 1), 
(15, 155, 1), 
(15, 167, 1), 
(15, 150, 1), 
(15, 160, 1), 
(15, 161, 1), 
(15, 152, 1), 
(15, 157, 1), 
(15, 156, 1), 
(30, 159, 1), 
(30, 171, 1), 
(30, 155, 1), 
(30, 167, 1), 
(30, 150, 1), 
(30, 160, 1), 
(30, 161, 1), 
(30, 152, 1), 
(30, 157, 1), 
(30, 156, 1), 
(27, 159, 1), 
(27, 171, 1), 
(27, 155, 1), 
(27, 167, 1), 
(27, 150, 1), 
(27, 160, 1), 
(27, 161, 1), 
(27, 152, 1), 
(27, 157, 1), 
(27, 156, 1), 
(23, 159, 1), 
(23, 171, 1), 
(23, 155, 1), 
(23, 167, 1), 
(23, 150, 1), 
(23, 160, 1), 
(23, 161, 1), 
(23, 152, 1), 
(23, 157, 1), 
(23, 156, 1), 
(21, 159, 1), 
(21, 171, 1), 
(21, 155, 1), 
(21, 167, 1), 
(21, 150, 1), 
(21, 160, 1), 
(21, 161, 1), 
(21, 152, 1), 
(21, 157, 1), 
(21, 156, 1), 
(2, 177, 1), 
(2, 178, 1), 
(2, 187, 1), 
(2, 188, 1), 
(2, 179, 1), 
(19, 176, 1), 
(19, 185, 1), 
(19, 177, 1), 
(19, 178, 1), 
(19, 187, 1), 
(26, 159, 3), 
(26, 171, 3), 
(26, 155, 3), 
(26, 167, 3), 
(26, 150, 3), 
(26, 160, 3), 
(26, 161, 3), 
(26, 152, 3), 
(26, 157, 3), 
(26, 156, 3), 
(19, 172, 1), 
(2, 172, 1), 
(3, 172, 2), 
(17, 172, 1), 
(4, 172, 1), 
(5, 172, 2), 
(6, 172, 3), 
(20, 172, 1), 
(18, 172, 1), 
(16, 172, 1), 
(10, 172, 1), 
(11, 172, 2), 
(12, 172, 3), 
(13, 172, 4), 
(15, 172, 1), 
(30, 172, 1), 
(27, 172, 1), 
(23, 172, 1), 
(21, 172, 1), 
(19, 188, 1), 
(26, 172, 3), 
(19, 173, 1), 
(2, 173, 1), 
(3, 173, 2), 
(17, 173, 1), 
(4, 173, 1), 
(5, 173, 2), 
(6, 173, 3), 
(20, 173, 1), 
(18, 173, 1), 
(16, 173, 1), 
(10, 173, 1), 
(11, 173, 2), 
(12, 173, 3), 
(13, 173, 4), 
(15, 173, 1), 
(30, 173, 1), 
(27, 173, 1), 
(23, 173, 1), 
(21, 173, 1), 
(19, 179, 1), 
(26, 173, 3), 
(31, 2, 1), 
(31, 117, 1), 
(31, 119, 1), 
(31, 120, 1), 
(31, 123, 1), 
(31, 121, 1), 
(31, 122, 1), 
(31, 118, 1), 
(31, 115, 1), 
(31, 36, 1), 
(31, 39, 1), 
(31, 42, 1), 
(31, 43, 1), 
(31, 27, 1), 
(31, 173, 1), 
(31, 7, 1), 
(31, 16, 1), 
(31, 15, 1), 
(31, 50, 1), 
(31, 6, 1), 
(31, 13, 1), 
(31, 5, 1), 
(31, 47, 1), 
(31, 46, 1), 
(31, 135, 1), 
(31, 147, 1), 
(31, 131, 1), 
(31, 143, 1), 
(31, 126, 1), 
(31, 136, 1), 
(31, 137, 1), 
(31, 128, 1), 
(31, 133, 1), 
(31, 132, 1), 
(31, 33, 1), 
(31, 32, 1), 
(31, 30, 1), 
(31, 29, 1), 
(31, 31, 1), 
(31, 28, 1), 
(31, 34, 1), 
(31, 48, 1), 
(31, 24, 1), 
(31, 20, 1), 
(31, 21, 1), 
(31, 26, 1), 
(31, 23, 1), 
(31, 18, 1), 
(31, 25, 1), 
(31, 17, 1), 
(31, 22, 1), 
(31, 19, 1), 
(31, 35, 1), 
(27, 179, 1), 
(27, 188, 1), 
(27, 187, 1), 
(27, 178, 1), 
(27, 177, 1), 
(27, 185, 1), 
(27, 176, 1), 
(23, 179, 1), 
(23, 188, 1), 
(23, 187, 1), 
(23, 178, 1), 
(23, 177, 1), 
(23, 185, 1), 
(23, 176, 1), 
(21, 179, 1), 
(21, 188, 1), 
(21, 187, 1), 
(21, 178, 1), 
(21, 177, 1), 
(21, 185, 1), 
(21, 176, 1), 
(26, 179, 2), 
(26, 188, 2), 
(26, 187, 2), 
(26, 178, 2), 
(26, 177, 2), 
(26, 185, 2), 
(26, 176, 2), 
(19, 194, 1), 
(19, 203, 1), 
(19, 202, 1), 
(19, 193, 1), 
(19, 192, 1), 
(19, 200, 1), 
(19, 191, 1), 
(2, 194, 1), 
(2, 203, 1), 
(2, 202, 1), 
(2, 193, 1), 
(2, 192, 1), 
(2, 200, 1), 
(2, 191, 1), 
(3, 194, 2), 
(3, 203, 2), 
(3, 202, 2), 
(3, 193, 2), 
(3, 192, 2), 
(3, 200, 2), 
(3, 191, 2), 
(17, 194, 1), 
(17, 203, 1), 
(17, 202, 1), 
(17, 193, 1), 
(17, 192, 1), 
(17, 200, 1), 
(17, 191, 1), 
(4, 194, 1), 
(4, 203, 1), 
(4, 202, 1), 
(4, 193, 1), 
(4, 192, 1), 
(4, 200, 1), 
(4, 191, 1), 
(5, 194, 2), 
(5, 203, 2), 
(5, 202, 2), 
(5, 193, 2), 
(5, 192, 2), 
(5, 200, 2), 
(5, 191, 2), 
(6, 194, 3), 
(6, 203, 3), 
(6, 202, 3), 
(6, 193, 3), 
(6, 192, 3), 
(6, 200, 3), 
(6, 191, 3), 
(20, 194, 1), 
(20, 203, 1), 
(20, 202, 1), 
(20, 193, 1), 
(20, 192, 1), 
(20, 200, 1), 
(20, 191, 1), 
(18, 194, 1), 
(18, 203, 1), 
(18, 202, 1), 
(18, 193, 1), 
(18, 192, 1), 
(18, 200, 1), 
(18, 191, 1), 
(16, 194, 1), 
(16, 203, 1), 
(16, 202, 1), 
(16, 193, 1), 
(16, 192, 1), 
(16, 200, 1), 
(16, 191, 1), 
(10, 194, 1), 
(10, 203, 1), 
(10, 202, 1), 
(10, 193, 1), 
(10, 192, 1), 
(10, 200, 1), 
(10, 191, 1), 
(11, 194, 2), 
(11, 203, 2), 
(11, 202, 2), 
(11, 193, 2), 
(11, 192, 2), 
(11, 200, 2), 
(11, 191, 2), 
(12, 194, 3), 
(12, 203, 3), 
(12, 202, 3), 
(12, 193, 3), 
(12, 192, 3), 
(12, 200, 3), 
(12, 191, 3), 
(13, 194, 4), 
(13, 203, 4), 
(13, 202, 4), 
(13, 193, 4), 
(13, 192, 4), 
(13, 200, 4), 
(13, 191, 4), 
(15, 194, 1), 
(15, 203, 1), 
(15, 202, 1), 
(15, 193, 1), 
(15, 192, 1), 
(15, 200, 1), 
(15, 191, 1), 
(30, 194, 1), 
(30, 203, 1), 
(30, 202, 1), 
(30, 193, 1), 
(30, 192, 1), 
(30, 200, 1), 
(30, 191, 1), 
(31, 194, 1), 
(31, 203, 1), 
(31, 202, 1), 
(31, 193, 1), 
(31, 192, 1), 
(31, 200, 1), 
(31, 191, 1), 
(27, 194, 1), 
(27, 203, 1), 
(27, 202, 1), 
(27, 193, 1), 
(27, 192, 1), 
(27, 200, 1), 
(27, 191, 1), 
(23, 194, 1), 
(23, 203, 1), 
(23, 202, 1), 
(23, 193, 1), 
(23, 192, 1), 
(23, 200, 1), 
(23, 191, 1), 
(21, 194, 1), 
(21, 203, 1), 
(21, 202, 1), 
(21, 193, 1), 
(21, 192, 1), 
(21, 200, 1), 
(21, 191, 1), 
(26, 194, 2), 
(26, 203, 2), 
(26, 202, 2), 
(26, 193, 2), 
(26, 192, 2), 
(26, 200, 2), 
(26, 191, 2), 
(19, 209, 1), 
(19, 218, 1), 
(19, 217, 1), 
(19, 208, 1), 
(19, 207, 1), 
(19, 215, 1), 
(19, 206, 1), 
(2, 209, 1), 
(2, 218, 1), 
(2, 217, 1), 
(2, 208, 1), 
(2, 207, 1), 
(2, 215, 1), 
(2, 206, 1), 
(3, 209, 2), 
(3, 218, 2), 
(3, 217, 2), 
(3, 208, 2), 
(3, 207, 2), 
(3, 215, 2), 
(3, 206, 2), 
(17, 209, 1), 
(17, 218, 1), 
(17, 217, 1), 
(17, 208, 1), 
(17, 207, 1), 
(17, 215, 1), 
(17, 206, 1), 
(4, 209, 1), 
(4, 218, 1), 
(4, 217, 1), 
(4, 208, 1), 
(4, 207, 1), 
(4, 215, 1), 
(4, 206, 1), 
(5, 209, 2), 
(5, 218, 2), 
(5, 217, 2), 
(5, 208, 2), 
(5, 207, 2), 
(5, 215, 2), 
(5, 206, 2), 
(6, 209, 3), 
(6, 218, 3), 
(6, 217, 3), 
(6, 208, 3), 
(6, 207, 3), 
(6, 215, 3), 
(6, 206, 3), 
(20, 209, 1), 
(20, 218, 1), 
(20, 217, 1), 
(20, 208, 1), 
(20, 207, 1), 
(20, 215, 1), 
(20, 206, 1), 
(18, 209, 1), 
(18, 218, 1), 
(18, 217, 1), 
(18, 208, 1), 
(18, 207, 1), 
(18, 215, 1), 
(18, 206, 1), 
(16, 209, 1), 
(16, 218, 1), 
(16, 217, 1), 
(16, 208, 1), 
(16, 207, 1), 
(16, 215, 1), 
(16, 206, 1), 
(10, 209, 1), 
(10, 218, 1), 
(10, 217, 1), 
(10, 208, 1), 
(10, 207, 1), 
(10, 215, 1), 
(10, 206, 1), 
(11, 209, 2), 
(11, 218, 2), 
(11, 217, 2), 
(11, 208, 2), 
(11, 207, 2), 
(11, 215, 2), 
(11, 206, 2), 
(12, 209, 3), 
(12, 218, 3), 
(12, 217, 3), 
(12, 208, 3), 
(12, 207, 3), 
(12, 215, 3), 
(12, 206, 3), 
(13, 209, 4), 
(13, 218, 4), 
(13, 217, 4), 
(13, 208, 4), 
(13, 207, 4), 
(13, 215, 4), 
(13, 206, 4), 
(15, 209, 1), 
(15, 218, 1), 
(15, 217, 1), 
(15, 208, 1), 
(15, 207, 1), 
(15, 215, 1), 
(15, 206, 1), 
(30, 209, 1), 
(30, 218, 1), 
(30, 217, 1), 
(30, 208, 1), 
(30, 207, 1), 
(30, 215, 1), 
(30, 206, 1), 
(31, 209, 1), 
(31, 218, 1), 
(31, 217, 1), 
(31, 208, 1), 
(31, 207, 1), 
(31, 215, 1), 
(31, 206, 1), 
(27, 209, 1), 
(27, 218, 1), 
(27, 217, 1), 
(27, 208, 1), 
(27, 207, 1), 
(27, 215, 1), 
(27, 206, 1), 
(23, 209, 1), 
(23, 218, 1), 
(23, 217, 1), 
(23, 208, 1), 
(23, 207, 1), 
(23, 215, 1), 
(23, 206, 1), 
(21, 209, 1), 
(21, 218, 1), 
(21, 217, 1), 
(21, 208, 1), 
(21, 207, 1), 
(21, 215, 1), 
(21, 206, 1), 
(26, 209, 2), 
(26, 218, 2), 
(26, 217, 2), 
(26, 208, 2), 
(26, 207, 2), 
(26, 215, 2), 
(26, 206, 2), 
(46, 2, 2), 
(46, 36, 2), 
(46, 39, 2), 
(46, 42, 2), 
(46, 43, 2), 
(46, 27, 2), 
(46, 173, 2), 
(46, 194, 2), 
(46, 203, 2), 
(46, 202, 2), 
(46, 193, 2), 
(46, 192, 2), 
(46, 200, 2), 
(46, 191, 2), 
(46, 179, 2), 
(46, 188, 2), 
(46, 187, 2), 
(46, 178, 2), 
(46, 177, 2), 
(46, 185, 2), 
(46, 176, 2), 
(46, 47, 2), 
(46, 46, 2), 
(57, 43, 4), 
(57, 2, 4), 
(57, 194, 4), 
(57, 36, 4), 
(57, 202, 4), 
(57, 42, 4), 
(57, 39, 4), 
(57, 203, 4), 
(57, 27, 4), 
(57, 173, 4), 
(46, 33, 2), 
(46, 32, 2), 
(46, 30, 2), 
(46, 29, 2), 
(46, 31, 2), 
(46, 28, 2), 
(46, 34, 2), 
(46, 209, 2), 
(46, 218, 2), 
(46, 217, 2), 
(46, 208, 2), 
(46, 207, 2), 
(46, 215, 2), 
(46, 206, 2), 
(46, 24, 2), 
(46, 48, 2), 
(46, 20, 2), 
(46, 21, 2), 
(46, 26, 2), 
(46, 23, 2), 
(46, 18, 2), 
(46, 25, 2), 
(46, 17, 2), 
(46, 22, 2), 
(46, 19, 2), 
(46, 35, 2), 
(56, 35, 3), 
(56, 36, 3), 
(56, 27, 3), 
(56, 43, 3), 
(56, 2, 3), 
(55, 173, 3), 
(51, 173, 1), 
(56, 200, 3), 
(56, 192, 3), 
(56, 193, 3), 
(56, 202, 3), 
(56, 203, 3), 
(56, 194, 3), 
(56, 191, 3), 
(56, 185, 3), 
(56, 177, 3), 
(56, 178, 3), 
(56, 187, 3), 
(56, 188, 3), 
(56, 179, 3), 
(56, 176, 3), 
(56, 209, 3), 
(56, 42, 3), 
(56, 32, 3), 
(56, 31, 3), 
(56, 47, 3), 
(56, 21, 3), 
(56, 33, 3), 
(56, 217, 3), 
(56, 28, 3), 
(56, 30, 3), 
(56, 208, 3), 
(56, 34, 3), 
(56, 215, 3), 
(57, 177, 4), 
(56, 207, 3), 
(56, 22, 3), 
(56, 24, 3), 
(56, 206, 3), 
(56, 20, 3), 
(56, 18, 3), 
(57, 188, 4), 
(56, 23, 3), 
(56, 26, 3), 
(56, 173, 3), 
(56, 25, 3), 
(54, 173, 2), 
(57, 187, 4), 
(56, 46, 3), 
(57, 178, 4), 
(57, 191, 4), 
(57, 179, 4), 
(57, 192, 4), 
(57, 200, 4), 
(56, 29, 3), 
(56, 19, 3), 
(57, 193, 4), 
(56, 218, 3), 
(56, 39, 3), 
(56, 17, 3), 
(56, 48, 3), 
(57, 185, 4), 
(57, 176, 4), 
(57, 47, 4), 
(57, 46, 4), 
(57, 33, 4), 
(57, 32, 4), 
(57, 30, 4), 
(57, 29, 4), 
(57, 31, 4), 
(57, 28, 4), 
(57, 34, 4), 
(57, 209, 4), 
(57, 218, 4), 
(57, 217, 4), 
(57, 208, 4), 
(57, 207, 4), 
(57, 215, 4), 
(57, 206, 4), 
(57, 24, 4), 
(57, 48, 4), 
(57, 20, 4), 
(57, 21, 4), 
(57, 26, 4), 
(57, 23, 4), 
(57, 18, 4), 
(57, 25, 4), 
(57, 17, 4), 
(57, 22, 4), 
(57, 19, 4), 
(57, 35, 4);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_contact_rows`
--

DROP TABLE IF EXISTS `nv3_vi_contact_rows`;
CREATE TABLE `nv3_vi_contact_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `note` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_contact_rows`
--

INSERT INTO `nv3_vi_contact_rows` VALUES
(1, 'Webmaster', '', '', '', '', '1/1/1/0;', 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_contact_send`
--

DROP TABLE IF EXISTS `nv3_vi_contact_send`;
CREATE TABLE `nv3_vi_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `send_time` int(11) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100) NOT NULL,
  `sender_email` varchar(100) NOT NULL,
  `sender_phone` varchar(255) NOT NULL,
  `sender_ip` varchar(15) NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `reply_content` mediumtext NOT NULL,
  `reply_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_counter`
--

DROP TABLE IF EXISTS `nv3_vi_counter`;
CREATE TABLE `nv3_vi_counter` (
  `c_type` varchar(100) NOT NULL,
  `c_val` varchar(100) NOT NULL,
  `c_count` int(11) unsigned NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_counter`
--

INSERT INTO `nv3_vi_counter` VALUES
('c_time', 'start', 0, 0), 
('c_time', 'last', 1352698097, 0), 
('total', 'hits', 20, 1352698097), 
('year', '2009', 0, 0), 
('year', '2010', 0, 0), 
('year', '2011', 0, 0), 
('year', '2012', 20, 1352698097), 
('year', '2013', 0, 0), 
('year', '2014', 0, 0), 
('year', '2015', 0, 0), 
('year', '2016', 0, 0), 
('year', '2017', 0, 0), 
('year', '2018', 0, 0), 
('year', '2019', 0, 0), 
('year', '2020', 0, 0), 
('month', 'Jan', 0, 0), 
('month', 'Feb', 0, 0), 
('month', 'Mar', 0, 0), 
('month', 'Apr', 0, 0), 
('month', 'May', 0, 0), 
('month', 'Jun', 0, 0), 
('month', 'Jul', 0, 0), 
('month', 'Aug', 0, 0), 
('month', 'Sep', 0, 0), 
('month', 'Oct', 10, 1351566649), 
('month', 'Nov', 10, 1352698097), 
('month', 'Dec', 0, 0), 
('day', '01', 0, 0), 
('day', '02', 3, 1351842305), 
('day', '03', 0, 0), 
('day', '04', 0, 0), 
('day', '05', 0, 0), 
('day', '06', 1, 1352187717), 
('day', '07', 1, 1352259184), 
('day', '08', 1, 1352353121), 
('day', '09', 1, 1352453618), 
('day', '10', 1, 1352542311), 
('day', '11', 1, 1352606564), 
('day', '12', 1, 1352698097), 
('day', '13', 0, 0), 
('day', '14', 0, 0), 
('day', '15', 0, 0), 
('day', '16', 0, 0), 
('day', '17', 0, 0), 
('day', '18', 0, 0), 
('day', '19', 0, 0), 
('day', '20', 0, 0), 
('day', '21', 0, 0), 
('day', '22', 0, 0), 
('day', '23', 0, 0), 
('day', '24', 0, 0), 
('day', '25', 0, 0), 
('day', '26', 0, 1351257664), 
('day', '27', 0, 1351328441), 
('day', '28', 0, 1351435247), 
('day', '29', 0, 1351517384), 
('day', '30', 0, 1351566649), 
('day', '31', 0, 0), 
('dayofweek', 'Sunday', 3, 1352606564), 
('dayofweek', 'Monday', 3, 1352698097), 
('dayofweek', 'Tuesday', 3, 1352187717), 
('dayofweek', 'Wednesday', 1, 1352259184), 
('dayofweek', 'Thursday', 1, 1352353121), 
('dayofweek', 'Friday', 6, 1352453618), 
('dayofweek', 'Saturday', 3, 1352542311), 
('hour', '00', 0, 0), 
('hour', '01', 0, 0), 
('hour', '02', 0, 0), 
('hour', '03', 0, 0), 
('hour', '04', 0, 0), 
('hour', '05', 0, 0), 
('hour', '06', 0, 0), 
('hour', '07', 0, 0), 
('hour', '08', 0, 0), 
('hour', '09', 0, 1351562561), 
('hour', '10', 0, 1352259184), 
('hour', '11', 0, 1352606564), 
('hour', '12', 1, 1352698097), 
('hour', '13', 0, 1351839131), 
('hour', '14', 0, 1352187717), 
('hour', '15', 0, 0), 
('hour', '16', 0, 1352453618), 
('hour', '17', 0, 1352542311), 
('hour', '18', 0, 1351249732), 
('hour', '19', 0, 0), 
('hour', '20', 0, 1351517384), 
('hour', '21', 0, 1351435247), 
('hour', '22', 0, 0), 
('hour', '23', 0, 0), 
('bot', 'Alexa', 0, 0), 
('bot', 'AltaVista Scooter', 0, 0), 
('bot', 'Altavista Mercator', 0, 0), 
('bot', 'Altavista Search', 0, 0), 
('bot', 'Aport.ru Bot', 0, 0), 
('bot', 'Ask Jeeves', 0, 0), 
('bot', 'Baidu', 0, 0), 
('bot', 'Exabot', 0, 0), 
('bot', 'FAST Enterprise', 0, 0), 
('bot', 'FAST WebCrawler', 0, 0), 
('bot', 'Francis', 0, 0), 
('bot', 'Gigablast', 0, 0), 
('bot', 'Google AdsBot', 0, 0), 
('bot', 'Google Adsense', 0, 0), 
('bot', 'Google Bot', 0, 0), 
('bot', 'Google Desktop', 0, 0), 
('bot', 'Google Feedfetcher', 0, 0), 
('bot', 'Heise IT-Markt', 0, 0), 
('bot', 'Heritrix', 0, 0), 
('bot', 'IBM Research', 0, 0), 
('bot', 'ICCrawler - ICjobs', 0, 0), 
('bot', 'Ichiro', 0, 0), 
('bot', 'InfoSeek Spider', 0, 0), 
('bot', 'Lycos.com Bot', 0, 0), 
('bot', 'MSN Bot', 0, 0), 
('bot', 'MSN Bot Media', 0, 0), 
('bot', 'MSN Bot News', 0, 0), 
('bot', 'MSN NewsBlogs', 0, 0), 
('bot', 'Majestic-12', 0, 0), 
('bot', 'Metager', 0, 0), 
('bot', 'NG-Search', 0, 0), 
('bot', 'Nutch Bot', 0, 0), 
('bot', 'NutchCVS', 0, 0), 
('bot', 'OmniExplorer', 0, 0), 
('bot', 'Online Link Validator', 0, 0), 
('bot', 'Open-source Web Search', 0, 0), 
('bot', 'Psbot', 0, 0), 
('bot', 'Rambler', 0, 0), 
('bot', 'SEO Crawler', 0, 0), 
('bot', 'SEOSearch', 0, 0), 
('bot', 'Seekport', 0, 0), 
('bot', 'Sensis', 0, 0), 
('bot', 'Seoma', 0, 0), 
('bot', 'Snappy', 0, 0), 
('bot', 'Steeler', 0, 0), 
('bot', 'Synoo', 0, 0), 
('bot', 'Telekom', 0, 0), 
('bot', 'TurnitinBot', 0, 0), 
('bot', 'Vietnamese Search', 0, 0), 
('bot', 'Voyager', 0, 0), 
('bot', 'W3 Sitesearch', 0, 0), 
('bot', 'W3C Linkcheck', 0, 0), 
('bot', 'W3C Validator', 0, 0), 
('bot', 'WiseNut', 0, 0), 
('bot', 'YaCy', 0, 0), 
('bot', 'Yahoo Bot', 0, 0), 
('bot', 'Yahoo MMCrawler', 0, 0), 
('bot', 'Yahoo Slurp', 0, 0), 
('bot', 'YahooSeeker', 0, 0), 
('bot', 'Yandex', 0, 0), 
('bot', 'Yandex Blog', 0, 0), 
('bot', 'Yandex Direct Bot', 0, 0), 
('bot', 'Yandex Something', 0, 0), 
('browser', 'netcaptor', 0, 0), 
('browser', 'opera', 0, 0), 
('browser', 'aol', 0, 0), 
('browser', 'aol2', 0, 0), 
('browser', 'mosaic', 0, 0), 
('browser', 'k-meleon', 0, 0), 
('browser', 'konqueror', 0, 0), 
('browser', 'avantbrowser', 0, 0), 
('browser', 'avantgo', 0, 0), 
('browser', 'proxomitron', 0, 0), 
('browser', 'chrome', 1, 1351517384), 
('browser', 'safari', 0, 0), 
('browser', 'lynx', 0, 0), 
('browser', 'links', 0, 0), 
('browser', 'galeon', 0, 0), 
('browser', 'abrowse', 0, 0), 
('browser', 'amaya', 0, 0), 
('browser', 'ant', 0, 0), 
('browser', 'aweb', 0, 0), 
('browser', 'beonex', 0, 0), 
('browser', 'blazer', 0, 0), 
('browser', 'camino', 0, 0), 
('browser', 'chimera', 0, 0), 
('browser', 'columbus', 0, 0), 
('browser', 'crazybrowser', 0, 0), 
('browser', 'curl', 0, 0), 
('browser', 'deepnet', 0, 0), 
('browser', 'dillo', 0, 0), 
('browser', 'doris', 0, 0), 
('browser', 'elinks', 0, 0), 
('browser', 'epiphany', 0, 0), 
('browser', 'ibrowse', 0, 0), 
('browser', 'icab', 0, 0), 
('browser', 'ice', 0, 0), 
('browser', 'isilox', 0, 0), 
('browser', 'lotus', 0, 0), 
('browser', 'lunascape', 0, 0), 
('browser', 'maxthon', 0, 0), 
('browser', 'mbrowser', 0, 0), 
('browser', 'multibrowser', 0, 0), 
('browser', 'nautilus', 0, 0), 
('browser', 'netfront', 0, 0), 
('browser', 'netpositive', 0, 0), 
('browser', 'omniweb', 0, 0), 
('browser', 'oregano', 0, 0), 
('browser', 'phaseout', 0, 0), 
('browser', 'plink', 0, 0), 
('browser', 'phoenix', 0, 0), 
('browser', 'shiira', 0, 0), 
('browser', 'sleipnir', 0, 0), 
('browser', 'slimbrowser', 0, 0), 
('browser', 'staroffice', 0, 0), 
('browser', 'sunrise', 0, 0), 
('browser', 'voyager', 0, 0), 
('browser', 'w3m', 0, 0), 
('browser', 'webtv', 0, 0), 
('browser', 'xiino', 0, 0), 
('browser', 'explorer', 0, 0), 
('browser', 'firefox', 19, 1352698097), 
('browser', 'netscape', 0, 0), 
('browser', 'netscape2', 0, 0), 
('browser', 'mozilla', 0, 0), 
('browser', 'mozilla2', 0, 0), 
('browser', 'firebird', 0, 0), 
('browser', 'Mobile', 0, 0), 
('browser', 'Unknown', 0, 0), 
('os', 'windows7', 20, 1352698097), 
('os', 'windowsvista', 0, 0), 
('os', 'windows2003', 0, 0), 
('os', 'windowsxp', 0, 0), 
('os', 'windowsxp2', 0, 0), 
('os', 'windows2k', 0, 0), 
('os', 'windows95', 0, 0), 
('os', 'windowsce', 0, 0), 
('os', 'windowsme', 0, 0), 
('os', 'windowsme2', 0, 0), 
('os', 'windowsnt', 0, 0), 
('os', 'windowsnt2', 0, 0), 
('os', 'windows98', 0, 0), 
('os', 'windows', 0, 0), 
('os', 'linux', 0, 0), 
('os', 'linux2', 0, 0), 
('os', 'linux3', 0, 0), 
('os', 'macosx', 0, 0), 
('os', 'macppc', 0, 0), 
('os', 'mac', 0, 0), 
('os', 'amiga', 0, 0), 
('os', 'beos', 0, 0), 
('os', 'freebsd', 0, 0), 
('os', 'freebsd2', 0, 0), 
('os', 'irix', 0, 0), 
('os', 'netbsd', 0, 0), 
('os', 'netbsd2', 0, 0), 
('os', 'os2', 0, 0), 
('os', 'os22', 0, 0), 
('os', 'openbsd', 0, 0), 
('os', 'openbsd2', 0, 0), 
('os', 'palm', 0, 0), 
('os', 'palm2', 0, 0), 
('os', 'Unspecified', 0, 0), 
('country', 'AD', 0, 0), 
('country', 'AE', 0, 0), 
('country', 'AF', 0, 0), 
('country', 'AG', 0, 0), 
('country', 'AI', 0, 0), 
('country', 'AL', 0, 0), 
('country', 'AM', 0, 0), 
('country', 'AN', 0, 0), 
('country', 'AO', 0, 0), 
('country', 'AQ', 0, 0), 
('country', 'AR', 0, 0), 
('country', 'AS', 0, 0), 
('country', 'AT', 0, 0), 
('country', 'AU', 0, 0), 
('country', 'AW', 0, 0), 
('country', 'AZ', 0, 0), 
('country', 'BA', 0, 0), 
('country', 'BB', 0, 0), 
('country', 'BD', 0, 0), 
('country', 'BE', 0, 0), 
('country', 'BF', 0, 0), 
('country', 'BG', 0, 0), 
('country', 'BH', 0, 0), 
('country', 'BI', 0, 0), 
('country', 'BJ', 0, 0), 
('country', 'BM', 0, 0), 
('country', 'BN', 0, 0), 
('country', 'BO', 0, 0), 
('country', 'BR', 0, 0), 
('country', 'BS', 0, 0), 
('country', 'BT', 0, 0), 
('country', 'BW', 0, 0), 
('country', 'BY', 0, 0), 
('country', 'BZ', 0, 0), 
('country', 'CA', 0, 0), 
('country', 'CD', 0, 0), 
('country', 'CF', 0, 0), 
('country', 'CG', 0, 0), 
('country', 'CH', 0, 0), 
('country', 'CI', 0, 0), 
('country', 'CK', 0, 0), 
('country', 'CL', 0, 0), 
('country', 'CM', 0, 0), 
('country', 'CN', 0, 0), 
('country', 'CO', 0, 0), 
('country', 'CR', 0, 0), 
('country', 'CS', 0, 0), 
('country', 'CU', 0, 0), 
('country', 'CV', 0, 0), 
('country', 'CY', 0, 0), 
('country', 'CZ', 0, 0), 
('country', 'DE', 0, 0), 
('country', 'DJ', 0, 0), 
('country', 'DK', 0, 0), 
('country', 'DM', 0, 0), 
('country', 'DO', 0, 0), 
('country', 'DZ', 0, 0), 
('country', 'EC', 0, 0), 
('country', 'EE', 0, 0), 
('country', 'EG', 0, 0), 
('country', 'ER', 0, 0), 
('country', 'ES', 0, 0), 
('country', 'ET', 0, 0), 
('country', 'EU', 0, 0), 
('country', 'FI', 0, 0), 
('country', 'FJ', 0, 0), 
('country', 'FK', 0, 0), 
('country', 'FM', 0, 0), 
('country', 'FO', 0, 0), 
('country', 'FR', 0, 0), 
('country', 'GA', 0, 0), 
('country', 'GB', 0, 0), 
('country', 'GD', 0, 0), 
('country', 'GE', 0, 0), 
('country', 'GF', 0, 0), 
('country', 'GH', 0, 0), 
('country', 'GI', 0, 0), 
('country', 'GL', 0, 0), 
('country', 'GM', 0, 0), 
('country', 'GN', 0, 0), 
('country', 'GP', 0, 0), 
('country', 'GQ', 0, 0), 
('country', 'GR', 0, 0), 
('country', 'GS', 0, 0), 
('country', 'GT', 0, 0), 
('country', 'GU', 0, 0), 
('country', 'GW', 0, 0), 
('country', 'GY', 0, 0), 
('country', 'HK', 0, 0), 
('country', 'HN', 0, 0), 
('country', 'HR', 0, 0), 
('country', 'HT', 0, 0), 
('country', 'HU', 0, 0), 
('country', 'ID', 0, 0), 
('country', 'IE', 0, 0), 
('country', 'IL', 0, 0), 
('country', 'IN', 0, 0), 
('country', 'IO', 0, 0), 
('country', 'IQ', 0, 0), 
('country', 'IR', 0, 0), 
('country', 'IS', 0, 0), 
('country', 'IT', 0, 0), 
('country', 'JM', 0, 0), 
('country', 'JO', 0, 0), 
('country', 'JP', 0, 0), 
('country', 'KE', 0, 0), 
('country', 'KG', 0, 0), 
('country', 'KH', 0, 0), 
('country', 'KI', 0, 0), 
('country', 'KM', 0, 0), 
('country', 'KN', 0, 0), 
('country', 'KR', 0, 0), 
('country', 'KW', 0, 0), 
('country', 'KY', 0, 0), 
('country', 'KZ', 0, 0), 
('country', 'LA', 0, 0), 
('country', 'LB', 0, 0), 
('country', 'LC', 0, 0), 
('country', 'LI', 0, 0), 
('country', 'LK', 0, 0), 
('country', 'LR', 0, 0), 
('country', 'LS', 0, 0), 
('country', 'LT', 0, 0), 
('country', 'LU', 0, 0), 
('country', 'LV', 0, 0), 
('country', 'LY', 0, 0), 
('country', 'MA', 0, 0), 
('country', 'MC', 0, 0), 
('country', 'MD', 0, 0), 
('country', 'MG', 0, 0), 
('country', 'MH', 0, 0), 
('country', 'MK', 0, 0), 
('country', 'ML', 0, 0), 
('country', 'MM', 0, 0), 
('country', 'MN', 0, 0), 
('country', 'MO', 0, 0), 
('country', 'MP', 0, 0), 
('country', 'MQ', 0, 0), 
('country', 'MR', 0, 0), 
('country', 'MT', 0, 0), 
('country', 'MU', 0, 0), 
('country', 'MV', 0, 0), 
('country', 'MW', 0, 0), 
('country', 'MX', 0, 0), 
('country', 'MY', 0, 0), 
('country', 'MZ', 0, 0), 
('country', 'NA', 0, 0), 
('country', 'NC', 0, 0), 
('country', 'NE', 0, 0), 
('country', 'NF', 0, 0), 
('country', 'NG', 0, 0), 
('country', 'NI', 0, 0), 
('country', 'NL', 0, 0), 
('country', 'NO', 0, 0), 
('country', 'NP', 0, 0), 
('country', 'NR', 0, 0), 
('country', 'NU', 0, 0), 
('country', 'NZ', 0, 0), 
('country', 'OM', 0, 0), 
('country', 'PA', 0, 0), 
('country', 'PE', 0, 0), 
('country', 'PF', 0, 0), 
('country', 'PG', 0, 0), 
('country', 'PH', 0, 0), 
('country', 'PK', 0, 0), 
('country', 'PL', 0, 0), 
('country', 'PR', 0, 0), 
('country', 'PS', 0, 0), 
('country', 'PT', 0, 0), 
('country', 'PW', 0, 0), 
('country', 'PY', 0, 0), 
('country', 'QA', 0, 0), 
('country', 'RE', 0, 0), 
('country', 'RO', 0, 0), 
('country', 'RU', 0, 0), 
('country', 'RW', 0, 0), 
('country', 'SA', 0, 0), 
('country', 'SB', 0, 0), 
('country', 'SC', 0, 0), 
('country', 'SD', 0, 0), 
('country', 'SE', 0, 0), 
('country', 'SG', 0, 0), 
('country', 'SI', 0, 0), 
('country', 'SK', 0, 0), 
('country', 'SL', 0, 0), 
('country', 'SM', 0, 0), 
('country', 'SN', 0, 0), 
('country', 'SO', 0, 0), 
('country', 'SR', 0, 0), 
('country', 'ST', 0, 0), 
('country', 'SV', 0, 0), 
('country', 'SY', 0, 0), 
('country', 'SZ', 0, 0), 
('country', 'TD', 0, 0), 
('country', 'TF', 0, 0), 
('country', 'TG', 0, 0), 
('country', 'TH', 0, 0), 
('country', 'TJ', 0, 0), 
('country', 'TK', 0, 0), 
('country', 'TL', 0, 0), 
('country', 'TM', 0, 0), 
('country', 'TN', 0, 0), 
('country', 'TO', 0, 0), 
('country', 'TR', 0, 0), 
('country', 'TT', 0, 0), 
('country', 'TV', 0, 0), 
('country', 'TW', 0, 0), 
('country', 'TZ', 0, 0), 
('country', 'UA', 0, 0), 
('country', 'UG', 0, 0), 
('country', 'US', 0, 0), 
('country', 'UY', 0, 0), 
('country', 'UZ', 0, 0), 
('country', 'VA', 0, 0), 
('country', 'VC', 0, 0), 
('country', 'VE', 0, 0), 
('country', 'VG', 0, 0), 
('country', 'VI', 0, 0), 
('country', 'VN', 0, 0), 
('country', 'VU', 0, 0), 
('country', 'WS', 0, 0), 
('country', 'YE', 0, 0), 
('country', 'YT', 0, 0), 
('country', 'YU', 0, 0), 
('country', 'ZA', 0, 0), 
('country', 'ZM', 0, 0), 
('country', 'ZW', 0, 0), 
('country', 'ZZ', 20, 1352698097), 
('country', 'unkown', 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_1`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_1`;
CREATE TABLE `nv3_vi_kien_truc_360_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_kien_truc_360_1`
--

INSERT INTO `nv3_vi_kien_truc_360_1` VALUES
(1, 1, '1', 0, 1, '', 0, 1352700391, 1352700391, 1, 1352700391, 0, 2, 'Không gian nhà bếp nổi bật 2012', 'Khong-gian-nha-bep-noi-bat-2012', 'Một không gian bếp đẹp “có cá tính” chính là một “nét duyên” trong ngôi nhà và có thể đem lại cho các thành viên trong gia đình cảm xúc ấm áp mỗi khi bước vào.', '2012_11/bep-xanh-tot-cho-suc-khoe-1.jpg', '', 'thumb/bep-xanh-tot-cho-suc-khoe-1.jpg|block/bep-xanh-tot-cho-suc-khoe-1.jpg', 1, 2, 1, 2, 0, 0, 0, 'không gian,cá tính,có thể,thành viên,gia đình,cảm xúc,ấm áp');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_2`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_2`;
CREATE TABLE `nv3_vi_kien_truc_360_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_kien_truc_360_2`
--

INSERT INTO `nv3_vi_kien_truc_360_2` VALUES
(2, 2, '2', 0, 1, '', 0, 1352706043, 1352706043, 1, 1352706043, 0, 2, 'Chọn cửa hàng kinh doanh theo Phong thủy', 'Chon-cua-hang-kinh-doanh-theo-Phong-thuy', 'Núi mà dương trạch tựa vào phải là núi có thế như con rồng phú quý. Sông mà nó hướng vào phải có hình uốn cong bao xung quanh. Khi chọn cửa hàng thì phải chọn thế “tựa núi hướng sông”. Đây là cách chọn lựa vị trí lý tưởng nhất trong dương trạch.', '2012_11/kinh-doanh-va-thuat-phong-thuy.jpg', '', 'thumb/kinh-doanh-va-thuat-phong-thuy.jpg|block/kinh-doanh-va-thuat-phong-thuy.jpg', 1, 2, 1, 0, 0, 0, 0, 'phú quý,cửa hàng,thì phải,vị trí,lý tưởng');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_3`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_3`;
CREATE TABLE `nv3_vi_kien_truc_360_3` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_kien_truc_360_3`
--

INSERT INTO `nv3_vi_kien_truc_360_3` VALUES
(3, 3, '3', 0, 1, '', 0, 1352706123, 1352706123, 1, 1352706123, 0, 2, 'Ngôi nhà nứt làm ba', 'Ngoi-nha-nut-lam-ba', 'Một ngôi nhà ở Mỹ đã khiến cho không ít người phải ngạc nhiên bởi kiến trúc quái dị của nó. Nhìn từ xa ngôi nhà bị gãy khúc giống như mới trải qua một trận động đất kinh hoàng.', '2012_11/ngoi-nha-dut-gay-doc-dao1.jpg', '', 'thumb/ngoi-nha-dut-gay-doc-dao1.jpg|block/ngoi-nha-dut-gay-doc-dao1.jpg', 1, 2, 1, 0, 0, 0, 0, 'nhà ở,ngạc nhiên,kiến trúc,quái dị,trải qua,động đất');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_4`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_4`;
CREATE TABLE `nv3_vi_kien_truc_360_4` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_kien_truc_360_4`
--

INSERT INTO `nv3_vi_kien_truc_360_4` VALUES
(4, 4, '4', 0, 1, '', 0, 1352706194, 1352706194, 1, 1352706194, 0, 2, 'Kiến trúc sư Ludwig Mies van der Rohe', 'Kien-truc-su-Ludwig-Mies-van-der-Rohe', 'Ludwig Mies van der Rohe (Sinh ngày 27 tháng 3 năm 1886 – mất ngày 19 tháng 8 năm 1969) là một kiến trúc sư nổi tiếng thế giới người Đức. Ông là một trong những người đặt nền móng cho sự phát triển của trào lưu Kiến trúc hiện đại của thế kỉ 20 và được xem như cha đẻ của phong cách Kiến trúc tối thiểu (Minimalism).', '2012_11/image001-749833.jpg', '', 'thumb/image001-749833.jpg|block/image001-749833.jpg', 1, 2, 1, 0, 0, 0, 0, 'kiến trúc sư,nổi tiếng,thế giới,nền móng,phát triển,trào lưu,kiến trúc,hiện đại,phong cách,tối thiểu');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_5`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_5`;
CREATE TABLE `nv3_vi_kien_truc_360_5` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_kien_truc_360_5`
--

INSERT INTO `nv3_vi_kien_truc_360_5` VALUES
(5, 5, '5', 0, 1, '', 0, 1352706268, 1352706268, 1, 1352706268, 0, 2, 'Điểm danh 7 khách sạn, khu nghỉ dưỡng đẹp nhất của các sao', 'Diem-danh-7-khach-san-khu-nghi-duong-dep-nhat-cua-cac-sao', 'Ờ bài viết này chúng tôi xin đưa các bạn đọc đến thăm các khách sạn sang trọng bậc nhất thế giới. Và không ai hết chủ sở hữu của các khách sạn này là các ngôi sao hàng đầu thế giới', '2012_11/691343.jpeg', '', 'thumb/691343.jpeg.jpg|block/691343.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'bạn đọc,khách sạn,sang trọng,thế giới,sở hữu,hàng đầu');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_admins`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_admins`;
CREATE TABLE `nv3_vi_kien_truc_360_admins` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `comment` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_block`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_block`;
CREATE TABLE `nv3_vi_kien_truc_360_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_block_cat`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_block_cat`;
CREATE TABLE `nv3_vi_kien_truc_360_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `number` mediumint(4) NOT NULL DEFAULT '10',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_bodyhtml_1`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_bodyhtml_1`;
CREATE TABLE `nv3_vi_kien_truc_360_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_kien_truc_360_bodyhtml_1`
--

INSERT INTO `nv3_vi_kien_truc_360_bodyhtml_1` VALUES
(1, '<h1 class=\"entry-title\" style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 20px; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> Không gian nhà bếp nổi bật 2012</h1><span style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); display: inline !important; float: none;\">﻿</span><span class=\"categories\" style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51) !important; font-size: 12px; font-weight: bold !important; font-family: Arial; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\">Chuyên mục:<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/kien-truc-360/khong-gian-song/\" rel=\"category tag\" style=\"color: rgb(148, 64, 64) !important; text-decoration: initial;\" title=\"View all posts in Không gian sống\">Không gian sống</a></span><div class=\"post-info\" style=\"color: rgb(51, 51, 51); font-size: 12px; margin: 0px 0px 5px; padding: 0px; font-family: Arial; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <b style=\"font-weight: bold;\">Ngày :<span class=\"Apple-converted-space\">&nbsp;</span></b><span class=\"date time published\" style=\"margin: 0px; padding: 0px;\" title=\"2012-11-03T08:44:41+0000\">03/11/2012</span></div><div class=\"entry-content\" style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> <strong>Một<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://kientructhiennam.com/khong-gian-bep-dep-2012-3877\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\">không gian bếp đẹp</a><span class=\"Apple-converted-space\">&nbsp;</span>“có cá tính” chính là một “nét duyên” trong ngôi nhà và có thể đem lại cho các thành viên trong gia đình cảm xúc ấm áp mỗi khi bước vào.</strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Có thể nhiều người không quan trọng việc trang hoàng bếp núc vì cho rằng không nhất thiết phải cầu kỳ vì khi chỉ dùng nó cho công việc nấu ăn, song không quá khó khăn và tốn kém để đổi mới gian bếp nhà mình.</p> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> Không gian bếp thân thiện với môi trường</h2> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Từ những gì gia đình bạn ăn trong nhà bếp, cho tới chi phí chạy các thiết bị nhà bếp của bạn, đều có thể được cải thiện để tiết kiệm chi phí cho bạn và giúp cải thiện nguồn tài nguyên có giá trị của Trái đất. Nếu bạn đang cố gắng để làm xanh hơn nhà bếp của bạn, thì những cách hữu ích sau đây sẽ giúp bạn và gia đình thay đổi thói quen vào bếp hàng ngày.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> <img alt=\"\" class=\"aligncenter size-full wp-image-3881\" height=\"468\" src=\"http://adkientruc.com/wp-content/uploads/2012/11/bep-xanh-tot-cho-suc-khoe-1-.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"631\" /></p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> <img alt=\"\" class=\"aligncenter\" height=\"442\" src=\"http://adkientruc.com/wp-content/uploads/2012/11/bep-xanh-tot-cho-suc-khoe-3-.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"636\" /></p> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> Không gian bếp hiện đại</h2> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Không gian bếp hiện đại được thiết kế theo phong cách riêng, thoáng nhìn qua đã hiểu được phần nào tính cách của người chủ.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> <img alt=\"\" class=\"aligncenter\" src=\"http://adkientruc.com/wp-content/uploads/2012/11/04_111104DOOLThangMB09.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" /></p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Căn bếp hiện đại được kết hợp các yếu tố tự nhiên và công nghiệp. Căn bếp với các thiết bị hiện đại như tủ lạnh, lò vi sóng và quầy bar phía trước. Ánh sáng từ cửa sổ mang lại luồng sinh khí mới và lưu thông trong căn bếp.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <img alt=\"Những mẫu phòng bếp đẹp năm 2012 - Archi\" class=\"aligncenter\" height=\"500\" src=\"http://adkientruc.com/wp-content/uploads/2012/11/nhung-mau-phong-bep-dep-2012-4.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"500\" /></p> <h2 align=\"\\&#039;&#039;justify&#039;\\&#039;\" style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> Đưa những tiện nghi giải trí vào trong nhà bếp</h2> <p align=\"center\" style=\"margin: 0px; padding: 0px 0px 10px;\"> <img alt=\"Xu hướng thiết kế nhà bếp 2012 ( Phần cuối)\" src=\"http://adkientruc.com/wp-content/uploads/2012/11/20120423afamilyNDxuhuongnhabep-7_8b0ca.jpg\" style=\"max-width: 100%;\" /></p> <p align=\"justify\" style=\"margin: 0px; padding: 0px 0px 10px;\"> Khi mọi người ngày càng trở nên hiểu biết về công nghệ thì tiện nghi nhà bếp và phòng tắm cũng được quan tâm và chú trọng nhiều hơn. Các trang trí truyền thống dần nhường chỗ cho các thiết bị điện tử. Các mặt hàng điện tử phổ biến như tivi gắn tường, máy tính quan sát, hệ thống âm thanh giải trí… đều được yêu thích. Đây thực chất là một xu hướng song hành với xu hướng “không dây” đang ngày càng thịnh hành.</p> <h2 align=\"\\&#039;&#039;justify&#039;\\&#039;\" style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> Sản phẩm sinh thái thân thiện</h2> <p align=\"center\" style=\"margin: 0px; padding: 0px 0px 10px;\"> <img alt=\"Xu hướng thiết kế nhà bếp 2012 ( Phần cuối)\" src=\"http://adkientruc.com/wp-content/uploads/2012/11/20120423afamilyNDxuhuongnhabep-8_8a65a.jpg\" style=\"max-width: 100%;\" /></p> <p align=\"justify\" style=\"margin: 0px; padding: 0px 0px 10px;\"> Sản phẩm được làm từ vật liệu bền vững đang ngày càng được ưa chuộng. Tủ bếp sinh thái thân thiện từ tre hay gỗ vừa mang lại cảm giác ấm cúng, gần gũi lại cải thiện được chất lượng không khí trong nhà.</p> <p align=\"justify\" style=\"margin: 0px; padding: 0px 0px 10px;\"> Vòi nước và các giải pháp tiết kiệm năng lượng cũng được các chủ nhà ưu tiên nhằm giảm bớt con số trên hóa đơn và giảm việc sử dụng các nguồn tài nguyên thiên nhiên.</p></div>', '', 1, 0, 1, 1, 1), 
(2, '<h1 class=\"entry-title\" style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 20px; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> Chọn cửa hàng kinh doanh theo Phong thủy</h1><span style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); display: inline !important; float: none;\">﻿</span><span class=\"categories\" style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51) !important; font-size: 12px; font-weight: bold !important; font-family: Arial; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\">Chuyên mục:<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/kien-truc-360/phong-thuy/\" rel=\"category tag\" style=\"color: rgb(148, 64, 64) !important; text-decoration: initial;\" title=\"View all posts in Phong thủy\">Phong thủy</a></span><div class=\"post-info\" style=\"color: rgb(51, 51, 51); font-size: 12px; margin: 0px 0px 5px; padding: 0px; font-family: Arial; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <b style=\"font-weight: bold;\">Ngày :<span class=\"Apple-converted-space\">&nbsp;</span></b><span class=\"date time published\" style=\"margin: 0px; padding: 0px;\" title=\"2012-06-17T02:48:20+0000\">17/06/2012</span></div><div class=\"entry-content\" style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Nên chọn vị trí dương trạch theo<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/kien-truc-360/phong-thuy/\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\" title=\"phong thủy\">phong thủy</a><span class=\"Apple-converted-space\">&nbsp;</span>như sau:</p> <div> <img alt=\"Chọn cửa hàng kinh doanh theo phong thủy - Archi\" class=\"aligncenter\" height=\"271\" src=\"http://adkientruc.com/wp-content/uploads/2012/06/kinh-doanh-va-thuat-phong-thuy.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"550\" /></div> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Nên tựa núi hướng sông</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Núi mà dương trạch tựa vào phải là núi có thế như con rồng phú quý. Sông mà nó hướng vào phải có hình uốn cong bao xung quanh. Khi chọn cửa hàng thì phải chọn thế “tựa núi hướng sông”. Đây là cách chọn lựa vị trí lý tưởng nhất trong dương trạch.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Theo<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/tag/phong-thuy/\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" title=\"phong thủy\">phong thủy</a><span class=\"Apple-converted-space\">&nbsp;</span>có thế tựa vào núi khiến người ta có cảm giác an tâm, yên ổn. Sau nhà mà có núi sẽ là một bức bình phong chắn gió vô cùng vững chắc. Nếu nơi đặt cửa hàng hướng ra sông, mặt nước trong sạch mát mẻ có thể mang lại không khí trong lành cho mọi người.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Thế đất cao hướng ra sông</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Theo phong thủy xưa nếu vị trí cửa hàng ở khu vực không có núi thì nên chọn vị trí đất cao hướng ra sông.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Đặt cửa hàng ở vị trí cao hướng ra sông sẽ tạo thành một hình thế trước thấp sau cao sẽ giúp cho nó được tựa lưng vào chỗ cao. Hơn thế không khí trong lành từ mặt sông thổi lại sẽ mang theo hơi nước mát lành.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Chọn mảnh đất có sinh khí</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Quan niệm phong thủy cho rằng có người là có sinh khí, người càng nhiều, sinh khí càng vượng, sinh khí tốt sẽ đem lại sự hưng thịnh trong buôn bán.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Lựa chọn mở cửa hàng ở những nơi đông dân cư ta có thể chủ động giới thiệu sản phẩm của cửa hàng với khách. Vị trí mà hấp dẫn được khách thì mới có tác dụng thúc đẩy kinh doanh, buôn bán phát tài và đảm bảo được doanh thu và lợi nhuận.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Ngược lại mở cửa hàng ở những nơi vắng vẻ thì đồng nghĩa tự đưa mình vào chỗ khó khăn. Khách hàng sẽ ít dẫn đến doanh thu ít và sẽ phải đóng cửa là điều không thể tránh.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Mặt khác theo phong thủy, người đại diện cho sinh khí, không có người đến cửa hàng thì ắt sẽ thiếu đi sinh khí. Sinh khí mà ít thì Âm khí sẽ mạnh lên.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Một cửa hàng mà Âm khí quá nhiều, không những buôn bán lỗ vốn, nghiêm trọng hơn nó sẽ làm tổn thương đến nguyên khí của chủ cửa hàng, khiến cho cửa hàng phá sản.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Nên chọn mảnh đất sạch sẽ</p> <div> Chọn vị trí để kinh doanh, đặt cửa hàng đòi hỏi mảnh đất được chọn phải sạch sẽ, khô ráo. Nếu mảnh đất chọn để xây nhà không tốt, ẩm thấp quá hoặc bốc lên mùi hôi thối sẽ làm ảnh hưởng đến sức khỏe cho người cư trú ở đó và đồng thời sẽ không hấp dẫn khách hàng đến cửa hàng. Điều này sẽ đặc biệt bất lợi trong kinh doanh.</div></div>', '', 1, 0, 1, 1, 1), 
(3, '<h1 class=\"entry-title\" style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 20px; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> Ngôi nhà nứt làm ba</h1><span style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); display: inline !important; float: none;\">﻿</span><span class=\"categories\" style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51) !important; font-size: 12px; font-weight: bold !important; font-family: Arial; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\">Chuyên mục:<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/kien-truc-360/kien-truc-la/\" rel=\"category tag\" style=\"color: rgb(148, 64, 64) !important; text-decoration: initial;\" title=\"View all posts in Kiến trúc lạ\">Kiến trúc lạ</a></span><div class=\"post-info\" style=\"color: rgb(51, 51, 51); font-size: 12px; margin: 0px 0px 5px; padding: 0px; font-family: Arial; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <b style=\"font-weight: bold;\">Ngày :<span class=\"Apple-converted-space\">&nbsp;</span></b><span class=\"date time published\" style=\"margin: 0px; padding: 0px;\" title=\"2012-03-14T14:39:43+0000\">14/03/2012</span></div><div class=\"entry-content\" style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> <strong>Một ngôi nhà ở Mỹ đã khiến cho không ít người phải ngạc nhiên bởi<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\" title=\"kiến trúc\">kiến trúc</a><span class=\"Apple-converted-space\">&nbsp;</span>quái dị của nó. Nhìn từ xa ngôi nhà bị gãy khúc giống như mới trải qua một trận động đất kinh hoàng.</strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Ngôi nhà kỳ quái có khẩu hiệu: “Ripley’s Believe It Or Not” (Tin hay không) ở Branson, tiểu bang Missouri, Mỹ có chiều cao hơn 12 mét và chiều rộng 365 mét. Ngôi nhà nổi bật lên với một kiến trúc quái dị nhất bạn từng thấy.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> <img alt=\"Ngôi nhà \" class=\"aligncenter\" height=\"374\" src=\"http://adkientruc.com/wp-content/uploads/2012/03/ngoi-nha-dut-gay-doc-dao1.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"500\" /></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <img alt=\"Ngôi nhà \" class=\"aligncenter\" height=\"374\" src=\"http://adkientruc.com/wp-content/uploads/2012/03/ngoi-nha-dut-gay-doc-dao2.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"500\" /><span style=\"color: rgb(0, 0, 255);\"><em style=\"text-align: center;\">Ngôi nhà đã đánh lừa thị giác của không ít người.</em></span></p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Người quản lý ngôi nhà, ông Gary Daily cho biết: “Ngôi nhà này được xây dựng vào năm 1999, kiến trúc của nó trông giống như một ngôi nhà bị tác động bởi trận động đất. Ý tưởng khi xây dựng ngôi nhà này là để tái hiện lại hình ảnh về trận động đất kinh hoàng trong lịch sử mạnh 8 độ richter năm 1812. Thật buồn cười khi nhìn thấy những người đi qua ngôi nhà, tất cả đều ngạc nhiên và không thốt nên lời.”</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Hiện tại, ngôi nhà độc đáo này đã được khoác bộ cánh mới màu vàng dịu.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> <img alt=\"Ngôi nhà \" class=\"aligncenter\" height=\"375\" src=\"http://adkientruc.com/wp-content/uploads/2012/03/ngoi-nha-dut-gay-doc-dao3.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"500\" /></p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> <img alt=\"Ngôi nhà \" class=\"aligncenter\" height=\"281\" src=\"http://adkientruc.com/wp-content/uploads/2012/03/ngoi-nha-dut-gay-doc-dao4.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"500\" /></p></div>', '', 1, 0, 1, 1, 1), 
(4, '<h1 class=\"entry-title\" style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 20px; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> Kiến trúc sư Ludwig Mies van der Rohe</h1><span style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); display: inline !important; float: none;\">﻿</span><span class=\"categories\" style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51) !important; font-size: 12px; font-weight: bold !important; font-family: Arial; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\">Chuyên mục:<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/kien-truc-360/kts-noi-tieng/\" rel=\"category tag\" style=\"color: rgb(148, 64, 64) !important; text-decoration: initial;\" title=\"View all posts in KTS Nổi tiếng\">KTS Nổi tiếng</a></span><div class=\"post-info\" style=\"color: rgb(51, 51, 51); font-size: 12px; margin: 0px 0px 5px; padding: 0px; font-family: Arial; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <b style=\"font-weight: bold;\">Ngày :<span class=\"Apple-converted-space\">&nbsp;</span></b><span class=\"date time published\" style=\"margin: 0px; padding: 0px;\" title=\"2011-01-13T17:06:29+0000\">13/01/2011</span></div><div class=\"entry-content\" style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> <strong>Ludwig Mies van der Rohe (Sinh ngày 27 tháng 3 năm 1886 – mất ngày 19 tháng 8 năm 1969) là một<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\" title=\"kiến trúc\">kiến trúc</a><span class=\"Apple-converted-space\">&nbsp;</span>sư nổi tiếng thế giới người Đức. Ông là một trong những người đặt nền móng cho sự phát triển của trào lưu Kiến trúc hiện đại của thế kỉ 20 và được xem như cha đẻ của phong cách Kiến trúc tối thiểu (Minimalism).</strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <a href=\"http://www.alliance-hn.com/vietnam/News/News/uploaded_images/image001-749835.jpg\" style=\"color: rgb(51, 51, 51); text-decoration: initial; outline: none;\" target=\"_blank\"><img alt=\"\" border=\"0\" class=\"aligncenter\" src=\"http://adkientruc.com/wp-content/uploads/2011/01/image001-749833.jpg\" style=\"border: none; display: block; margin: 0px auto 10px; max-width: 100%;\" /></a></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> <strong>Thời gian tại Đức</strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Ông sinh ra tại Aachen, Đức, với tên là Maria Ludwig Michael Mies, là con trai của một người thợ đá thủ công, điều này đã ảnh hưởng sâu sắc tới quan điểm thực hành trong kiến trúc của ông sau này. Sau đó ông chuyển tới Berlin làm việc ở văn phòng thiết kế của Brono Paul, và từ năm 1908 đến năm 1912 làm việc tại xưởng thiết kế của Peter Behrens, một trong những người tiên phong của kiến trúc Đức thời bấy giờ. Mies đã học được rất nhiều về lý thuyết thiết kế cũng như sự phát triển của văn hóa Đức thời bấy giờ. Cũng tại xưởng thiết kế của Behrens, Mies đã gặp gỡ và làm việc cùng với Le Corbusier và Wal-ter Gropius.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Với dáng vóc vạm vỡ, tính tình cẩn thận và là một con người trầm lặng, ít nói, người thanh niên tài năng Ludwig Mies tự đổi tên, lột xác từ con trai một người thợ tỉnh lẻ trở thành một kiến trúc sư làm việc với giới thượng lưu ở Berlin thời bấy giờ, bằng cách thêm ba chữ “van der Rohe” như một tên hiệu quý tộc. Ông bắt đầu sự nghiệp độc lâp của mình bằng cách thiết kế một số công trình nhà ở theo phong cách kiến trúc truyền thống của Đức. Mies ưa thích những tỉ lệ lớn, những hình khối không gian của kiến trúc sư Tân Cổ điển nước Phổ thế kỉ 19 là Karl Friedrich Schinkel, trong khi bỏ qua những xu hướng cổ điển chiết trung và hỗn độn của buổi giao thời.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <em><span style=\"color: rgb(0, 0, 128);\"><a href=\"http://www.alliance-hn.com/vietnam/News/News/uploaded_images/image003-718730.jpg\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\"><img alt=\"\" border=\"0\" src=\"http://adkientruc.com/wp-content/uploads/2011/01/image003-718727.jpg\" style=\"border: none; max-width: 100%;\" /></a></span></em></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <em><span style=\"color: rgb(0, 0, 128);\">Nhà ở tại Weissenhof</span></em></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Sau Thế chiến thứ nhất, Mies bắt đầu từ bỏ phong cách truyền thống và gia nhập hàng ngũ những người tiên phong trên con đường đi tìm một phong cách mới trong thời đại mới. Phong cách cổ điển từ lâu đã bị các nhà phê bình nghệ thuật chỉ trích từ giữa thế kỉ 19, chủ yếu do sự lạm dụng các chi tiết trang trí bề mặt, không tương xứng với sự phát triển của các kết cấu xây dựng bên trong công trình. Sự chỉ trích tấn công vào truyền thống cổ điển càng thắng thế, nhất là với sự sụp đổ của các đế chế vương quyền châu Âu, sau Thế chiến thứ nhất. Kiến trúc truyền thống giờ đây bị xem như tàn tích của quá khứ, của một chế độ chính trị không hợp thời. Mặt khác, dưới sự bùng nổ phát triển của nền sản xuất công nghiệp hóa châu Âu thời bấy giờ đòi hỏi một tư duy mới về kỹ thuật đã thúc đẩy quá trình tìm kiếm một phong cách mới cho nghệ thuật.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Trong bối cảnh đó, Mies đã thực hiện một bước ngoặt ngoạn mục với đồ án nhà kính chọc trời ở Berlin năm 1921. Công trình này có mặt bằng không chuẩn tắc, được loại bỏ các chi tiết trang trí của công trình. Về mặt kết cấu, công trình sử dụng hệ kết cấu thép, được bọc kính hoàn toàn, chan hòa ánh sáng đến tất cả các không gian<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/san-pham/noi-that/\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\" title=\"nội thất\">nội thất</a>, đã thể hiện một quan điểm hiện đại về tổ chức không gian ở. Với tư duy về kết cấu và kiến trúc, đồ án này của Mies có thể sánh với những công trình sau này của ông trên đất Mỹ vào thập niên 1950. Năm 1929, Mies cho ra đời công trình nổi tiếng nhất của mình, được xem như đỉnh cao của kiến trúc Đức thời bấy giờ, gian triển lãm của Đức tại triển lãm Barcelona, Tây Ban Nha năm 1929 (Công trình này hiện nay đã được phục chế lại.) Năm 1930, biệt thự Tugendhat ở Brno, Cộng hòa Séc, được xây dựng với dáng vẻ thanh nhã và hiện đại. Cả hai công trình đã thể hiện xuất sắc ý tưởng về “mặt bằng liên hoàn” của Mies.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <a href=\"http://www.alliance-hn.com/vietnam/News/News/uploaded_images/image005-718756.jpg\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\"><img alt=\"\" border=\"0\" class=\"aligncenter\" src=\"http://adkientruc.com/wp-content/uploads/2011/01/image005-718754.jpg\" style=\"border: none; display: block; margin: 0px auto 10px; max-width: 100%;\" /></a></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <span style=\"color: rgb(0, 0, 128);\"><em>Barcelona Pavilion, xây dựng năm 1929 cho cuộc Triển lãm Hoàn vũ, được sửa chữa vào năm 1983–1989</em></span></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Tháng 7 năm 1923, Mies cộng tác với tạp chí cấp tiến G. Năm 1925, ông tham gia sáng lập nhóm “Zehnerring” chống lại chủ nghĩa hình thức thuần túy. Ông nổi bật một cách xuất chúng như người lãnh đạo của phong trào Werkbund. Năm 1926, Mies được đề cử làm phó chủ tịch Werkbund, một phong trào cấp tiến thời bấy giờ do Hermann Muthesius sáng lập. Chính ông đã thiết kế quy hoạch chung cũng như thiết kế nhà ở tại dự án Weissenhof nổi tiếng của Werkbund, ở Stuttgart năm 1927. Về quan điểm thẩm mỹ, Mies bị ảnh hưởng mạnh của trường phái Kết cấu Nga và nhóm De Stijl của Hà Lan cũng như phong cách nhà ở thảo nguyên của kiến trúc sư người Mỹ Frank Lloyd Wright. Năm 1928, ông bắt đầu tham gia giảng dạy kiến trúc tại trường Bauhaus. Ông cũng thiết kế một số mẫu nội thất nổi tiếng, ví dụ như bàn ghế Barcelona và ghế Brno.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Sau sự ra đi của Hannes Meyer, trước đề nghị của Wal-ter Gropius, Mies chấp nhận lên làm hiệu trưởng đời thứ ba của trường Bauhaus, lúc này đang trong giai đoạn suy tàn. Ông đã tiếp tục một chương trình đầy tham vọng với trường Bauhaus, tuy nhiên do sự suy thoái kinh tế của cũng như áp lực của chính quyền phát xít thời đó đã không cho phép ông tiếp tục. Chính quyền phát xít đã ép Mies phải đóng cửa trường Bauhaus do có sự liên quan đến phong trào xã hội chủ nghĩa, chủ nghĩa cộng sản và các ý thức hệ khác. Trong giai đoạn này, Mies không xây dựng một công trình nổi bật nào, công trình lớn nhất của ông thời đó lại là căn hộ của Philip Johnson ở Thành phố New York. Mặt khác, phong cách kiến trúc của Mies bị nhà cầm quyền tẩy chay với lý do đi ngược lại truyền thống, không mang phong cách của Đức. Cuối cùng, khi cảm thấy mọi cơ hội phát triển cho tương lai của mình bị tiêu tan, Mies miễn cưỡng rời Đức vào năm 1937 sang Mỹ, nhận lời thiết kế một công trình nhà ở tại bang Wyoming.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> <strong>Thời gian tại Hoa Kỳ</strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <img alt=\"http://www.alliance-hn.com/vietnam/News/News/uploaded_images/image007-775737.jpg\" class=\"aligncenter\" src=\"http://adkientruc.com/wp-content/uploads/2011/01/image007-775737.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" /></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <em><span style=\"color: rgb(0, 0, 128);\">Trung tâm Ngân hàng Toronto Dominion – Toronto, Canada</span></em></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Rời Đức sau 30 năm hành nghề kiến trúc, Mies đã tạo được danh tiếng lẫy lừng, được xem như một trong những người tiên phong của Phong cách Quốc tế. Sau khi định cư ở Chicago, ông được đề nghị làm hiệu trưởng của trường Kiến trúc thuộc Học viện Kỹ thuật Thiết giáp (Armour Institute of Technology) ở Chicago, sau này đổi tên thành Học viện Kỹ thuật Illinois (Illinois Institute of Technology – IIT). Một trong những điều kiện mà Mies đặt ra với đề nghị này là phải để ông thiết kế một số tòa nhà mới của khu đại học. Một trong những tòa nhà đó còn tồn tại đến hiện nay, bao gồm giảng đường Crown, trụ sở trường Kiến trúc của IIT. Năm 1944, Mies nhập tịch Mỹ, hoàn toàn cắt đứt nguồn gốc Đức của mình.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Trong suốt thời gian 30 năm hành nghề kiến trúc tại Mỹ, Mies luôn kiên trì khẳng định tư tưởng và đường lối của mình nhằm hoàn thiện một nền kiến trúc mới của thế kỷ 20. Ông tập trung các nỗ lực của mình cho ý tưởng của một không gian tổng thể lớn, với trật tự kết cấu rõ ràng, được làm nổi bật bằng các thanh thép hình tiền chế, “chèn” bằng gạch và kính. Những công trình đầu tiên của Mies ở đây là khu học xá của IIT và một số công trình cho Herb Greenwald đã thức tỉnh người Mỹ về một phong cách được xem như sự tiếp nối tự nhiên, một âm hưởng văn hóa của trường phái Chicago cuối thế kỉ 19. Góc tường với việc sử dụng thép hình của tòa nhà Hải quân (Naval Building) ở IIT được ca ngợi coi đó như hình thức kinh điển của chủ nghĩa hiện đại hay đó là “cây cột Ionic của kiến trúc thế kỉ 20″. Do điều luật của sở cứu hỏa thành phố Chicago sau vụ đại hỏa hoạn năm 1871 yêu cầu phải bọc vật liệu chống cháy ra ngoài kết cấu chịu lực bằng kim loại đối với công trình có hơn 1 tầng buộc Mies phải giấu dầm thép chữ I vào trong tường gạch. Mặt khác Mies muốn bộc lộ kết cấu của công trình, cuối cùng ông đã chọn giải pháp áp các dầm thép chữ I vào hai bên cạnh tường. Các dầm này không có giá trị về mặt chịu lực mà chỉ dùng để trưng bày kết cấu chịu lực chính. Ở phía đáy dưới là một bản thép phẳng, ở trên đầu là một viên gạch mỏng. Tất cả các chi tiết bằng kim loại được sơn đen tạo thành một đối tượng thống nhất với tỉ lệ hoàn hảo chuyển tiếp từ một cạnh tường này sang tường bên kia. Giải pháp này được xem như một biểu tượng của kiến trúc mới và bức ảnh về góc tường này xuất hiện trong tất cả các cuốn sách về lịch sử kiến trúc hiện đại.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <a href=\"http://www.alliance-hn.com/vietnam/News/News/uploaded_images/image009-775770.jpg\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\"><img alt=\"\" border=\"0\" src=\"http://adkientruc.com/wp-content/uploads/2011/01/image009-775768.jpg\" style=\"border: none; max-width: 100%; margin: 0px auto 10px; display: block; text-align: center; cursor: pointer;\" /></a></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <em><span style=\"color: rgb(0, 0, 128);\">Nhà trưng bày nghệ thuật quốc gia Berlin</span></em></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Từ năm 1946 đến năm 1951, Mies thiết kế và xây dựng công trình nổi tiếng: Nhà kính Farnsworth. Đây là một công trình nhà nghỉ cuối tuần ở ngoại vi của Chicago cho nữ giáo sư tiến sĩ Edith Farnsworth. Tuyệt tác kiến trúc này đã chứng minh cho mọi người thấy kết cấu thép và kính là những vật liệu có khả năng tạo nên một công trình kiến trúc hoàn hảo. Tòa nhà kính mọc lên từ địa hình phẳng, bên cạnh sông Fox. Công trình phô trương những dầm thép hình chữ H được đặt thành từng hàng song song. Treo giữa các cột là ba phiến thép mỏng: Sàn, mái và hiên nhà. Toàn bộ kết cấu màu trắng tinh xác định một không gian giới hạn với bốn mặt kính chạy suốt chiều cao, cho phép ánh sáng tự nhiên thâm nhập vào không gian nội thất. Một “lõi” bằng gỗ chứa các bộ phận kỹ thuật của công trình, bếp, lò sưởi và khu vệ sinh được đặt bên trong không gian mở xác định các không gian khách, làm việc, ăn, ngủ mà hoàn toàn không cần đến một sự phân chia vật lý nào. Cũng không hề có một dấu vết của sự phân chia không gian nội thất nào đụng chạm tới bề mặt ngoài của công trình. Các tấm rèm treo suốt chiều cao được chạy vòng quanh chu vi công trình cho sẽ che chắn ánh sáng cũng như tạo ra không gian riêng tư khi cần thiết. Toàn bộ công trình thể hiện một sự tinh tế về thẩm mỹ, tạo cảm nhận dường như tòa nhà nhẹ nhàng bay khỏi mặt đất, là một vần thơ và một tuyệt phẩm nghệ thuật. Công trình này đã biểu lộ quan điểm của Mies về trật tự, trong sáng và đơn giản của kiến trúc. Năm 2004, tòa nhà kính Farnsworth cùng với khu rừng 60 mẫu xung quanh được một nhóm bảo tồn mua lại với giá là 7,5 triệu đô la. Ngày nay, quần thể này nằm dưới sự quản lí của Hội đồng Bảo tồn các Di tích của Illionois như một bảo tàng. Công trình này ảnh hưởng xuống hàng chục các tòa nhà hiện đại khác, nổi bật nhất trong số đó là tòa nhà kính (Glass House) của Phillip Johnson, được xây dựng ở gần New Canaan.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> <a href=\"http://www.alliance-hn.com/vietnam/News/News/uploaded_images/image011-719340.jpg\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\"><img alt=\"\" border=\"0\" src=\"http://adkientruc.com/wp-content/uploads/2011/01/image011-719337.jpg\" style=\"border: none; max-width: 100%; margin: 0px auto 10px; display: block; text-align: center; cursor: pointer;\" /></a></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <span style=\"color: rgb(0, 0, 128);\"><em>Westmount Plaza, Montréal, Canada, phiên bản thu nhỏ của toà nhà Seagram</em></span></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Từ năm 1951 đến năm 1952, Mies thiết kế nhà nghỉ mùa hè McCormich, nằm ở Elmhurst, Illinois, cho điền chủ Robert Hall McCormick Jr. Ý tưởng chính dựa trên mặt bằng điển hình của công trình nổi tiếng của ông: Ở đường Lake Shore Drive. Sau đó công trình này trở thành mẫu thiết kế điển hình cho một loạt công trình nhà lô sẽ được xây dựng ở Melrose Park, Illinois, mặc dù cuối cùng không được xây dựng. Tòa nhà McCormich hiện nay là một phần của Viện Bảo tàng Nghệ thuật Elmhurst.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Năm 1958, Mies thiết kế công trình được xem như đỉnh cao của<a href=\"http://adkientruc.com/san-pham/nha-cao-tang/\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\" title=\" nhà cao tầng\"><span class=\"Apple-converted-space\">&nbsp;</span>nhà cao tầng</a><span class=\"Apple-converted-space\">&nbsp;</span>trong kiến trúc hiện đại. Đó là tòa nhà Seagram ở thành phố New York. Mies được lựa chọn bởi bà Phyllis Bronfman Lambert, con gái của khách hàng, người sau này cũng sẽ trở thành một kiến trúc sư nổi tiếng. Tòa nhà Seagram trở thành một biểu tượng của một nền kiến trúc mới thế kỉ 20. Ngược lại so với lệ thường, Mies quyết định đặt công trình phía sau một quảng trường lớn và vòi phun nước tạo ra một khoảng không gian mở lớn phía trước đại lộ Park (Park Avenue). Mies phải tranh cãi rất nhiều với những chủ đầu tư về khai thác hoàn toàn khả năng của địa điểm công trình. Một điểm không bình thường nữa là một loạt dầm thép chữ I được đưa ra phía ngoài mặt đứng, đính lên trên mặt kính công trình. Những dầm thép này hoàn toàn không có giá trị gì về mặt kết cấu, nhưng nhờ đó đã biểu hiện được đặc điểm kết cấu công trình. Qua đó đã dập tắt mọi cuộc tranh cãi xem liệu Mies có phải là người ủng hộ quan điểm “trang trí là tội ác” của kiến trúc hiện đại không. Phillip Johnson cũng có một vai trò quan trọng trong thiết kế quảng trường và nhà hàng Bốn mùa trong công trình. Tòa nhà Seagram cũng được xem là công trình đầu tiên thuộc thể loại công trình xây dựng “siêu tốc” khi mà thiết kế và thi công làm đồng thời. Về sau Mies cũng cho ra đời một bản sao của công trình Seagram đó là Westmount Plaza ở Montréal, Canada.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Ông đã cống hiến rất nhiều thời gian và nỗ lực dẫn dắt trường Kiến trúc ở IIT, ông tin tưởng rằng các ý tưởng kiến trúc của ông có thể được truyền đạt qua giáo dục. Các đồ án thường liên quan đến các công trình thực tế của ông bên ngoài. Ông làm việc cật lực với các mẫu thiết kế, sau đó cho phép các sinh viên của mình tạo ra các biến thể cho các công trình đặc biệt dưới sự hướng dẫn của ông. Nhưng mỗi khi không sinh viên nào đạt được như ông mong muốn, Mies thường tự dày vò mình. Trong số các học trò của Mies có Gene Summers, David Haid, Myron Goldsmith, Jaques Brownsom, Helmut Jahn cũng như một loạt các kiến trúc sư khác của Murphy/Jahn và Skidmore, Owings &amp; Merrill.</p></div>', '', 1, 0, 1, 1, 1), 
(5, '<h1 class=\"entry-title\" style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 20px; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> Điểm danh 7 khách sạn, khu nghỉ dưỡng đẹp nhất của các sao</h1><span style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); display: inline !important; float: none;\">﻿</span><span class=\"categories\" style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51) !important; font-size: 12px; font-weight: bold !important; font-family: Arial; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\">Chuyên mục:<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/kien-truc-360/cong-trinh-kien-truc-noi-tieng/\" rel=\"category tag\" style=\"color: rgb(148, 64, 64) !important; text-decoration: initial;\" title=\"View all posts in Công trình kiến trúc nổi tiếng\">Công trình kiến trúc nổi tiếng</a></span><div class=\"post-info\" style=\"color: rgb(51, 51, 51); font-size: 12px; margin: 0px 0px 5px; padding: 0px; font-family: Arial; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <b style=\"font-weight: bold;\">Ngày :<span class=\"Apple-converted-space\">&nbsp;</span></b><span class=\"date time published\" style=\"margin: 0px; padding: 0px;\" title=\"2012-09-19T16:56:57+0000\">19/09/2012</span></div><div class=\"entry-content\" style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> <strong>Ờ bài viết này chúng tôi xin đưa các bạn đọc đến thăm các khách sạn&nbsp;sang trọng&nbsp;bậc nhất thế giới. Và không ai hết chủ sở hữu của các khách sạn này là các ngôi sao hàng đầu thế giới</strong></p> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> 1. Khách sạn Palazzo Margherita (Francisco Ford Coppola)</h2> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Mới khai trương hồi đầu năm nay tại Bernalda (Italy), Palazzo là thành viên mới nhất trong chuỗi tổ hợp kinh doanh mang tên Coppola Resorts của đạo diễn người Mỹ Francisco Ford Coppola. Ông chính là đạo diễn bộ phim kinh điển The Godfather (Bố già). Khách sạn hạng sang được thiết kế bởi chính các con của Coppola và nhà thiết kế nổi tiếng Pháp, Jaques Grange, tạo không gian ấm cúng như một ngôi nhà dành cho đại gia đình.</p> <div style=\"text-align: center;\"> <img alt=\"\" src=\"http://adkientruc.com/wp-content/uploads/2012/09/691343.jpeg\" style=\"max-width: 100%; height: 320px;\" /></div> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> 2. Khách sạn The Clarence ( Bono và The Edge )</h2> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Tọa lạc tại thành phố Dublin của Ireland, The Clarence thuộc sở hữu của Bono và The Edge – hai thành viên nhóm nhạc đình đám U2. Khách sạn gồm 49 phòng và mỗi phòng có thiết kế riêng, giúp khách có nhiều lựa chọn hơn. Màu sắc được lựa chọn cho<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/san-pham/noi-that/\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\" title=\"nội thất\">nội thất</a><span class=\"Apple-converted-space\">&nbsp;</span>The Clarence rất phong phú, từ màu đỏ thẫm tới xanh lam, từ màu thạch anh tím tới màu vàng quý phái và màu nâu choocolate.</p> <div style=\"text-align: center;\"> <img alt=\"\" src=\"http://adkientruc.com/wp-content/uploads/2012/09/691344.jpeg\" style=\"max-width: 100%; height: 320px;\" /></div> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> 3. Khu nghỉ dưỡng Mission Ranch (Clint Eastwood )</h2> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Đạo diễn tài ba Clint Eastwood đã cải tạo trang trại có từ thập niên 80 của mình ở Carmel (bang California) trở thành “một trải nghiệm về thiên đường nghỉ dưỡng độc đáo”. Khu này có 31 phòng với 10 ngôi nhà tách biệt trong khu tổ hợp rộng gần 9 ha. Từ khu nghỉ dưỡng này, khách có thể chiêm ngưỡng vẻ đẹp của Khu bảo tồn tự nhiên quốc gia Mỹ Point Lobos, Bãi biển Carmel River và Thái Bình Dương. Trong lúc thưởng thức bữa tối tại nhà hàng khách sạn, bạn có thể thảnh thơi ngắm cảnh đàn cừu đang gặm cỏ trong ráng chiều thơ mộng.</p> <div style=\"text-align: center;\"> <img alt=\"\" src=\"http://adkientruc.com/wp-content/uploads/2012/09/691345.jpeg\" style=\"max-width: 100%; height: 320px;\" /></div> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> 4. Khách sạn Cardozo (Gloria Estefan )</h2> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Nữ ca sĩ Gloria Estefan và ông xã Emilio – nhà sản xuất từng giành giải Oscar – là chủ sở hữu khách sạn Cardozo gần bãi biển Miami (Florida). Khách sạn có 43 phòng thường và 4 phòng VIP. Ấn tượng nổi bật nhất về Cardozo chính là sự hài hòa giữa các nền văn hóa khác nhau. Bên cạnh đó, cặp đôi này còn sở hữu một bất động sản khác ở Bãi biển Vero, bang Florida.</p> <div style=\"text-align: center;\"> <img alt=\"\" src=\"http://adkientruc.com/wp-content/uploads/2012/09/691346.jpeg\" style=\"max-width: 100%; height: 320px;\" /></div> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> 5. Khách sạn Greenwich (Robert De Niro )</h2> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Đây là khách sạn cao cấp gồm 88 phòng, tọa lạc tại khu thương mại TriBeCa sầm uất ở trung tâm Manhattan do nam diễn viên kỳ cựu Robert De Niro làm chủ. Bể bơi và spa chính là hai điểm nổi bật nhất của Greenwich. Nhà hàng mang đậm phong cách Ý, Locanda Verde, bên trong khách sạn, cũng rất đáng để bạn thử nếu ghé thăm nơi đây.</p> <div style=\"text-align: center;\"> <img alt=\"\" src=\"http://adkientruc.com/wp-content/uploads/2012/09/691347.jpeg\" style=\"max-width: 100%; height: 320px;\" /></div> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> 6. Khách sạn The Rival (Benny Anderson)</h2> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Gồm 99 phòng, The Rival là khách sạn cao cấp đầu tiên tại Stockholm – Thụy Điển. Chủ sở hữu của nó là giọng ca Benny Anderson trong ban nhạc huyền thoại ABBA. Bên cạnh thiết kế cực kỳ cá tính và hiện đại, The Rival còn nổi tiếng với chất lượng đồ ăn, đồ uống được phục vụ tại Café Rival.</p> <div style=\"text-align: center;\"> <img alt=\"\" src=\"http://adkientruc.com/wp-content/uploads/2012/09/691348.jpeg\" style=\"max-width: 100%; height: 320px;\" /></div> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> 7. Khách sạn Cypress Inn (Doris Day )</h2> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Doris Day, nữ diễn viên kiêm ca sĩ, từng có 50 năm kinh nghiệm trong lĩnh vực giải trí, là người đồng sở hữu khách sạn Cypress suốt 20 năm qua. Gồm 44 phòng, khách sạn nằm bên bờ biển, thuộc phạm vi ngôi làng Carmel ở California. Vẻ đẹp kiểu cổ điển quyến rũ như trong tranh làm nên sức hấp dẫn của khách sạn, bên cạnh hệ thống sân golf xanh. Là một người rất yêu mến động vật nên Doris Day cho phép khách sạn Cypress Inn kinh doanh cả dịch vụ chăm sóc thú cưng của khách. Nếu bạn không muốn rời xa con vật yêu quý của mình, bạn có thể ăn tối với chúng trong nhà hàng khách sạn.</p> <div style=\"text-align: center;\"> <img alt=\"\" src=\"http://adkientruc.com/wp-content/uploads/2012/09/691349.jpeg\" style=\"max-width: 100%; height: 320px;\" /></div></div>', '', 1, 0, 1, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_bodytext`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_bodytext`;
CREATE TABLE `nv3_vi_kien_truc_360_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_kien_truc_360_bodytext`
--

INSERT INTO `nv3_vi_kien_truc_360_bodytext` VALUES
(1, ' Không gian nhà bếp nổi bật 2012﻿Chuyên mục: http://adkientruc.com/kien-truc-360/khong-gian-song/ Không gian sống Ngày : 03/11/2012 Một http://kientructhiennam.com/khong-gian-bep-dep-2012-3877 không gian bếp đẹp “có cá tính” chính là một “nét duyên” trong ngôi nhà và có thể đem lại cho các thành viên trong gia đình cảm xúc ấm áp mỗi khi bước vào. Có thể nhiều người không quan trọng việc trang hoàng bếp núc vì cho rằng không nhất thiết phải cầu kỳ vì khi chỉ dùng nó cho công việc nấu ăn, song không quá khó khăn và tốn kém để đổi mới gian bếp nhà mình. Không gian bếp thân thiện với môi trường Từ những gì gia đình bạn ăn trong nhà bếp, cho tới chi phí chạy các thiết bị nhà bếp của bạn, đều có thể được cải thiện để tiết kiệm chi phí cho bạn và giúp cải thiện nguồn tài nguyên có giá trị của Trái đất. Nếu bạn đang cố gắng để làm xanh hơn nhà bếp của bạn, thì những cách hữu ích sau đây sẽ giúp bạn và gia đình thay đổi thói quen vào bếp hàng ngày. http://adkientruc.com/wp-content/uploads/2012/11/bep-xanh-tot-cho-suc-khoe-1-.jpg http://adkientruc.com/wp-content/uploads/2012/11/bep-xanh-tot-cho-suc-khoe-3-.jpg Không gian bếp hiện đại Không gian bếp hiện đại được thiết kế theo phong cách riêng, thoáng nhìn qua đã hiểu được phần nào tính cách của người chủ. http://adkientruc.com/wp-content/uploads/2012/11/04_111104DOOLThangMB09.jpg Căn bếp hiện đại được kết hợp các yếu tố tự nhiên và công nghiệp. Căn bếp với các thiết bị hiện đại như tủ lạnh, lò vi sóng và quầy bar phía trước. Ánh sáng từ cửa sổ mang lại luồng sinh khí mới và lưu thông trong căn bếp. http://adkientruc.com/wp-content/uploads/2012/11/nhung-mau-phong-bep-dep-2012-4.jpg Những mẫu phòng bếp đẹp năm 2012 - Archi Đưa những tiện nghi giải trí vào trong nhà bếp http://adkientruc.com/wp-content/uploads/2012/11/20120423afamilyNDxuhuongnhabep-7_8b0ca.jpg Xu hướng thiết kế nhà bếp 2012 ( Phần cuối) Khi mọi người ngày càng trở nên hiểu biết về công nghệ thì tiện nghi nhà bếp và phòng tắm cũng được quan tâm và chú trọng nhiều hơn. Các trang trí truyền thống dần nhường chỗ cho các thiết bị điện tử. Các mặt hàng điện tử phổ biến như tivi gắn tường, máy tính quan sát, hệ thống âm thanh giải trí… đều được yêu thích. Đây thực chất là một xu hướng song hành với xu hướng “không dây” đang ngày càng thịnh hành. Sản phẩm sinh thái thân thiện http://adkientruc.com/wp-content/uploads/2012/11/20120423afamilyNDxuhuongnhabep-8_8a65a.jpg Xu hướng thiết kế nhà bếp 2012 ( Phần cuối) Sản phẩm được làm từ vật liệu bền vững đang ngày càng được ưa chuộng. Tủ bếp sinh thái thân thiện từ tre hay gỗ vừa mang lại cảm giác ấm cúng, gần gũi lại cải thiện được chất lượng không khí trong nhà. Vòi nước và các giải pháp tiết kiệm năng lượng cũng được các chủ nhà ưu tiên nhằm giảm bớt con số trên hóa đơn và giảm việc sử dụng các nguồn tài nguyên thiên nhiên.'), 
(2, ' Chọn cửa hàng kinh doanh theo Phong thủy﻿Chuyên mục: http://adkientruc.com/kien-truc-360/phong-thuy/ Phong thủy Ngày : 17/06/2012 Nên chọn vị trí dương trạch theo http://adkientruc.com/kien-truc-360/phong-thuy/ phong thủy như sau: http://adkientruc.com/wp-content/uploads/2012/06/kinh-doanh-va-thuat-phong-thuy.jpg Chọn cửa hàng kinh doanh theo phong thủy - Archi Nên tựa núi hướng sông Núi mà dương trạch tựa vào phải là núi có thế như con rồng phú quý. Sông mà nó hướng vào phải có hình uốn cong bao xung quanh. Khi chọn cửa hàng thì phải chọn thế “tựa núi hướng sông”. Đây là cách chọn lựa vị trí lý tưởng nhất trong dương trạch. Theo http://adkientruc.com/tag/phong-thuy/ phong thủy có thế tựa vào núi khiến người ta có cảm giác an tâm, yên ổn. Sau nhà mà có núi sẽ là một bức bình phong chắn gió vô cùng vững chắc. Nếu nơi đặt cửa hàng hướng ra sông, mặt nước trong sạch mát mẻ có thể mang lại không khí trong lành cho mọi người. Thế đất cao hướng ra sông Theo phong thủy xưa nếu vị trí cửa hàng ở khu vực không có núi thì nên chọn vị trí đất cao hướng ra sông. Đặt cửa hàng ở vị trí cao hướng ra sông sẽ tạo thành một hình thế trước thấp sau cao sẽ giúp cho nó được tựa lưng vào chỗ cao. Hơn thế không khí trong lành từ mặt sông thổi lại sẽ mang theo hơi nước mát lành. Chọn mảnh đất có sinh khí Quan niệm phong thủy cho rằng có người là có sinh khí, người càng nhiều, sinh khí càng vượng, sinh khí tốt sẽ đem lại sự hưng thịnh trong buôn bán. Lựa chọn mở cửa hàng ở những nơi đông dân cư ta có thể chủ động giới thiệu sản phẩm của cửa hàng với khách. Vị trí mà hấp dẫn được khách thì mới có tác dụng thúc đẩy kinh doanh, buôn bán phát tài và đảm bảo được doanh thu và lợi nhuận. Ngược lại mở cửa hàng ở những nơi vắng vẻ thì đồng nghĩa tự đưa mình vào chỗ khó khăn. Khách hàng sẽ ít dẫn đến doanh thu ít và sẽ phải đóng cửa là điều không thể tránh. Mặt khác theo phong thủy, người đại diện cho sinh khí, không có người đến cửa hàng thì ắt sẽ thiếu đi sinh khí. Sinh khí mà ít thì Âm khí sẽ mạnh lên. Một cửa hàng mà Âm khí quá nhiều, không những buôn bán lỗ vốn, nghiêm trọng hơn nó sẽ làm tổn thương đến nguyên khí của chủ cửa hàng, khiến cho cửa hàng phá sản. Nên chọn mảnh đất sạch sẽ Chọn vị trí để kinh doanh, đặt cửa hàng đòi hỏi mảnh đất được chọn phải sạch sẽ, khô ráo. Nếu mảnh đất chọn để xây nhà không tốt, ẩm thấp quá hoặc bốc lên mùi hôi thối sẽ làm ảnh hưởng đến sức khỏe cho người cư trú ở đó và đồng thời sẽ không hấp dẫn khách hàng đến cửa hàng. Điều này sẽ đặc biệt bất lợi trong kinh doanh.'), 
(3, ' Ngôi nhà nứt làm ba﻿Chuyên mục: http://adkientruc.com/kien-truc-360/kien-truc-la/ Kiến trúc lạ Ngày : 14/03/2012 Một ngôi nhà ở Mỹ đã khiến cho không ít người phải ngạc nhiên bởi http://adkientruc.com/ kiến trúc quái dị của nó. Nhìn từ xa ngôi nhà bị gãy khúc giống như mới trải qua một trận động đất kinh hoàng. Ngôi nhà kỳ quái có khẩu hiệu: “Ripley’s Believe It Or Not” (Tin hay không) ở Branson, tiểu bang Missouri, Mỹ có chiều cao hơn 12 mét và chiều rộng 365 mét. Ngôi nhà nổi bật lên với một kiến trúc quái dị nhất bạn từng thấy. http://adkientruc.com/wp-content/uploads/2012/03/ngoi-nha-dut-gay-doc-dao1.jpg Ngôi nhà http://adkientruc.com/wp-content/uploads/2012/03/ngoi-nha-dut-gay-doc-dao2.jpg Ngôi nhà Ngôi nhà đã đánh lừa thị giác của không ít người. Người quản lý ngôi nhà, ông Gary Daily cho biết: “Ngôi nhà này được xây dựng vào năm 1999, kiến trúc của nó trông giống như một ngôi nhà bị tác động bởi trận động đất. Ý tưởng khi xây dựng ngôi nhà này là để tái hiện lại hình ảnh về trận động đất kinh hoàng trong lịch sử mạnh 8 độ richter năm 1812. Thật buồn cười khi nhìn thấy những người đi qua ngôi nhà, tất cả đều ngạc nhiên và không thốt nên lời.” Hiện tại, ngôi nhà độc đáo này đã được khoác bộ cánh mới màu vàng dịu. http://adkientruc.com/wp-content/uploads/2012/03/ngoi-nha-dut-gay-doc-dao3.jpg Ngôi nhà http://adkientruc.com/wp-content/uploads/2012/03/ngoi-nha-dut-gay-doc-dao4.jpg Ngôi nhà '), 
(4, ' Kiến trúc sư Ludwig Mies van der Rohe﻿Chuyên mục: http://adkientruc.com/kien-truc-360/kts-noi-tieng/ KTS Nổi tiếng Ngày : 13/01/2011 Ludwig Mies van der Rohe (Sinh ngày 27 tháng 3 năm 1886 – mất ngày 19 tháng 8 năm 1969) là một http://adkientruc.com/ kiến trúc sư nổi tiếng thế giới người Đức. Ông là một trong những người đặt nền móng cho sự phát triển của trào lưu Kiến trúc hiện đại của thế kỉ 20 và được xem như cha đẻ của phong cách Kiến trúc tối thiểu (Minimalism). http://www.alliance-hn.com/vietnam/News/News/uploaded_images/image001-749835.jpg http://adkientruc.com/wp-content/uploads/2011/01/image001-749833.jpg Thời gian tại Đức Ông sinh ra tại Aachen, Đức, với tên là Maria Ludwig Michael Mies, là con trai của một người thợ đá thủ công, điều này đã ảnh hưởng sâu sắc tới quan điểm thực hành trong kiến trúc của ông sau này. Sau đó ông chuyển tới Berlin làm việc ở văn phòng thiết kế của Brono Paul, và từ năm 1908 đến năm 1912 làm việc tại xưởng thiết kế của Peter Behrens, một trong những người tiên phong của kiến trúc Đức thời bấy giờ. Mies đã học được rất nhiều về lý thuyết thiết kế cũng như sự phát triển của văn hóa Đức thời bấy giờ. Cũng tại xưởng thiết kế của Behrens, Mies đã gặp gỡ và làm việc cùng với Le Corbusier và Wal-ter Gropius. Với dáng vóc vạm vỡ, tính tình cẩn thận và là một con người trầm lặng, ít nói, người thanh niên tài năng Ludwig Mies tự đổi tên, lột xác từ con trai một người thợ tỉnh lẻ trở thành một kiến trúc sư làm việc với giới thượng lưu ở Berlin thời bấy giờ, bằng cách thêm ba chữ “van der Rohe” như một tên hiệu quý tộc. Ông bắt đầu sự nghiệp độc lâp của mình bằng cách thiết kế một số công trình nhà ở theo phong cách kiến trúc truyền thống của Đức. Mies ưa thích những tỉ lệ lớn, những hình khối không gian của kiến trúc sư Tân Cổ điển nước Phổ thế kỉ 19 là Karl Friedrich Schinkel, trong khi bỏ qua những xu hướng cổ điển chiết trung và hỗn độn của buổi giao thời. http://www.alliance-hn.com/vietnam/News/News/uploaded_images/image003-718730.jpg http://adkientruc.com/wp-content/uploads/2011/01/image003-718727.jpg Nhà ở tại Weissenhof Sau Thế chiến thứ nhất, Mies bắt đầu từ bỏ phong cách truyền thống và gia nhập hàng ngũ những người tiên phong trên con đường đi tìm một phong cách mới trong thời đại mới. Phong cách cổ điển từ lâu đã bị các nhà phê bình nghệ thuật chỉ trích từ giữa thế kỉ 19, chủ yếu do sự lạm dụng các chi tiết trang trí bề mặt, không tương xứng với sự phát triển của các kết cấu xây dựng bên trong công trình. Sự chỉ trích tấn công vào truyền thống cổ điển càng thắng thế, nhất là với sự sụp đổ của các đế chế vương quyền châu Âu, sau Thế chiến thứ nhất. Kiến trúc truyền thống giờ đây bị xem như tàn tích của quá khứ, của một chế độ chính trị không hợp thời. Mặt khác, dưới sự bùng nổ phát triển của nền sản xuất công nghiệp hóa châu Âu thời bấy giờ đòi hỏi một tư duy mới về kỹ thuật đã thúc đẩy quá trình tìm kiếm một phong cách mới cho nghệ thuật. Trong bối cảnh đó, Mies đã thực hiện một bước ngoặt ngoạn mục với đồ án nhà kính chọc trời ở Berlin năm 1921. Công trình này có mặt bằng không chuẩn tắc, được loại bỏ các chi tiết trang trí của công trình. Về mặt kết cấu, công trình sử dụng hệ kết cấu thép, được bọc kính hoàn toàn, chan hòa ánh sáng đến tất cả các không gian http://adkientruc.com/san-pham/noi-that/ nội thất, đã thể hiện một quan điểm hiện đại về tổ chức không gian ở. Với tư duy về kết cấu và kiến trúc, đồ án này của Mies có thể sánh với những công trình sau này của ông trên đất Mỹ vào thập niên 1950. Năm 1929, Mies cho ra đời công trình nổi tiếng nhất của mình, được xem như đỉnh cao của kiến trúc Đức thời bấy giờ, gian triển lãm của Đức tại triển lãm Barcelona, Tây Ban Nha năm 1929 (Công trình này hiện nay đã được phục chế lại.) Năm 1930, biệt thự Tugendhat ở Brno, Cộng hòa Séc, được xây dựng với dáng vẻ thanh nhã và hiện đại. Cả hai công trình đã thể hiện xuất sắc ý tưởng về “mặt bằng liên hoàn” của Mies. http://www.alliance-hn.com/vietnam/News/News/uploaded_images/image005-718756.jpg http://adkientruc.com/wp-content/uploads/2011/01/image005-718754.jpg Barcelona Pavilion, xây dựng năm 1929 cho cuộc Triển lãm Hoàn vũ, được sửa chữa vào năm 1983–1989 Tháng 7 năm 1923, Mies cộng tác với tạp chí cấp tiến G. Năm 1925, ông tham gia sáng lập nhóm “Zehnerring” chống lại chủ nghĩa hình thức thuần túy. Ông nổi bật một cách xuất chúng như người lãnh đạo của phong trào Werkbund. Năm 1926, Mies được đề cử làm phó chủ tịch Werkbund, một phong trào cấp tiến thời bấy giờ do Hermann Muthesius sáng lập. Chính ông đã thiết kế quy hoạch chung cũng như thiết kế nhà ở tại dự án Weissenhof nổi tiếng của Werkbund, ở Stuttgart năm 1927. Về quan điểm thẩm mỹ, Mies bị ảnh hưởng mạnh của trường phái Kết cấu Nga và nhóm De Stijl của Hà Lan cũng như phong cách nhà ở thảo nguyên của kiến trúc sư người Mỹ Frank Lloyd Wright. Năm 1928, ông bắt đầu tham gia giảng dạy kiến trúc tại trường Bauhaus. Ông cũng thiết kế một số mẫu nội thất nổi tiếng, ví dụ như bàn ghế Barcelona và ghế Brno. Sau sự ra đi của Hannes Meyer, trước đề nghị của Wal-ter Gropius, Mies chấp nhận lên làm hiệu trưởng đời thứ ba của trường Bauhaus, lúc này đang trong giai đoạn suy tàn. Ông đã tiếp tục một chương trình đầy tham vọng với trường Bauhaus, tuy nhiên do sự suy thoái kinh tế của cũng như áp lực của chính quyền phát xít thời đó đã không cho phép ông tiếp tục. Chính quyền phát xít đã ép Mies phải đóng cửa trường Bauhaus do có sự liên quan đến phong trào xã hội chủ nghĩa, chủ nghĩa cộng sản và các ý thức hệ khác. Trong giai đoạn này, Mies không xây dựng một công trình nổi bật nào, công trình lớn nhất của ông thời đó lại là căn hộ của Philip Johnson ở Thành phố New York. Mặt khác, phong cách kiến trúc của Mies bị nhà cầm quyền tẩy chay với lý do đi ngược lại truyền thống, không mang phong cách của Đức. Cuối cùng, khi cảm thấy mọi cơ hội phát triển cho tương lai của mình bị tiêu tan, Mies miễn cưỡng rời Đức vào năm 1937 sang Mỹ, nhận lời thiết kế một công trình nhà ở tại bang Wyoming. Thời gian tại Hoa Kỳ http://adkientruc.com/wp-content/uploads/2011/01/image007-775737.jpg http://www.alliance-hn.com/vietnam/News/News/uploaded_images/image007-775737.jpg Trung tâm Ngân hàng Toronto Dominion – Toronto, Canada Rời Đức sau 30 năm hành nghề kiến trúc, Mies đã tạo được danh tiếng lẫy lừng, được xem như một trong những người tiên phong của Phong cách Quốc tế. Sau khi định cư ở Chicago, ông được đề nghị làm hiệu trưởng của trường Kiến trúc thuộc Học viện Kỹ thuật Thiết giáp (Armour Institute of Technology) ở Chicago, sau này đổi tên thành Học viện Kỹ thuật Illinois (Illinois Institute of Technology – IIT). Một trong những điều kiện mà Mies đặt ra với đề nghị này là phải để ông thiết kế một số tòa nhà mới của khu đại học. Một trong những tòa nhà đó còn tồn tại đến hiện nay, bao gồm giảng đường Crown, trụ sở trường Kiến trúc của IIT. Năm 1944, Mies nhập tịch Mỹ, hoàn toàn cắt đứt nguồn gốc Đức của mình. Trong suốt thời gian 30 năm hành nghề kiến trúc tại Mỹ, Mies luôn kiên trì khẳng định tư tưởng và đường lối của mình nhằm hoàn thiện một nền kiến trúc mới của thế kỷ 20. Ông tập trung các nỗ lực của mình cho ý tưởng của một không gian tổng thể lớn, với trật tự kết cấu rõ ràng, được làm nổi bật bằng các thanh thép hình tiền chế, “chèn” bằng gạch và kính. Những công trình đầu tiên của Mies ở đây là khu học xá của IIT và một số công trình cho Herb Greenwald đã thức tỉnh người Mỹ về một phong cách được xem như sự tiếp nối tự nhiên, một âm hưởng văn hóa của trường phái Chicago cuối thế kỉ 19. Góc tường với việc sử dụng thép hình của tòa nhà Hải quân (Naval Building) ở IIT được ca ngợi coi đó như hình thức kinh điển của chủ nghĩa hiện đại hay đó là “cây cột Ionic của kiến trúc thế kỉ 20″. Do điều luật của sở cứu hỏa thành phố Chicago sau vụ đại hỏa hoạn năm 1871 yêu cầu phải bọc vật liệu chống cháy ra ngoài kết cấu chịu lực bằng kim loại đối với công trình có hơn 1 tầng buộc Mies phải giấu dầm thép chữ I vào trong tường gạch. Mặt khác Mies muốn bộc lộ kết cấu của công trình, cuối cùng ông đã chọn giải pháp áp các dầm thép chữ I vào hai bên cạnh tường. Các dầm này không có giá trị về mặt chịu lực mà chỉ dùng để trưng bày kết cấu chịu lực chính. Ở phía đáy dưới là một bản thép phẳng, ở trên đầu là một viên gạch mỏng. Tất cả các chi tiết bằng kim loại được sơn đen tạo thành một đối tượng thống nhất với tỉ lệ hoàn hảo chuyển tiếp từ một cạnh tường này sang tường bên kia. Giải pháp này được xem như một biểu tượng của kiến trúc mới và bức ảnh về góc tường này xuất hiện trong tất cả các cuốn sách về lịch sử kiến trúc hiện đại. http://www.alliance-hn.com/vietnam/News/News/uploaded_images/image009-775770.jpg http://adkientruc.com/wp-content/uploads/2011/01/image009-775768.jpg Nhà trưng bày nghệ thuật quốc gia Berlin Từ năm 1946 đến năm 1951, Mies thiết kế và xây dựng công trình nổi tiếng: Nhà kính Farnsworth. Đây là một công trình nhà nghỉ cuối tuần ở ngoại vi của Chicago cho nữ giáo sư tiến sĩ Edith Farnsworth. Tuyệt tác kiến trúc này đã chứng minh cho mọi người thấy kết cấu thép và kính là những vật liệu có khả năng tạo nên một công trình kiến trúc hoàn hảo. Tòa nhà kính mọc lên từ địa hình phẳng, bên cạnh sông Fox. Công trình phô trương những dầm thép hình chữ H được đặt thành từng hàng song song. Treo giữa các cột là ba phiến thép mỏng: Sàn, mái và hiên nhà. Toàn bộ kết cấu màu trắng tinh xác định một không gian giới hạn với bốn mặt kính chạy suốt chiều cao, cho phép ánh sáng tự nhiên thâm nhập vào không gian nội thất. Một “lõi” bằng gỗ chứa các bộ phận kỹ thuật của công trình, bếp, lò sưởi và khu vệ sinh được đặt bên trong không gian mở xác định các không gian khách, làm việc, ăn, ngủ mà hoàn toàn không cần đến một sự phân chia vật lý nào. Cũng không hề có một dấu vết của sự phân chia không gian nội thất nào đụng chạm tới bề mặt ngoài của công trình. Các tấm rèm treo suốt chiều cao được chạy vòng quanh chu vi công trình cho sẽ che chắn ánh sáng cũng như tạo ra không gian riêng tư khi cần thiết. Toàn bộ công trình thể hiện một sự tinh tế về thẩm mỹ, tạo cảm nhận dường như tòa nhà nhẹ nhàng bay khỏi mặt đất, là một vần thơ và một tuyệt phẩm nghệ thuật. Công trình này đã biểu lộ quan điểm của Mies về trật tự, trong sáng và đơn giản của kiến trúc. Năm 2004, tòa nhà kính Farnsworth cùng với khu rừng 60 mẫu xung quanh được một nhóm bảo tồn mua lại với giá là 7,5 triệu đô la. Ngày nay, quần thể này nằm dưới sự quản lí của Hội đồng Bảo tồn các Di tích của Illionois như một bảo tàng. Công trình này ảnh hưởng xuống hàng chục các tòa nhà hiện đại khác, nổi bật nhất trong số đó là tòa nhà kính (Glass House) của Phillip Johnson, được xây dựng ở gần New Canaan. http://www.alliance-hn.com/vietnam/News/News/uploaded_images/image011-719340.jpg http://adkientruc.com/wp-content/uploads/2011/01/image011-719337.jpg Westmount Plaza, Montréal, Canada, phiên bản thu nhỏ của toà nhà Seagram Từ năm 1951 đến năm 1952, Mies thiết kế nhà nghỉ mùa hè McCormich, nằm ở Elmhurst, Illinois, cho điền chủ Robert Hall McCormick Jr. Ý tưởng chính dựa trên mặt bằng điển hình của công trình nổi tiếng của ông: Ở đường Lake Shore Drive. Sau đó công trình này trở thành mẫu thiết kế điển hình cho một loạt công trình nhà lô sẽ được xây dựng ở Melrose Park, Illinois, mặc dù cuối cùng không được xây dựng. Tòa nhà McCormich hiện nay là một phần của Viện Bảo tàng Nghệ thuật Elmhurst. Năm 1958, Mies thiết kế công trình được xem như đỉnh cao củahttp://adkientruc.com/san-pham/nha-cao-tang/ nhà cao tầng trong kiến trúc hiện đại. Đó là tòa nhà Seagram ở thành phố New York. Mies được lựa chọn bởi bà Phyllis Bronfman Lambert, con gái của khách hàng, người sau này cũng sẽ trở thành một kiến trúc sư nổi tiếng. Tòa nhà Seagram trở thành một biểu tượng của một nền kiến trúc mới thế kỉ 20. Ngược lại so với lệ thường, Mies quyết định đặt công trình phía sau một quảng trường lớn và vòi phun nước tạo ra một khoảng không gian mở lớn phía trước đại lộ Park (Park Avenue). Mies phải tranh cãi rất nhiều với những chủ đầu tư về khai thác hoàn toàn khả năng của địa điểm công trình. Một điểm không bình thường nữa là một loạt dầm thép chữ I được đưa ra phía ngoài mặt đứng, đính lên trên mặt kính công trình. Những dầm thép này hoàn toàn không có giá trị gì về mặt kết cấu, nhưng nhờ đó đã biểu hiện được đặc điểm kết cấu công trình. Qua đó đã dập tắt mọi cuộc tranh cãi xem liệu Mies có phải là người ủng hộ quan điểm “trang trí là tội ác” của kiến trúc hiện đại không. Phillip Johnson cũng có một vai trò quan trọng trong thiết kế quảng trường và nhà hàng Bốn mùa trong công trình. Tòa nhà Seagram cũng được xem là công trình đầu tiên thuộc thể loại công trình xây dựng “siêu tốc” khi mà thiết kế và thi công làm đồng thời. Về sau Mies cũng cho ra đời một bản sao của công trình Seagram đó là Westmount Plaza ở Montréal, Canada. Ông đã cống hiến rất nhiều thời gian và nỗ lực dẫn dắt trường Kiến trúc ở IIT, ông tin tưởng rằng các ý tưởng kiến trúc của ông có thể được truyền đạt qua giáo dục. Các đồ án thường liên quan đến các công trình thực tế của ông bên ngoài. Ông làm việc cật lực với các mẫu thiết kế, sau đó cho phép các sinh viên của mình tạo ra các biến thể cho các công trình đặc biệt dưới sự hướng dẫn của ông. Nhưng mỗi khi không sinh viên nào đạt được như ông mong muốn, Mies thường tự dày vò mình. Trong số các học trò của Mies có Gene Summers, David Haid, Myron Goldsmith, Jaques Brownsom, Helmut Jahn cũng như một loạt các kiến trúc sư khác của Murphy/Jahn và Skidmore, Owings & Merrill.'), 
(5, ' Điểm danh 7 khách sạn, khu nghỉ dưỡng đẹp nhất của các sao﻿Chuyên mục: http://adkientruc.com/kien-truc-360/cong-trinh-kien-truc-noi-tieng/ Công trình kiến trúc nổi tiếng Ngày : 19/09/2012 Ờ bài viết này chúng tôi xin đưa các bạn đọc đến thăm các khách sạn sang trọng bậc nhất thế giới. Và không ai hết chủ sở hữu của các khách sạn này là các ngôi sao hàng đầu thế giới 1. Khách sạn Palazzo Margherita (Francisco Ford Coppola) Mới khai trương hồi đầu năm nay tại Bernalda (Italy), Palazzo là thành viên mới nhất trong chuỗi tổ hợp kinh doanh mang tên Coppola Resorts của đạo diễn người Mỹ Francisco Ford Coppola. Ông chính là đạo diễn bộ phim kinh điển The Godfather (Bố già). Khách sạn hạng sang được thiết kế bởi chính các con của Coppola và nhà thiết kế nổi tiếng Pháp, Jaques Grange, tạo không gian ấm cúng như một ngôi nhà dành cho đại gia đình. http://adkientruc.com/wp-content/uploads/2012/09/691343.jpeg 2. Khách sạn The Clarence ( Bono và The Edge ) Tọa lạc tại thành phố Dublin của Ireland, The Clarence thuộc sở hữu của Bono và The Edge – hai thành viên nhóm nhạc đình đám U2. Khách sạn gồm 49 phòng và mỗi phòng có thiết kế riêng, giúp khách có nhiều lựa chọn hơn. Màu sắc được lựa chọn cho http://adkientruc.com/san-pham/noi-that/ nội thất The Clarence rất phong phú, từ màu đỏ thẫm tới xanh lam, từ màu thạch anh tím tới màu vàng quý phái và màu nâu choocolate. http://adkientruc.com/wp-content/uploads/2012/09/691344.jpeg 3. Khu nghỉ dưỡng Mission Ranch (Clint Eastwood ) Đạo diễn tài ba Clint Eastwood đã cải tạo trang trại có từ thập niên 80 của mình ở Carmel (bang California) trở thành “một trải nghiệm về thiên đường nghỉ dưỡng độc đáo”. Khu này có 31 phòng với 10 ngôi nhà tách biệt trong khu tổ hợp rộng gần 9 ha. Từ khu nghỉ dưỡng này, khách có thể chiêm ngưỡng vẻ đẹp của Khu bảo tồn tự nhiên quốc gia Mỹ Point Lobos, Bãi biển Carmel River và Thái Bình Dương. Trong lúc thưởng thức bữa tối tại nhà hàng khách sạn, bạn có thể thảnh thơi ngắm cảnh đàn cừu đang gặm cỏ trong ráng chiều thơ mộng. http://adkientruc.com/wp-content/uploads/2012/09/691345.jpeg 4. Khách sạn Cardozo (Gloria Estefan ) Nữ ca sĩ Gloria Estefan và ông xã Emilio – nhà sản xuất từng giành giải Oscar – là chủ sở hữu khách sạn Cardozo gần bãi biển Miami (Florida). Khách sạn có 43 phòng thường và 4 phòng VIP. Ấn tượng nổi bật nhất về Cardozo chính là sự hài hòa giữa các nền văn hóa khác nhau. Bên cạnh đó, cặp đôi này còn sở hữu một bất động sản khác ở Bãi biển Vero, bang Florida. http://adkientruc.com/wp-content/uploads/2012/09/691346.jpeg 5. Khách sạn Greenwich (Robert De Niro ) Đây là khách sạn cao cấp gồm 88 phòng, tọa lạc tại khu thương mại TriBeCa sầm uất ở trung tâm Manhattan do nam diễn viên kỳ cựu Robert De Niro làm chủ. Bể bơi và spa chính là hai điểm nổi bật nhất của Greenwich. Nhà hàng mang đậm phong cách Ý, Locanda Verde, bên trong khách sạn, cũng rất đáng để bạn thử nếu ghé thăm nơi đây. http://adkientruc.com/wp-content/uploads/2012/09/691347.jpeg 6. Khách sạn The Rival (Benny Anderson) Gồm 99 phòng, The Rival là khách sạn cao cấp đầu tiên tại Stockholm – Thụy Điển. Chủ sở hữu của nó là giọng ca Benny Anderson trong ban nhạc huyền thoại ABBA. Bên cạnh thiết kế cực kỳ cá tính và hiện đại, The Rival còn nổi tiếng với chất lượng đồ ăn, đồ uống được phục vụ tại Café Rival. http://adkientruc.com/wp-content/uploads/2012/09/691348.jpeg 7. Khách sạn Cypress Inn (Doris Day ) Doris Day, nữ diễn viên kiêm ca sĩ, từng có 50 năm kinh nghiệm trong lĩnh vực giải trí, là người đồng sở hữu khách sạn Cypress suốt 20 năm qua. Gồm 44 phòng, khách sạn nằm bên bờ biển, thuộc phạm vi ngôi làng Carmel ở California. Vẻ đẹp kiểu cổ điển quyến rũ như trong tranh làm nên sức hấp dẫn của khách sạn, bên cạnh hệ thống sân golf xanh. Là một người rất yêu mến động vật nên Doris Day cho phép khách sạn Cypress Inn kinh doanh cả dịch vụ chăm sóc thú cưng của khách. Nếu bạn không muốn rời xa con vật yêu quý của mình, bạn có thể ăn tối với chúng trong nhà hàng khách sạn. http://adkientruc.com/wp-content/uploads/2012/09/691349.jpeg');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_cat`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_cat`;
CREATE TABLE `nv3_vi_kien_truc_360_cat` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `titlesite` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '',
  `thumbnail` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_kien_truc_360_cat`
--

INSERT INTO `nv3_vi_kien_truc_360_cat` VALUES
(1, 0, 'Không gian sống', '', 'Khong-gian-song', '', '', '', 1, 1, 0, 'viewcat_grid_new', 0, '', 1, 3, '', '', 1352625797, 1352625797, 0, ''), 
(2, 0, 'Phong thuỷ', '', 'Phong-thuy', '', '', '', 2, 2, 0, 'viewcat_grid_new', 0, '', 1, 3, '', '', 1352625908, 1352625908, 0, ''), 
(3, 0, 'Kiến trúc lạ', '', 'Kien-truc-la', '', '', '', 3, 3, 0, 'viewcat_grid_new', 0, '', 1, 3, '', '', 1352625924, 1352625924, 0, ''), 
(4, 0, 'KTS nổi tiếng', '', 'KTS-noi-tieng', '', '', '', 4, 4, 0, 'viewcat_grid_new', 0, '', 1, 3, '', '', 1352625947, 1352625947, 0, ''), 
(5, 0, 'Công trình kiến trúc nổi tiếng', '', 'Cong-trinh-kien-truc-noi-tieng', '', '', '', 5, 5, 0, 'viewcat_grid_new', 0, '', 1, 3, '', '', 1352625976, 1352625976, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_comments`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_comments`;
CREATE TABLE `nv3_vi_kien_truc_360_comments` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `post_time` (`post_time`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_config_post`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_config_post`;
CREATE TABLE `nv3_vi_kien_truc_360_config_post` (
  `pid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `member` tinyint(4) NOT NULL,
  `group_id` mediumint(9) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `member` (`member`,`group_id`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_kien_truc_360_config_post`
--

INSERT INTO `nv3_vi_kien_truc_360_config_post` VALUES
(1, 0, 0, 0, 0, 0, 0), 
(2, 1, 0, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_rows`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_rows`;
CREATE TABLE `nv3_vi_kien_truc_360_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_kien_truc_360_rows`
--

INSERT INTO `nv3_vi_kien_truc_360_rows` VALUES
(1, 1, '1', 0, 1, '', 0, 1352700391, 1352700391, 1, 1352700391, 0, 2, 'Không gian nhà bếp nổi bật 2012', 'Khong-gian-nha-bep-noi-bat-2012', 'Một không gian bếp đẹp “có cá tính” chính là một “nét duyên” trong ngôi nhà và có thể đem lại cho các thành viên trong gia đình cảm xúc ấm áp mỗi khi bước vào.', '2012_11/bep-xanh-tot-cho-suc-khoe-1.jpg', '', 'thumb/bep-xanh-tot-cho-suc-khoe-1.jpg|block/bep-xanh-tot-cho-suc-khoe-1.jpg', 1, 2, 1, 2, 0, 0, 0, 'không gian,cá tính,có thể,thành viên,gia đình,cảm xúc,ấm áp'), 
(2, 2, '2', 0, 1, '', 0, 1352706043, 1352706043, 1, 1352706043, 0, 2, 'Chọn cửa hàng kinh doanh theo Phong thủy', 'Chon-cua-hang-kinh-doanh-theo-Phong-thuy', 'Núi mà dương trạch tựa vào phải là núi có thế như con rồng phú quý. Sông mà nó hướng vào phải có hình uốn cong bao xung quanh. Khi chọn cửa hàng thì phải chọn thế “tựa núi hướng sông”. Đây là cách chọn lựa vị trí lý tưởng nhất trong dương trạch.', '2012_11/kinh-doanh-va-thuat-phong-thuy.jpg', '', 'thumb/kinh-doanh-va-thuat-phong-thuy.jpg|block/kinh-doanh-va-thuat-phong-thuy.jpg', 1, 2, 1, 0, 0, 0, 0, 'phú quý,cửa hàng,thì phải,vị trí,lý tưởng'), 
(3, 3, '3', 0, 1, '', 0, 1352706123, 1352706123, 1, 1352706123, 0, 2, 'Ngôi nhà nứt làm ba', 'Ngoi-nha-nut-lam-ba', 'Một ngôi nhà ở Mỹ đã khiến cho không ít người phải ngạc nhiên bởi kiến trúc quái dị của nó. Nhìn từ xa ngôi nhà bị gãy khúc giống như mới trải qua một trận động đất kinh hoàng.', '2012_11/ngoi-nha-dut-gay-doc-dao1.jpg', '', 'thumb/ngoi-nha-dut-gay-doc-dao1.jpg|block/ngoi-nha-dut-gay-doc-dao1.jpg', 1, 2, 1, 0, 0, 0, 0, 'nhà ở,ngạc nhiên,kiến trúc,quái dị,trải qua,động đất'), 
(4, 4, '4', 0, 1, '', 0, 1352706194, 1352706194, 1, 1352706194, 0, 2, 'Kiến trúc sư Ludwig Mies van der Rohe', 'Kien-truc-su-Ludwig-Mies-van-der-Rohe', 'Ludwig Mies van der Rohe (Sinh ngày 27 tháng 3 năm 1886 – mất ngày 19 tháng 8 năm 1969) là một kiến trúc sư nổi tiếng thế giới người Đức. Ông là một trong những người đặt nền móng cho sự phát triển của trào lưu Kiến trúc hiện đại của thế kỉ 20 và được xem như cha đẻ của phong cách Kiến trúc tối thiểu (Minimalism).', '2012_11/image001-749833.jpg', '', 'thumb/image001-749833.jpg|block/image001-749833.jpg', 1, 2, 1, 0, 0, 0, 0, 'kiến trúc sư,nổi tiếng,thế giới,nền móng,phát triển,trào lưu,kiến trúc,hiện đại,phong cách,tối thiểu'), 
(5, 5, '5', 0, 1, '', 0, 1352706268, 1352706268, 1, 1352706268, 0, 2, 'Điểm danh 7 khách sạn, khu nghỉ dưỡng đẹp nhất của các sao', 'Diem-danh-7-khach-san-khu-nghi-duong-dep-nhat-cua-cac-sao', 'Ờ bài viết này chúng tôi xin đưa các bạn đọc đến thăm các khách sạn sang trọng bậc nhất thế giới. Và không ai hết chủ sở hữu của các khách sạn này là các ngôi sao hàng đầu thế giới', '2012_11/691343.jpeg', '', 'thumb/691343.jpeg.jpg|block/691343.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'bạn đọc,khách sạn,sang trọng,thế giới,sở hữu,hàng đầu');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_sources`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_sources`;
CREATE TABLE `nv3_vi_kien_truc_360_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_kien_truc_360_topics`
--

DROP TABLE IF EXISTS `nv3_vi_kien_truc_360_topics`;
CREATE TABLE `nv3_vi_kien_truc_360_topics` (
  `topicid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_menu_menu`
--

DROP TABLE IF EXISTS `nv3_vi_menu_menu`;
CREATE TABLE `nv3_vi_menu_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `menu_item` mediumtext NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_menu_rows`
--

DROP TABLE IF EXISTS `nv3_vi_menu_rows`;
CREATE TABLE `nv3_vi_menu_rows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` int(11) unsigned NOT NULL,
  `mid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  `weight` int(11) NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` mediumtext NOT NULL,
  `who_view` tinyint(2) NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL,
  `module_name` varchar(255) NOT NULL DEFAULT '',
  `op` varchar(255) NOT NULL DEFAULT '',
  `target` tinyint(4) NOT NULL DEFAULT '0',
  `css` varchar(255) NOT NULL DEFAULT '',
  `active_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_modfuncs`
--

DROP TABLE IF EXISTS `nv3_vi_modfuncs`;
CREATE TABLE `nv3_vi_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55) NOT NULL,
  `func_custom_name` varchar(255) NOT NULL,
  `in_module` varchar(55) NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(2) unsigned NOT NULL DEFAULT '1',
  `setting` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`)
) ENGINE=MyISAM  AUTO_INCREMENT=219  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_modfuncs`
--

INSERT INTO `nv3_vi_modfuncs` VALUES
(1, 'Sitemap', 'Sitemap', 'about', 0, 0, 0, ''), 
(2, 'main', 'Main', 'about', 1, 0, 1, ''), 
(191, 'content', 'Content', 'kien-truc-360', 1, 0, 7, ''), 
(190, 'comment', 'Comment', 'kien-truc-360', 0, 0, 0, ''), 
(189, 'Sitemap', 'Sitemap', 'kien-truc-360', 0, 0, 0, ''), 
(188, 'viewcat', 'Viewcat', 'news', 1, 0, 2, ''), 
(187, 'topic', 'Topic', 'news', 1, 0, 3, ''), 
(186, 'sendmail', 'Sendmail', 'news', 0, 0, 0, ''), 
(185, 'search', 'Search', 'news', 1, 0, 6, ''), 
(184, 'savefile', 'Savefile', 'news', 0, 0, 0, ''), 
(183, 'rss', 'Rss', 'news', 0, 0, 0, ''), 
(17, 'active', 'Active', 'users', 1, 0, 8, ''), 
(18, 'changepass', 'Đổi mật khẩu', 'users', 1, 1, 6, ''), 
(19, 'editinfo', 'Editinfo', 'users', 1, 0, 10, ''), 
(20, 'login', 'Đăng nhập', 'users', 1, 1, 2, ''), 
(21, 'logout', 'Logout', 'users', 1, 1, 3, ''), 
(22, 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 9, ''), 
(23, 'lostpass', 'Quên mật khẩu', 'users', 1, 1, 5, ''), 
(24, 'main', 'Main', 'users', 1, 1, 1, ''), 
(25, 'openid', 'Openid', 'users', 1, 1, 7, ''), 
(26, 'register', 'Đăng ký', 'users', 1, 1, 4, ''), 
(27, 'main', 'Main', 'contact', 1, 0, 1, ''), 
(28, 'allbots', 'Máy chủ tìm kiếm', 'statistics', 1, 1, 6, ''), 
(29, 'allbrowsers', 'Theo trình duyệt', 'statistics', 1, 1, 4, ''), 
(30, 'allcountries', 'Theo quốc gia', 'statistics', 1, 1, 3, ''), 
(31, 'allos', 'Theo hệ điều hành', 'statistics', 1, 1, 5, ''), 
(32, 'allreferers', 'Theo đường dẫn đến site', 'statistics', 1, 1, 2, ''), 
(33, 'main', 'Main', 'statistics', 1, 0, 1, ''), 
(34, 'referer', 'Đường dẫn đến site theo tháng', 'statistics', 1, 0, 7, ''), 
(35, 'main', 'Main', 'voting', 1, 0, 0, ''), 
(36, 'addads', 'Addads', 'banners', 1, 0, 1, ''), 
(37, 'cledit', 'Cledit', 'banners', 0, 0, 0, ''), 
(38, 'click', 'Click', 'banners', 0, 0, 0, ''), 
(39, 'clientinfo', 'Clientinfo', 'banners', 1, 0, 2, ''), 
(40, 'clinfo', 'Clinfo', 'banners', 0, 0, 0, ''), 
(41, 'logininfo', 'Logininfo', 'banners', 0, 0, 0, ''), 
(42, 'main', 'Main', 'banners', 1, 0, 3, ''), 
(43, 'stats', 'Stats', 'banners', 1, 0, 4, ''), 
(44, 'viewmap', 'Viewmap', 'banners', 0, 0, 0, ''), 
(45, 'adv', 'Adv', 'search', 0, 0, 0, ''), 
(46, 'main', 'Main', 'search', 1, 0, 1, ''), 
(47, 'main', 'Main', 'rss', 1, 0, 1, ''), 
(48, 'regroups', 'Nhóm thành viên', 'users', 1, 0, 1, ''), 
(182, 'rating', 'Rating', 'news', 0, 0, 0, ''), 
(181, 'print', 'Print', 'news', 0, 0, 0, ''), 
(180, 'postcomment', 'Postcomment', 'news', 0, 0, 0, ''), 
(179, 'main', 'Main', 'news', 1, 0, 1, ''), 
(178, 'groups', 'Groups', 'news', 1, 0, 4, ''), 
(177, 'detail', 'Detail', 'news', 1, 0, 5, ''), 
(176, 'content', 'Content', 'news', 1, 0, 7, ''), 
(175, 'comment', 'Comment', 'news', 0, 0, 0, ''), 
(174, 'Sitemap', 'Sitemap', 'news', 0, 0, 0, ''), 
(212, 'rating', 'Rating', 'tu-van-kien-truc', 0, 0, 0, ''), 
(211, 'print', 'Print', 'tu-van-kien-truc', 0, 0, 0, ''), 
(210, 'postcomment', 'Postcomment', 'tu-van-kien-truc', 0, 0, 0, ''), 
(209, 'main', 'Main', 'tu-van-kien-truc', 1, 0, 1, ''), 
(208, 'groups', 'Groups', 'tu-van-kien-truc', 1, 0, 4, ''), 
(207, 'detail', 'Detail', 'tu-van-kien-truc', 1, 0, 5, ''), 
(206, 'content', 'Content', 'tu-van-kien-truc', 1, 0, 7, ''), 
(204, 'Sitemap', 'Sitemap', 'tu-van-kien-truc', 0, 0, 0, ''), 
(203, 'viewcat', 'Viewcat', 'kien-truc-360', 1, 0, 2, ''), 
(202, 'topic', 'Topic', 'kien-truc-360', 1, 0, 3, ''), 
(200, 'search', 'Search', 'kien-truc-360', 1, 0, 6, ''), 
(199, 'savefile', 'Savefile', 'kien-truc-360', 0, 0, 0, ''), 
(198, 'rss', 'Rss', 'kien-truc-360', 0, 0, 0, ''), 
(197, 'rating', 'Rating', 'kien-truc-360', 0, 0, 0, ''), 
(196, 'print', 'Print', 'kien-truc-360', 0, 0, 0, ''), 
(195, 'postcomment', 'Postcomment', 'kien-truc-360', 0, 0, 0, ''), 
(194, 'main', 'Main', 'kien-truc-360', 1, 0, 1, ''), 
(193, 'groups', 'Groups', 'kien-truc-360', 1, 0, 4, ''), 
(192, 'detail', 'Detail', 'kien-truc-360', 1, 0, 5, ''), 
(173, 'main', 'Main', 'home', 1, 0, 1, ''), 
(201, 'sendmail', 'Sendmail', 'kien-truc-360', 0, 0, 0, ''), 
(205, 'comment', 'Comment', 'tu-van-kien-truc', 0, 0, 0, ''), 
(213, 'rss', 'Rss', 'tu-van-kien-truc', 0, 0, 0, ''), 
(214, 'savefile', 'Savefile', 'tu-van-kien-truc', 0, 0, 0, ''), 
(215, 'search', 'Search', 'tu-van-kien-truc', 1, 0, 6, ''), 
(216, 'sendmail', 'Sendmail', 'tu-van-kien-truc', 0, 0, 0, ''), 
(217, 'topic', 'Topic', 'tu-van-kien-truc', 1, 0, 3, ''), 
(218, 'viewcat', 'Viewcat', 'tu-van-kien-truc', 1, 0, 2, '');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_modthemes`
--

DROP TABLE IF EXISTS `nv3_vi_modthemes`;
CREATE TABLE `nv3_vi_modthemes` (
  `func_id` int(11) DEFAULT NULL,
  `layout` varchar(100) DEFAULT NULL,
  `theme` varchar(100) DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_modthemes`
--

INSERT INTO `nv3_vi_modthemes` VALUES
(0, 'body', 'mobile_nukeviet'), 
(0, 'body-right', 'modern'), 
(0, 'left-body', 'noithatviet'), 
(0, 'left-body-right', 'default'), 
(0, 'left-body-right', 'phapluat2'), 
(2, 'body', 'mobile_nukeviet'), 
(2, 'body', 'modern'), 
(2, 'body', 'noithatviet'), 
(2, 'left-body-right', 'default'), 
(2, 'left-body-right', 'phapluat2'), 
(17, 'body', 'mobile_nukeviet'), 
(17, 'body-right', 'modern'), 
(17, 'body-right', 'noithatviet'), 
(17, 'left-body-right', 'default'), 
(17, 'left-body-right', 'phapluat2'), 
(18, 'body', 'mobile_nukeviet'), 
(18, 'body-right', 'modern'), 
(18, 'body-right', 'noithatviet'), 
(18, 'left-body-right', 'default'), 
(18, 'left-body-right', 'phapluat2'), 
(19, 'body', 'mobile_nukeviet'), 
(19, 'body-right', 'modern'), 
(19, 'body-right', 'noithatviet'), 
(19, 'left-body-right', 'default'), 
(19, 'left-body-right', 'phapluat2'), 
(20, 'body', 'mobile_nukeviet'), 
(20, 'body-right', 'modern'), 
(20, 'body-right', 'noithatviet'), 
(20, 'left-body-right', 'default'), 
(20, 'left-body-right', 'phapluat2'), 
(21, 'body', 'mobile_nukeviet'), 
(21, 'body-right', 'modern'), 
(21, 'body-right', 'noithatviet'), 
(21, 'left-body-right', 'default'), 
(21, 'left-body-right', 'phapluat2'), 
(22, 'body', 'mobile_nukeviet'), 
(22, 'body-right', 'modern'), 
(22, 'body-right', 'noithatviet'), 
(22, 'left-body-right', 'default'), 
(22, 'left-body-right', 'phapluat2'), 
(23, 'body', 'mobile_nukeviet'), 
(23, 'body-right', 'modern'), 
(23, 'body-right', 'noithatviet'), 
(23, 'left-body-right', 'default'), 
(23, 'left-body-right', 'phapluat2'), 
(24, 'body', 'mobile_nukeviet'), 
(24, 'body-right', 'modern'), 
(24, 'body-right', 'noithatviet'), 
(24, 'left-body-right', 'default'), 
(24, 'left-body-right', 'phapluat2'), 
(25, 'body', 'mobile_nukeviet'), 
(25, 'body-right', 'modern'), 
(25, 'body-right', 'noithatviet'), 
(25, 'left-body-right', 'default'), 
(25, 'left-body-right', 'phapluat2'), 
(26, 'body', 'mobile_nukeviet'), 
(26, 'body-right', 'modern'), 
(26, 'body-right', 'noithatviet'), 
(26, 'left-body-right', 'default'), 
(26, 'left-body-right', 'phapluat2'), 
(27, 'body', 'mobile_nukeviet'), 
(27, 'body-right', 'modern'), 
(27, 'body-right', 'noithatviet'), 
(27, 'left-body-right', 'default'), 
(27, 'left-body-right', 'phapluat2'), 
(28, 'body', 'mobile_nukeviet'), 
(28, 'body', 'modern'), 
(28, 'body', 'noithatviet'), 
(28, 'left-body', 'default'), 
(28, 'left-body', 'phapluat2'), 
(29, 'body', 'mobile_nukeviet'), 
(29, 'body', 'modern'), 
(29, 'body', 'noithatviet'), 
(29, 'left-body', 'default'), 
(29, 'left-body', 'phapluat2'), 
(30, 'body', 'mobile_nukeviet'), 
(30, 'body', 'modern'), 
(30, 'body', 'noithatviet'), 
(30, 'left-body', 'default'), 
(30, 'left-body', 'phapluat2'), 
(31, 'body', 'mobile_nukeviet'), 
(31, 'body', 'modern'), 
(31, 'body', 'noithatviet'), 
(31, 'left-body', 'default'), 
(31, 'left-body', 'phapluat2'), 
(32, 'body', 'mobile_nukeviet'), 
(32, 'body', 'modern'), 
(32, 'body', 'noithatviet'), 
(32, 'left-body', 'default'), 
(32, 'left-body', 'phapluat2'), 
(33, 'body', 'mobile_nukeviet'), 
(33, 'body', 'modern'), 
(33, 'body', 'noithatviet'), 
(33, 'left-body', 'default'), 
(33, 'left-body', 'phapluat2'), 
(34, 'body', 'mobile_nukeviet'), 
(34, 'body', 'modern'), 
(34, 'body', 'noithatviet'), 
(34, 'left-body', 'default'), 
(34, 'left-body', 'phapluat2'), 
(35, 'body', 'mobile_nukeviet'), 
(35, 'body-right', 'modern'), 
(35, 'body-right', 'noithatviet'), 
(35, 'left-body-right', 'default'), 
(35, 'left-body-right', 'phapluat2'), 
(36, 'body', 'mobile_nukeviet'), 
(36, 'body-right', 'modern'), 
(36, 'body-right', 'noithatviet'), 
(36, 'left-body-right', 'default'), 
(36, 'left-body-right', 'phapluat2'), 
(39, 'body', 'mobile_nukeviet'), 
(39, 'body-right', 'modern'), 
(39, 'body-right', 'noithatviet'), 
(39, 'left-body-right', 'default'), 
(39, 'left-body-right', 'phapluat2'), 
(42, 'body', 'mobile_nukeviet'), 
(42, 'body-right', 'modern'), 
(42, 'body-right', 'noithatviet'), 
(42, 'left-body-right', 'default'), 
(42, 'left-body-right', 'phapluat2'), 
(43, 'body', 'mobile_nukeviet'), 
(43, 'body-right', 'modern'), 
(43, 'body-right', 'noithatviet'), 
(43, 'left-body-right', 'default'), 
(43, 'left-body-right', 'phapluat2'), 
(46, 'body', 'mobile_nukeviet'), 
(46, 'body-right', 'modern'), 
(46, 'body-right', 'noithatviet'), 
(46, 'left-body-right', 'default'), 
(46, 'left-body-right', 'phapluat2'), 
(47, 'body', 'mobile_nukeviet'), 
(47, 'body', 'modern'), 
(47, 'body-right', 'noithatviet'), 
(47, 'left-body-right', 'default'), 
(47, 'left-body-right', 'phapluat2'), 
(48, 'body', 'mobile_nukeviet'), 
(48, 'body-right', 'modern'), 
(48, 'body-right', 'noithatviet'), 
(48, 'left-body-right', 'default'), 
(48, 'left-body-right', 'phapluat2'), 
(173, 'body', 'mobile_nukeviet'), 
(173, 'body-right', 'modern'), 
(173, 'left-body', 'noithatviet'), 
(173, 'left-body-right', 'default'), 
(173, 'left-body-right', 'phapluat2'), 
(176, 'body', 'mobile_nukeviet'), 
(176, 'body-right', 'modern'), 
(176, 'body-right', 'noithatviet'), 
(176, 'left-body-right', 'default'), 
(176, 'left-body-right', 'phapluat2'), 
(177, 'body', 'mobile_nukeviet'), 
(177, 'body-right', 'modern'), 
(177, 'body-right', 'noithatviet'), 
(177, 'left-body-right', 'default'), 
(177, 'left-body-right', 'phapluat2'), 
(178, 'body', 'mobile_nukeviet'), 
(178, 'body-right', 'modern'), 
(178, 'body-right', 'noithatviet'), 
(178, 'left-body-right', 'default'), 
(178, 'left-body-right', 'phapluat2'), 
(179, 'body', 'mobile_nukeviet'), 
(179, 'body-right', 'modern'), 
(179, 'body-right', 'noithatviet'), 
(179, 'left-body-right', 'default'), 
(179, 'left-body-right', 'phapluat2'), 
(185, 'body', 'mobile_nukeviet'), 
(185, 'body-right', 'modern'), 
(185, 'body-right', 'noithatviet'), 
(185, 'left-body-right', 'default'), 
(185, 'left-body-right', 'phapluat2'), 
(187, 'body', 'mobile_nukeviet'), 
(187, 'body-right', 'modern'), 
(187, 'body-right', 'noithatviet'), 
(187, 'left-body-right', 'default'), 
(187, 'left-body-right', 'phapluat2'), 
(188, 'body', 'mobile_nukeviet'), 
(188, 'body-right', 'modern'), 
(188, 'body-right', 'noithatviet'), 
(188, 'left-body-right', 'default'), 
(188, 'left-body-right', 'phapluat2'), 
(191, 'body', 'mobile_nukeviet'), 
(191, 'body-right', 'modern'), 
(191, 'body-right', 'noithatviet'), 
(191, 'left-body-right', 'default'), 
(191, 'left-body-right', 'phapluat2'), 
(192, 'body', 'mobile_nukeviet'), 
(192, 'body-right', 'modern'), 
(192, 'body-right', 'noithatviet'), 
(192, 'left-body-right', 'default'), 
(192, 'left-body-right', 'phapluat2'), 
(193, 'body', 'mobile_nukeviet'), 
(193, 'body-right', 'modern'), 
(193, 'body-right', 'noithatviet'), 
(193, 'left-body-right', 'default'), 
(193, 'left-body-right', 'phapluat2'), 
(194, 'body', 'mobile_nukeviet'), 
(194, 'body-right', 'modern'), 
(194, 'body-right', 'noithatviet'), 
(194, 'left-body-right', 'default'), 
(194, 'left-body-right', 'phapluat2'), 
(200, 'body', 'mobile_nukeviet'), 
(200, 'body-right', 'modern'), 
(200, 'body-right', 'noithatviet'), 
(200, 'left-body-right', 'default'), 
(200, 'left-body-right', 'phapluat2'), 
(202, 'body', 'mobile_nukeviet'), 
(202, 'body-right', 'modern'), 
(202, 'body-right', 'noithatviet'), 
(202, 'left-body-right', 'default'), 
(202, 'left-body-right', 'phapluat2'), 
(203, 'body', 'mobile_nukeviet'), 
(203, 'body-right', 'modern'), 
(203, 'body-right', 'noithatviet'), 
(203, 'left-body-right', 'default'), 
(203, 'left-body-right', 'phapluat2'), 
(206, 'body', 'mobile_nukeviet'), 
(206, 'body-right', 'modern'), 
(206, 'body-right', 'noithatviet'), 
(206, 'left-body-right', 'default'), 
(206, 'left-body-right', 'phapluat2'), 
(207, 'body', 'mobile_nukeviet'), 
(207, 'body-right', 'modern'), 
(207, 'body-right', 'noithatviet'), 
(207, 'left-body-right', 'default'), 
(207, 'left-body-right', 'phapluat2'), 
(208, 'body', 'mobile_nukeviet'), 
(208, 'body-right', 'modern'), 
(208, 'body-right', 'noithatviet'), 
(208, 'left-body-right', 'default'), 
(208, 'left-body-right', 'phapluat2'), 
(209, 'body', 'mobile_nukeviet'), 
(209, 'body-right', 'modern'), 
(209, 'body-right', 'noithatviet'), 
(209, 'left-body-right', 'default'), 
(209, 'left-body-right', 'phapluat2'), 
(215, 'body', 'mobile_nukeviet'), 
(215, 'body-right', 'modern'), 
(215, 'body-right', 'noithatviet'), 
(215, 'left-body-right', 'default'), 
(215, 'left-body-right', 'phapluat2'), 
(217, 'body', 'mobile_nukeviet'), 
(217, 'body-right', 'modern'), 
(217, 'body-right', 'noithatviet'), 
(217, 'left-body-right', 'default'), 
(217, 'left-body-right', 'phapluat2'), 
(218, 'body', 'mobile_nukeviet'), 
(218, 'body-right', 'modern'), 
(218, 'body-right', 'noithatviet'), 
(218, 'left-body-right', 'default'), 
(218, 'left-body-right', 'phapluat2');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_modules`
--

DROP TABLE IF EXISTS `nv3_vi_modules`;
CREATE TABLE `nv3_vi_modules` (
  `title` varchar(55) NOT NULL,
  `module_file` varchar(55) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `custom_title` varchar(255) NOT NULL,
  `admin_title` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  `main_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `keywords` mediumtext NOT NULL,
  `groups_view` varchar(255) NOT NULL,
  `in_menu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(255) NOT NULL,
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_modules`
--

INSERT INTO `nv3_vi_modules` VALUES
('about', 'about', 'about', 'Giới thiệu', '', 1276333182, 1, 1, '', 'mobile_nukeviet', '', '0', 1, 2, 1, 1, '', 0), 
('tu-van-kien-truc', 'news', 'tu_van_kien_truc', 'Tư vấn kiến trúc', '', 1352625446, 1, 1, '', '', '', '0', 1, 5, 1, 1, '', 1), 
('users', 'users', 'users', 'Thành viên', 'Tài khoản', 1274080277, 1, 1, '', 'mobile_nukeviet', '', '0', 1, 6, 1, 1, '', 0), 
('contact', 'contact', 'contact', 'Liên hệ', '', 1275351337, 1, 1, '', 'mobile_nukeviet', '', '0', 1, 7, 1, 1, '', 0), 
('statistics', 'statistics', 'statistics', 'Thống kê', '', 1276520928, 1, 0, '', 'mobile_nukeviet', 'truy cập, online, statistics', '0', 0, 8, 1, 1, '', 0), 
('voting', 'voting', 'voting', 'Thăm dò ý kiến', '', 1275315261, 1, 1, '', 'mobile_nukeviet', '', '0', 0, 9, 1, 1, '', 1), 
('banners', 'banners', 'banners', 'Quảng cáo', '', 1270400000, 1, 1, '', 'mobile_nukeviet', '', '0', 0, 10, 1, 1, '', 0), 
('search', 'search', 'search', 'Tìm kiếm', '', 1273474173, 1, 0, '', 'mobile_nukeviet', '', '0', 0, 11, 1, 1, '', 0), 
('menu', 'menu', 'menu', 'Menu Site', '', 1295287334, 0, 1, '', 'mobile_nukeviet', '', '0', 0, 12, 1, 1, '', 0), 
('rss', 'rss', 'rss', 'Sơ đồ site', '', 1279366705, 1, 1, '', 'mobile_nukeviet', '', '0', 1, 13, 10, 1, '', 0), 
('news', 'news', 'news', 'Sản phẩm', '', 1352624996, 1, 1, '', '', '', '0', 1, 3, 1, 1, '', 1), 
('home', 'home', 'home', 'Trang chủ', '', 1352384266, 1, 0, '', '', '', '0', 1, 1, 1, 1, '', 0), 
('kien-truc-360', 'news', 'kien_truc_360', 'Kiến trúc 360', '', 1352625128, 1, 1, '', '', '', '0', 1, 4, 1, 1, '', 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_1`
--

DROP TABLE IF EXISTS `nv3_vi_news_1`;
CREATE TABLE `nv3_vi_news_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_1`
--

INSERT INTO `nv3_vi_news_1` VALUES
(1, 1, '1', 0, 1, '', 0, 1352698488, 1352698488, 1, 1352698488, 0, 2, 'Một số công trình nhà đẹp mà ADKientruc đã thi công', 'Mot-so-cong-trinh-nha-dep-ma-ADKientruc-da-thi-cong', 'Dưới đây là một số công trình nhà đẹp tiêu biểu mà AD Kiến trúc đã thiết kế và thi công với phương châm mang đến cho khách hàng những thiết kế kiến trúc mang xu hướng kiến trúc đương đại, ứng dụng những thành tựu và kiến thức thiết kế của thế giới hiện đại để tạo ra những thiết kế ấn tượng và nổi bật, nhưng vẫn chú trọng đến yếu tố phong thủy. Chúng tôi quan niệm rằng, kiến trúc sinh ra là để làm cho môi trường sống con người tốt hơn và sâu sắc hơn.', '2012_11/113.jpg', '', 'thumb/113.jpg|block/113.jpg', 1, 2, 1, 1, 0, 0, 0, 'tiêu biểu,kiến trúc,thiết kế,thi công,phương châm,khách hàng,xu hướng,ứng dụng,thành tựu,kiến thức,thế giới,hiện đại,ấn tượng,nổi bật,yếu tố,phong thủy,quan niệm,sinh ra,làm cho,môi trường,sâu sắc');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_2`
--

DROP TABLE IF EXISTS `nv3_vi_news_2`;
CREATE TABLE `nv3_vi_news_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_2`
--

INSERT INTO `nv3_vi_news_2` VALUES
(2, 2, '2', 0, 1, '', 0, 1352698623, 1352698623, 1, 1352698623, 0, 2, 'Mẫu thiết kế phòng khách hiện đại – sang trọng', 'Mau-thiet-ke-phong-khach-hien-dai-sang-trong', 'Cách bài trí đơn giản, màu sắc được phối hợp khéo léo và hài hoà nhưng những mẫu phòng khách mà Kiến trúc Trang Kim giới thiệu sau đây đều toát lên vẻ sang trọng, hiện đại và độc đáo, có thể cung cấp cho các gia đình một số ý tưởng để tạo nên một không gian sống phù hợp trong tương lai.', '2012_11/phong-khach-hien-dai-sang-trong-1.jpg', '', 'thumb/phong-khach-hien-dai-sang-trong-1.jpg|block/phong-khach-hien-dai-sang-trong-1.jpg', 1, 2, 1, 0, 0, 0, 0, 'màu sắc,phối hợp,khéo léo,kiến trúc,trang kim,giới thiệu,sau đây,sang trọng,hiện đại,có thể,gia đình,ý tưởng,không gian,phù hợp');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_3`
--

DROP TABLE IF EXISTS `nv3_vi_news_3`;
CREATE TABLE `nv3_vi_news_3` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_3`
--

INSERT INTO `nv3_vi_news_3` VALUES
(3, 3, '3', 0, 1, '', 0, 1352698698, 1352698698, 1, 1352698698, 0, 2, 'Khách Sạn Mini Cao Bằng', 'Khach-San-Mini-Cao-Bang', 'Công trình: Khách sạn mini Cao Bằng\r\nChủ đầu tư: Ông Bùi Đình Việt\r\nĐịa điểm: Thị xã Cao Bằng\r\nDiện tích: 1400m2', '2012_11/124.jpg', '', 'thumb/124.jpg|block/124.jpg', 1, 2, 1, 0, 0, 0, 0, 'khách sạn,cao bằng,địa điểm,thị xã,diện tích');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_4`
--

DROP TABLE IF EXISTS `nv3_vi_news_4`;
CREATE TABLE `nv3_vi_news_4` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_4`
--

INSERT INTO `nv3_vi_news_4` VALUES
(4, 4, '4', 0, 1, '', 0, 1352698760, 1352698760, 1, 1352698760, 0, 2, 'Mẫu nhà vườn đẹp tặng bạn', 'Mau-nha-vuon-dep-tang-ban', 'Cuộc sống nơi làng quê thanh bình đã và đang là những ước mơ của bao người nơi thành thị . Một ngôi nhà vườn nhỏ đẹp thông thường diện tich sàn trên dưới 80m2 với số tầng từ 1 dến 2 tầng với 4 mặt thoáng . Công năng đầy đủ với các phòng chức năng như Phòng khách , Bếp , Phòng ăn , Vệ sinh và một số phòng ngủ nhỏ ở tầng lửng ( tầng áp mái ) hoặc tầng hai . Trong bài viết này chúng tôi chỉ giới thiệu đến bạn đọc những mẫu nhà vườn nhỏ mang tính chất là một nơi nghỉ ngơi của một gia đình trong những ngày cuối tuần hay những kỳ nghỉ trong năm .', '2012_11/139.jpg', '', 'thumb/139.jpg|block/139.jpg', 1, 2, 1, 0, 0, 0, 0, 'thanh bình,ước mơ,thành thị,thông thường,trên dưới,đầy đủ,phòng ăn,vệ sinh,giới thiệu,bạn đọc,tính chất,nghỉ ngơi,gia đình');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_5`
--

DROP TABLE IF EXISTS `nv3_vi_news_5`;
CREATE TABLE `nv3_vi_news_5` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_5`
--

INSERT INTO `nv3_vi_news_5` VALUES
(5, 5, '5', 0, 1, '', 0, 1352698831, 1352698831, 1, 1352698831, 0, 2, 'Trung tâm game giải trí', 'Trung-tam-game-giai-tri', 'Chủ đầu tư: Mr Trung\r\nĐịa điểm: Thái Nguyên\r\nDiện tích: 250m2', '2012_11/136.jpg', '', 'thumb/136.jpg|block/136.jpg', 1, 2, 1, 0, 0, 0, 0, 'địa điểm,thái nguyên,diện tích');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_6`
--

DROP TABLE IF EXISTS `nv3_vi_news_6`;
CREATE TABLE `nv3_vi_news_6` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_6`
--

INSERT INTO `nv3_vi_news_6` VALUES
(6, 6, '6', 0, 1, '', 0, 1352698890, 1352698890, 1, 1352698890, 0, 2, 'Công viên Mai Dịch', 'Cong-vien-Mai-Dich', 'Thiết kế: KTS.Ths Hoàng Minh Hiển\r\nĐịa điểm: Mai Dịch, Cầu Giấy (Hà Nội)', '2012_11/4_resize.jpg', '', 'thumb/4_resize.jpg|block/4_resize.jpg', 1, 2, 1, 0, 0, 0, 0, 'thiết kế,địa điểm,mai dịch,cầu giấy');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_admins`
--

DROP TABLE IF EXISTS `nv3_vi_news_admins`;
CREATE TABLE `nv3_vi_news_admins` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `comment` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_block`
--

DROP TABLE IF EXISTS `nv3_vi_news_block`;
CREATE TABLE `nv3_vi_news_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_block_cat`
--

DROP TABLE IF EXISTS `nv3_vi_news_block_cat`;
CREATE TABLE `nv3_vi_news_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `number` mediumint(4) NOT NULL DEFAULT '10',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_bodyhtml_1`
--

DROP TABLE IF EXISTS `nv3_vi_news_bodyhtml_1`;
CREATE TABLE `nv3_vi_news_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_bodyhtml_1`
--

INSERT INTO `nv3_vi_news_bodyhtml_1` VALUES
(1, '<h1 class=\"entry-title\" style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 20px; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> Một số công trình nhà đẹp mà ADKientruc đã thi công</h1><span style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); display: inline !important; float: none;\">﻿</span><span class=\"categories\" style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51) !important; font-size: 12px; font-weight: bold !important; font-family: Arial; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\">Chuyên mục:<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/san-pham/nha-dep/\" rel=\"category tag\" style=\"color: rgb(148, 64, 64) !important; text-decoration: initial;\" title=\"View all posts in Nhà đẹp\">Nhà đẹp</a></span><div class=\"post-info\" style=\"color: rgb(51, 51, 51); font-size: 12px; margin: 0px 0px 5px; padding: 0px; font-family: Arial; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <b style=\"font-weight: bold;\">Ngày :<span class=\"Apple-converted-space\">&nbsp;</span></b><span class=\"date time published\" style=\"margin: 0px; padding: 0px;\" title=\"2011-07-05T16:35:37+0000\">05/07/2011</span></div><div class=\"entry-content\" style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> <strong>Dưới đây là một số công trình<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/san-pham/nha-dep/\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\" title=\"nhà đẹp\">nhà đẹp</a><span class=\"Apple-converted-space\">&nbsp;</span>tiêu biểu mà AD Kiến trúc đã thiết kế và thi công với phương châm mang đến cho khách hàng những<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/tag/tu-van-thiet-ke-kien-truc/\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\" title=\"thiết kế kiến trúc\">thiết kế kiến trúc</a><span class=\"Apple-converted-space\">&nbsp;</span>mang xu hướng kiến trúc đương đại, ứng dụng những thành tựu và kiến thức thiết kế của thế giới hiện đại để tạo ra những thiết kế ấn tượng và nổi bật, nhưng vẫn chú trọng đến yếu tố<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/kien-truc-360/phong-thuy/\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\" title=\"phong thủy\">phong thủy</a>. Chúng tôi quan niệm rằng, kiến trúc sinh ra là để làm cho môi trường sống con người tốt hơn và sâu sắc hơn.</strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Kiến trúc sư là người thổi hồn vào căn nhà, tạo dựng không gian sống phù hợp với văn hoá từng gia đình, thiết lập cách ứng xử của con người trong công trình. Kiến trúc sư tư vấn có trách nhiệm chia sẻ các bài toán nhu cầu của chủ nhà, phối hợp tìm các giải pháp hiệu quả; đồng thời chịu một phần trách nhiệm trong việc giám sát thi công.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Dưới đây là một số công trình nhà đẹp tiêu biểu mà AD Kiến trúc đã thiết kế và thi công:</p> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> Kiến trúc nhà biệt thự đẹp Anh Việt – Cao Bằng</h2> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> &nbsp;</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"Kiến trúc biệt thự vườn Anh Việt\" class=\"aligncenter\" height=\"386\" src=\"http://adkientruc.com/wp-content/uploads/2011/01/image0011.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"445\" /></strong></p> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> Kiến trúc biệt thự đẹp Mr. Thủy Lưu – Vĩnh Yên</h2> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> &nbsp;</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"Kiến trúc biệt thự Mr.Thủy Lưu \" class=\"aligncenter\" height=\"356\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/113.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"446\" /></strong></p> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> Biệt thự đẹp anh Hùng – Cao Bằng</h2> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> &nbsp;</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"Kiến trúc biệt thự anh Hùng \" class=\"aligncenter\" height=\"327\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/11.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"451\" /></strong></p> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> Nhà ống đẹp – Anh Như (Hà Nội)</h2> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> &nbsp;</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"Nhà anh Như \" class=\"aligncenter\" height=\"584\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/13.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"420\" /></strong></p> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> Kiến trúc nhà ở đẹp – Anh Vinh (Hà Nội)</h2> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> &nbsp;</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"Kiến trúc nhà ở anh Vinh \" class=\"aligncenter\" height=\"520\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/14.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"419\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Chúng tôi quan niệm rằng, mỗi công trình của khách hàng là tâm huyết, công sức, kỳ vọng của cả đời họ, gia đình họ. Vì vậy, phương châm hoạt động của chúng tôi là: Mọi khách hàng tìm đến ADkientruc đều bình đẳng và công trình của họ xứng đáng được chăm chút như nhau với tiêu chí tạo ra các không gian sống, giải trí, làm việc thoải mái, sang trọng và tiện nghi.</p></div>', '', 1, 0, 1, 1, 1), 
(2, '<h1 class=\"entry-title\" style=\"color: rgb(51, 51, 51); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 20px; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> Mẫu thiết kế phòng khách hiện đại – sang trọng</h1><span style=\"color: rgb(51, 51, 51); font-family: Arial, Tahoma, Verdana; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); display: inline !important; float: none;\">﻿</span><div class=\"post-category\" style=\"font-weight: bold; margin-bottom: 10px; color: rgb(51, 51, 51); font-family: Arial, Tahoma, Verdana; font-size: 12px; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <span class=\"categories\" style=\"margin: 0px; padding: 0px;\">Chuyên mục:<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://kientructrangkim.com/tin/tin-tuc-trang-kim/\" rel=\"category tag\" style=\"color: rgb(0, 93, 137); text-decoration: initial;\" title=\"Hiển thị toàn bộ bài viết trong Tin tức Trang Kim\">Tin tức Trang Kim</a></span></div><div class=\"entry-content\" style=\"color: rgb(51, 51, 51); font-family: Arial, Tahoma, Verdana; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <p style=\"margin: 0px; padding: 0px 0px 15px; text-align: justify;\"> <strong>Cách bài trí đơn giản, màu sắc được phối hợp khéo léo và hài hoà nhưng những mẫu phòng khách mà Kiến trúc Trang Kim giới thiệu sau đây đều toát lên vẻ sang trọng, hiện đại và độc đáo, có thể cung cấp cho các gia đình một số ý tưởng để tạo nên một không gian sống phù hợp trong tương lai.</strong></p> <p style=\"margin: 0px; padding: 0px 0px 15px; text-align: justify;\"> <a href=\"http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-1.jpg\" style=\"color: rgb(0, 93, 137); text-decoration: initial;\" target=\"_blank\"><img alt=\"phong-khach-hien-dai-sang-trong-1 Mẫu thiết kế phòng khách hiện đại - sang trọng\" class=\"aligncenter size-full wp-image-5883\" height=\"329\" src=\"http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-1.jpg\" style=\"border-style: solid; border-width: 10px 6px; border-color: rgb(236, 236, 236); display: block; margin: 0px auto 10px; max-width: 504px; padding: 3px; background-color: rgb(255, 255, 255); background-position: initial initial; background-repeat: initial initial;\" title=\"Mẫu thiết kế phòng khách hiện đại - sang trọng\" width=\"530\" /></a>Lấy tông trắng làm chủ đạo cho toàn bộ căn phòng để tạo không gian rộng và sáng, tuy nhiên nếu chỉ một gam màu này sẽ khiến phòng khách mờ nhạt nên KTS đã khéo léo tận dụng từng chi tiết nhỏ để làm điểm nhấn như bức tranh, lam chắn giữa phòng khách và bếp ăn,<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://kientructrangkim.com/tag/thiet-ke-tieu-canh\" style=\"color: rgb(0, 93, 137); text-decoration: initial;\" title=\"tiểu cảnh\">tiểu cảnh</a>, hình khối mảng tường ti vi, trần nhà….để không gian thêm sinh động, cuốn hút những vị khách đã một lần ghé qua.</p> <p style=\"margin: 0px; padding: 0px 0px 15px; text-align: justify;\"> <img alt=\"phong-khach-hien-dai-sang-trong-2 Mẫu thiết kế phòng khách hiện đại - sang trọng\" class=\"aligncenter size-full wp-image-5884\" height=\"371\" src=\"http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-2.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 504px; padding: 3px; background-color: rgb(255, 255, 255); border-width: 10px 6px; border-style: solid; border-color: rgb(236, 236, 236); background-position: initial initial; background-repeat: initial initial;\" title=\"Mẫu thiết kế phòng khách hiện đại - sang trọng\" width=\"530\" />Nếu bạn đang tìm kiếm một ý tưởng mới cho không gian phòng khách thì mẫu thiết kế trên đây sẽ là một trong những ý tưởng tuyệt vời nhất. Màu sắc,<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://kientructrangkim.com/tin/noi-that-nha-dep/\" style=\"color: rgb(0, 93, 137); text-decoration: initial;\" target=\"_blank\" title=\"nội thất\">nội thất</a><span class=\"Apple-converted-space\">&nbsp;</span>kết hợp hài hoà đến từng chi tiết.</p> <p style=\"margin: 0px; padding: 0px 0px 15px; text-align: justify;\"> <img alt=\"phong-khach-hien-dai-sang-trong-3 Mẫu thiết kế phòng khách hiện đại - sang trọng\" class=\"aligncenter size-full wp-image-5885\" height=\"353\" src=\"http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-3.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 504px; padding: 3px; background-color: rgb(255, 255, 255); border-width: 10px 6px; border-style: solid; border-color: rgb(236, 236, 236); background-position: initial initial; background-repeat: initial initial;\" title=\"Mẫu thiết kế phòng khách hiện đại - sang trọng\" width=\"530\" />Phòng khách trên đây sử dụng thạch cao và giấy dán tường để tạo hình khiến không gian có nét hiện đại, trẻ trung và khá độc đáo.</p> <p style=\"margin: 0px; padding: 0px 0px 15px; text-align: justify;\"> <img alt=\"phong-khach-hien-dai-sang-trong-4 Mẫu thiết kế phòng khách hiện đại - sang trọng\" class=\"aligncenter size-full wp-image-5886\" height=\"353\" src=\"http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-4.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 504px; padding: 3px; background-color: rgb(255, 255, 255); border-width: 10px 6px; border-style: solid; border-color: rgb(236, 236, 236); background-position: initial initial; background-repeat: initial initial;\" title=\"Mẫu thiết kế phòng khách hiện đại - sang trọng\" width=\"530\" /></p> <p style=\"margin: 0px; padding: 0px 0px 15px; text-align: justify;\"> <img alt=\"phong-khach-hien-dai-sang-trong-5 Mẫu thiết kế phòng khách hiện đại - sang trọng\" class=\"aligncenter size-full wp-image-5887\" height=\"371\" src=\"http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-5.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 504px; padding: 3px; background-color: rgb(255, 255, 255); border-width: 10px 6px; border-style: solid; border-color: rgb(236, 236, 236); background-position: initial initial; background-repeat: initial initial;\" title=\"Mẫu thiết kế phòng khách hiện đại - sang trọng\" width=\"530\" />Một góc khác của phòng khách</p> <p style=\"margin: 0px; padding: 0px 0px 15px; text-align: justify;\"> <img alt=\"phong-khach-hien-dai-sang-trong-6 Mẫu thiết kế phòng khách hiện đại - sang trọng\" class=\"aligncenter size-full wp-image-5888\" height=\"398\" src=\"http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-6.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 504px; padding: 3px; background-color: rgb(255, 255, 255); border-width: 10px 6px; border-style: solid; border-color: rgb(236, 236, 236); background-position: initial initial; background-repeat: initial initial;\" title=\"Mẫu thiết kế phòng khách hiện đại - sang trọng\" width=\"530\" />Hoa văn nổi của giấy dán tường, màu vàng tươi giúp căn phòng nổi bật và trông có vẻ tự nhiên, cá tính.</p> <p style=\"margin: 0px; padding: 0px 0px 15px; text-align: justify;\"> <img alt=\"phong-khach-hien-dai-sang-trong-7 Mẫu thiết kế phòng khách hiện đại - sang trọng\" class=\"aligncenter size-full wp-image-5889\" height=\"398\" src=\"http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-7.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 504px; padding: 3px; background-color: rgb(255, 255, 255); border-width: 10px 6px; border-style: solid; border-color: rgb(236, 236, 236); background-position: initial initial; background-repeat: initial initial;\" title=\"Mẫu thiết kế phòng khách hiện đại - sang trọng\" width=\"530\" />Phòng khách và ăn liên thông với nhau.</p> <p style=\"margin: 0px; padding: 0px 0px 15px; text-align: justify;\"> <img alt=\"phong-khach-hien-dai-sang-trong-8 Mẫu thiết kế phòng khách hiện đại - sang trọng\" class=\"aligncenter size-full wp-image-5890\" height=\"369\" src=\"http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-8.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 504px; padding: 3px; background-color: rgb(255, 255, 255); border-width: 10px 6px; border-style: solid; border-color: rgb(236, 236, 236); background-position: initial initial; background-repeat: initial initial;\" title=\"Mẫu thiết kế phòng khách hiện đại - sang trọng\" width=\"530\" />Không gian sang trọng sử dụng các lam gỗ với mục đích trang trí.</p></div>', '', 1, 0, 1, 1, 1), 
(3, '<h1 class=\"entry-title\" style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 20px; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> Khách Sạn Mini Cao Bằng</h1><span style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); display: inline !important; float: none;\">﻿</span><span class=\"categories\" style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51) !important; font-size: 12px; font-weight: bold !important; font-family: Arial; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\">Chuyên mục:<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/san-pham/nha-cao-tang/\" rel=\"category tag\" style=\"color: rgb(148, 64, 64) !important; text-decoration: initial;\" title=\"View all posts in Nhà cao tầng\">Nhà cao tầng</a>,<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/san-pham/\" rel=\"category tag\" style=\"color: rgb(148, 64, 64) !important; text-decoration: initial;\" title=\"View all posts in Sản phẩm\">Sản phẩm</a></span><div class=\"post-info\" style=\"color: rgb(51, 51, 51); font-size: 12px; margin: 0px 0px 5px; padding: 0px; font-family: Arial; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <b style=\"font-weight: bold;\">Ngày :<span class=\"Apple-converted-space\">&nbsp;</span></b><span class=\"date time published\" style=\"margin: 0px; padding: 0px;\" title=\"2010-12-01T05:04:31+0000\">01/12/2010</span></div><div class=\"entry-content\" style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> <strong>Công trình: Khách sạn mini Cao Bằng<br  /> Chủ đầu tư: Ông Bùi Đình Việt<br  /> Địa điểm: Thị xã Cao Bằng<br  /> Diện tích: 1400m2</strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1438\" height=\"508\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/124.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"387\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <em><strong>Phối cảnh trên cao</strong></em></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <em><strong><img alt=\"\" class=\"aligncenter size-full wp-image-1439\" height=\"426\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/219.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"548\" /></strong></em></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <em><strong>Phối cảnh hoàng hôn</strong></em></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <em><strong><img alt=\"\" class=\"aligncenter size-full wp-image-1440\" height=\"430\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/315.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"562\" /></strong></em></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <em><strong>Phối cảnh tổng thể</strong></em></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <em><strong><img alt=\"\" class=\"aligncenter size-full wp-image-1441\" height=\"441\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/49.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"576\" /></strong></em></p></div><br class=\"Apple-interchange-newline\" />', '', 1, 0, 1, 1, 1), 
(4, '<h1 class=\"entry-title\" style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 20px; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> Mẫu nhà vườn đẹp tặng bạn</h1><span style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); display: inline !important; float: none;\">﻿</span><span class=\"categories\" style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51) !important; font-size: 12px; font-weight: bold !important; font-family: Arial; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\">Chuyên mục:<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/san-pham/nha-vuon-resort/\" rel=\"category tag\" style=\"color: rgb(148, 64, 64) !important; text-decoration: initial;\" title=\"View all posts in Nhà vườn - Resort\">Nhà vườn - Resort</a></span><div class=\"post-info\" style=\"color: rgb(51, 51, 51); font-size: 12px; margin: 0px 0px 5px; padding: 0px; font-family: Arial; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <b style=\"font-weight: bold;\">Ngày :<span class=\"Apple-converted-space\">&nbsp;</span></b><span class=\"date time published\" style=\"margin: 0px; padding: 0px;\" title=\"2010-12-01T08:22:59+0000\">01/12/2010</span></div><div class=\"entry-content\" style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> <strong>Một số hình ảnh mẫu nhà vườn đẹp mới cập nhật được nhiều người lựa chọn</strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Cuộc sống nơi làng quê thanh bình đã và đang là những ước mơ của bao người nơi thành thị . Một ngôi nhà vườn nhỏ đẹp thông thường diện tich sàn trên dưới 80m2 với số tầng từ 1 dến 2 tầng với 4 mặt thoáng . Công năng đầy đủ với các phòng chức năng như Phòng khách , Bếp , Phòng ăn , Vệ sinh và một số phòng ngủ nhỏ ở tầng lửng ( tầng áp mái ) hoặc tầng hai . Trong bài viết này chúng tôi chỉ giới thiệu đến bạn đọc những mẫu nhà vườn nhỏ mang tính chất là một nơi nghỉ ngơi của một gia đình trong những ngày cuối tuần hay những kỳ nghỉ trong năm .</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1771\" height=\"316\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/139.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"400\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1772\" height=\"288\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/227.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"400\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1773\" height=\"288\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/326.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"400\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1774\" height=\"254\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/417.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"400\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1775\" height=\"210\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/512.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"400\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1776\" height=\"271\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/67.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"400\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1777\" height=\"288\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/75.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"400\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1778\" height=\"213\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/81.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"400\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1779\" height=\"284\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/91.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"400\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1780\" height=\"212\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/10.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"400\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1781\" height=\"240\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/1110.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"400\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1782\" height=\"198\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/1211.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"400\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1786\" height=\"248\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/1310.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"400\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1789\" height=\"190\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/142.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"400\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1790\" height=\"177\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/151.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"400\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Chúng tôi quan niệm rằng, mỗi công trình của khách hàng là tâm huyết, công sức, kỳ vọng của cả đời họ, gia đình họ. Vì vậy, phương châm hoạt động của chúng tôi là: Mọi khách hàng tìm đến<span class=\"Apple-converted-space\">&nbsp;</span><strong>ADkientruc</strong><span class=\"Apple-converted-space\">&nbsp;</span>đều bình đẳng và công trình của họ xứng đáng được chăm chút như nhau với tiêu chí tạo ra các không gian sống, giải trí, làm việc thoải mái, sang trọng và tiện nghi.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> <em><strong>Hãy<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/lien-he/\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\">Liên hệ</a><span class=\"Apple-converted-space\">&nbsp;</span>với chúng tôi để nhận được những tư vấn tốt nhất!</strong></em></p></div>', '', 1, 0, 1, 1, 1), 
(5, '<h1 class=\"entry-title\" style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 20px; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> Trung tâm game giải trí</h1><span style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); display: inline !important; float: none;\">﻿</span><span class=\"categories\" style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51) !important; font-size: 12px; font-weight: bold !important; font-family: Arial; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\">Chuyên mục:<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/san-pham/cong-trinh-cong-cong/\" rel=\"category tag\" style=\"color: rgb(148, 64, 64) !important; text-decoration: initial;\" title=\"View all posts in Công trình công cộng\">Công trình công cộng</a>,<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/san-pham/\" rel=\"category tag\" style=\"color: rgb(148, 64, 64) !important; text-decoration: initial;\" title=\"View all posts in Sản phẩm\">Sản phẩm</a></span><div class=\"post-info\" style=\"color: rgb(51, 51, 51); font-size: 12px; margin: 0px 0px 5px; padding: 0px; font-family: Arial; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <b style=\"font-weight: bold;\">Ngày :<span class=\"Apple-converted-space\">&nbsp;</span></b><span class=\"date time published\" style=\"margin: 0px; padding: 0px;\" title=\"2010-12-01T07:46:53+0000\">01/12/2010</span></div><div class=\"entry-content\" style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> <strong>Chủ đầu tư: Mr Trung<br  /> Địa điểm: Thái Nguyên<br  /> Diện tích: 250m2</strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1677\" height=\"375\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/136.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"500\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1678\" height=\"323\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/225.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"500\" /></strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <strong><img alt=\"\" class=\"aligncenter size-full wp-image-1679\" height=\"323\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/322.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"500\" /></strong></p></div>', '', 1, 0, 1, 1, 1), 
(6, '<h1 class=\"entry-title\" style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 20px; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> Công viên Mai Dịch</h1><span style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); display: inline !important; float: none;\">﻿</span><span class=\"categories\" style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51) !important; font-size: 12px; font-weight: bold !important; font-family: Arial; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\">Chuyên mục:<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/san-pham/quy-hoach-du-an/\" rel=\"category tag\" style=\"color: rgb(148, 64, 64) !important; text-decoration: initial;\" title=\"View all posts in Quy hoạch - Dự án\">Quy hoạch - Dự án</a></span><div class=\"post-info\" style=\"color: rgb(51, 51, 51); font-size: 12px; margin: 0px 0px 5px; padding: 0px; font-family: Arial; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <b style=\"font-weight: bold;\">Ngày :<span class=\"Apple-converted-space\">&nbsp;</span></b><span class=\"date time published\" style=\"margin: 0px; padding: 0px;\" title=\"2010-12-01T07:56:29+0000\">01/12/2010</span></div><div class=\"entry-content\" style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> <strong>Thiết kế: KTS.Ths Hoàng Minh Hiển<br  /> Địa điểm: Mai Dịch, Cầu Giấy (Hà Nội)</strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <img alt=\"\" border=\"0\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/4_resize.jpg\" style=\"max-width: 100%;\" /><br  /> <em><strong>Một góc công viên</strong></em></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <img alt=\"\" class=\"aligncenter size-full wp-image-1699\" height=\"236\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/137.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"537\" /></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <em><strong>Nhà điều hành</strong></em></p></div>', '', 1, 0, 1, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_bodytext`
--

DROP TABLE IF EXISTS `nv3_vi_news_bodytext`;
CREATE TABLE `nv3_vi_news_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_bodytext`
--

INSERT INTO `nv3_vi_news_bodytext` VALUES
(1, ' Một số công trình nhà đẹp mà ADKientruc đã thi công﻿Chuyên mục: http://adkientruc.com/san-pham/nha-dep/ Nhà đẹp Ngày : 05/07/2011 Dưới đây là một số công trình http://adkientruc.com/san-pham/nha-dep/ nhà đẹp tiêu biểu mà AD Kiến trúc đã thiết kế và thi công với phương châm mang đến cho khách hàng những http://adkientruc.com/tag/tu-van-thiet-ke-kien-truc/ thiết kế kiến trúc mang xu hướng kiến trúc đương đại, ứng dụng những thành tựu và kiến thức thiết kế của thế giới hiện đại để tạo ra những thiết kế ấn tượng và nổi bật, nhưng vẫn chú trọng đến yếu tố http://adkientruc.com/kien-truc-360/phong-thuy/ phong thủy. Chúng tôi quan niệm rằng, kiến trúc sinh ra là để làm cho môi trường sống con người tốt hơn và sâu sắc hơn. Kiến trúc sư là người thổi hồn vào căn nhà, tạo dựng không gian sống phù hợp với văn hoá từng gia đình, thiết lập cách ứng xử của con người trong công trình. Kiến trúc sư tư vấn có trách nhiệm chia sẻ các bài toán nhu cầu của chủ nhà, phối hợp tìm các giải pháp hiệu quả; đồng thời chịu một phần trách nhiệm trong việc giám sát thi công. Dưới đây là một số công trình nhà đẹp tiêu biểu mà AD Kiến trúc đã thiết kế và thi công: Kiến trúc nhà biệt thự đẹp Anh Việt – Cao Bằng http://adkientruc.com/wp-content/uploads/2011/01/image0011.jpg Kiến trúc biệt thự vườn Anh Việt Kiến trúc biệt thự đẹp Mr. Thủy Lưu – Vĩnh Yên http://adkientruc.com/wp-content/uploads/2010/12/113.jpg Kiến trúc biệt thự Mr.Thủy Lưu Biệt thự đẹp anh Hùng – Cao Bằng http://adkientruc.com/wp-content/uploads/2010/12/11.jpg Kiến trúc biệt thự anh Hùng Nhà ống đẹp – Anh Như (Hà Nội) http://adkientruc.com/wp-content/uploads/2010/12/13.jpg Nhà anh Như Kiến trúc nhà ở đẹp – Anh Vinh (Hà Nội) http://adkientruc.com/wp-content/uploads/2010/12/14.jpg Kiến trúc nhà ở anh Vinh Chúng tôi quan niệm rằng, mỗi công trình của khách hàng là tâm huyết, công sức, kỳ vọng của cả đời họ, gia đình họ. Vì vậy, phương châm hoạt động của chúng tôi là: Mọi khách hàng tìm đến ADkientruc đều bình đẳng và công trình của họ xứng đáng được chăm chút như nhau với tiêu chí tạo ra các không gian sống, giải trí, làm việc thoải mái, sang trọng và tiện nghi.'), 
(2, ' Mẫu thiết kế phòng khách hiện đại – sang trọng﻿ Chuyên mục: http://kientructrangkim.com/tin/tin-tuc-trang-kim/ Tin tức Trang Kim Cách bài trí đơn giản, màu sắc được phối hợp khéo léo và hài hoà nhưng những mẫu phòng khách mà Kiến trúc Trang Kim giới thiệu sau đây đều toát lên vẻ sang trọng, hiện đại và độc đáo, có thể cung cấp cho các gia đình một số ý tưởng để tạo nên một không gian sống phù hợp trong tương lai. http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-1.jpg http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-1.jpg phong-khach-hien-dai-sang-trong-1 Mẫu thiết kế phòng khách hiện đại - sang trọngLấy tông trắng làm chủ đạo cho toàn bộ căn phòng để tạo không gian rộng và sáng, tuy nhiên nếu chỉ một gam màu này sẽ khiến phòng khách mờ nhạt nên KTS đã khéo léo tận dụng từng chi tiết nhỏ để làm điểm nhấn như bức tranh, lam chắn giữa phòng khách và bếp ăn, http://kientructrangkim.com/tag/thiet-ke-tieu-canh tiểu cảnh, hình khối mảng tường ti vi, trần nhà….để không gian thêm sinh động, cuốn hút những vị khách đã một lần ghé qua. http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-2.jpg phong-khach-hien-dai-sang-trong-2 Mẫu thiết kế phòng khách hiện đại - sang trọngNếu bạn đang tìm kiếm một ý tưởng mới cho không gian phòng khách thì mẫu thiết kế trên đây sẽ là một trong những ý tưởng tuyệt vời nhất. Màu sắc, http://kientructrangkim.com/tin/noi-that-nha-dep/ nội thất kết hợp hài hoà đến từng chi tiết. http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-3.jpg phong-khach-hien-dai-sang-trong-3 Mẫu thiết kế phòng khách hiện đại - sang trọngPhòng khách trên đây sử dụng thạch cao và giấy dán tường để tạo hình khiến không gian có nét hiện đại, trẻ trung và khá độc đáo. http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-4.jpg phong-khach-hien-dai-sang-trong-4 Mẫu thiết kế phòng khách hiện đại - sang trọng http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-5.jpg phong-khach-hien-dai-sang-trong-5 Mẫu thiết kế phòng khách hiện đại - sang trọngMột góc khác của phòng khách http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-6.jpg phong-khach-hien-dai-sang-trong-6 Mẫu thiết kế phòng khách hiện đại - sang trọngHoa văn nổi của giấy dán tường, màu vàng tươi giúp căn phòng nổi bật và trông có vẻ tự nhiên, cá tính. http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-7.jpg phong-khach-hien-dai-sang-trong-7 Mẫu thiết kế phòng khách hiện đại - sang trọngPhòng khách và ăn liên thông với nhau. http://kientructrangkim.com/wp-content/uploads/2011/07/phong-khach-hien-dai-sang-trong-8.jpg phong-khach-hien-dai-sang-trong-8 Mẫu thiết kế phòng khách hiện đại - sang trọngKhông gian sang trọng sử dụng các lam gỗ với mục đích trang trí.'), 
(3, ' Khách Sạn Mini Cao Bằng﻿Chuyên mục: http://adkientruc.com/san-pham/nha-cao-tang/ Nhà cao tầng, http://adkientruc.com/san-pham/ Sản phẩm Ngày : 01/12/2010 Công trình: Khách sạn mini Cao Bằng Chủ đầu tư: Ông Bùi Đình Việt Địa điểm: Thị xã Cao Bằng Diện tích: 1400m2 http://adkientruc.com/wp-content/uploads/2010/12/124.jpg Phối cảnh trên cao http://adkientruc.com/wp-content/uploads/2010/12/219.jpg Phối cảnh hoàng hôn http://adkientruc.com/wp-content/uploads/2010/12/315.jpg Phối cảnh tổng thể http://adkientruc.com/wp-content/uploads/2010/12/49.jpg'), 
(4, ' Mẫu nhà vườn đẹp tặng bạn﻿Chuyên mục: http://adkientruc.com/san-pham/nha-vuon-resort/ Nhà vườn - Resort Ngày : 01/12/2010 Một số hình ảnh mẫu nhà vườn đẹp mới cập nhật được nhiều người lựa chọn Cuộc sống nơi làng quê thanh bình đã và đang là những ước mơ của bao người nơi thành thị . Một ngôi nhà vườn nhỏ đẹp thông thường diện tich sàn trên dưới 80m2 với số tầng từ 1 dến 2 tầng với 4 mặt thoáng . Công năng đầy đủ với các phòng chức năng như Phòng khách , Bếp , Phòng ăn , Vệ sinh và một số phòng ngủ nhỏ ở tầng lửng ( tầng áp mái ) hoặc tầng hai . Trong bài viết này chúng tôi chỉ giới thiệu đến bạn đọc những mẫu nhà vườn nhỏ mang tính chất là một nơi nghỉ ngơi của một gia đình trong những ngày cuối tuần hay những kỳ nghỉ trong năm . http://adkientruc.com/wp-content/uploads/2010/12/139.jpg http://adkientruc.com/wp-content/uploads/2010/12/227.jpg http://adkientruc.com/wp-content/uploads/2010/12/326.jpg http://adkientruc.com/wp-content/uploads/2010/12/417.jpg http://adkientruc.com/wp-content/uploads/2010/12/512.jpg http://adkientruc.com/wp-content/uploads/2010/12/67.jpg http://adkientruc.com/wp-content/uploads/2010/12/75.jpg http://adkientruc.com/wp-content/uploads/2010/12/81.jpg http://adkientruc.com/wp-content/uploads/2010/12/91.jpg http://adkientruc.com/wp-content/uploads/2010/12/10.jpg http://adkientruc.com/wp-content/uploads/2010/12/1110.jpg http://adkientruc.com/wp-content/uploads/2010/12/1211.jpg http://adkientruc.com/wp-content/uploads/2010/12/1310.jpg http://adkientruc.com/wp-content/uploads/2010/12/142.jpg http://adkientruc.com/wp-content/uploads/2010/12/151.jpg Chúng tôi quan niệm rằng, mỗi công trình của khách hàng là tâm huyết, công sức, kỳ vọng của cả đời họ, gia đình họ. Vì vậy, phương châm hoạt động của chúng tôi là: Mọi khách hàng tìm đến ADkientruc đều bình đẳng và công trình của họ xứng đáng được chăm chút như nhau với tiêu chí tạo ra các không gian sống, giải trí, làm việc thoải mái, sang trọng và tiện nghi. Hãy http://adkientruc.com/lien-he/ Liên hệ với chúng tôi để nhận được những tư vấn tốt nhất!'), 
(5, ' Trung tâm game giải trí﻿Chuyên mục: http://adkientruc.com/san-pham/cong-trinh-cong-cong/ Công trình công cộng, http://adkientruc.com/san-pham/ Sản phẩm Ngày : 01/12/2010 Chủ đầu tư: Mr Trung Địa điểm: Thái Nguyên Diện tích: 250m2 http://adkientruc.com/wp-content/uploads/2010/12/136.jpg http://adkientruc.com/wp-content/uploads/2010/12/225.jpg http://adkientruc.com/wp-content/uploads/2010/12/322.jpg'), 
(6, ' Công viên Mai Dịch﻿Chuyên mục: http://adkientruc.com/san-pham/quy-hoach-du-an/ Quy hoạch - Dự án Ngày : 01/12/2010 Thiết kế: KTS.Ths Hoàng Minh Hiển Địa điểm: Mai Dịch, Cầu Giấy (Hà Nội) http://adkientruc.com/wp-content/uploads/2010/12/4_resize.jpg Một góc công viên http://adkientruc.com/wp-content/uploads/2010/12/137.jpg Nhà điều hành');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_cat`
--

DROP TABLE IF EXISTS `nv3_vi_news_cat`;
CREATE TABLE `nv3_vi_news_cat` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `titlesite` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '',
  `thumbnail` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_cat`
--

INSERT INTO `nv3_vi_news_cat` VALUES
(1, 0, 'Nhà ở', '', 'Nha-o', '', '', '', 1, 1, 0, 'viewcat_grid_new', 0, '', 1, 3, '', '', 1352625619, 1352625619, 0, ''), 
(2, 0, 'Nội thất', '', 'Noi-that', '', '', '', 2, 2, 0, 'viewcat_grid_new', 0, '', 1, 3, '', '', 1352625654, 1352625654, 0, ''), 
(3, 0, 'Nhà cao tầng', '', 'Nha-cao-tang', '', '', '', 3, 3, 0, 'viewcat_grid_new', 0, '', 1, 3, '', '', 1352625671, 1352625671, 0, ''), 
(4, 0, 'Nhà vườn - resort', '', 'Nha-vuon-resort', '', '', '', 4, 4, 0, 'viewcat_grid_new', 0, '', 1, 3, '', '', 1352625724, 1352625724, 0, ''), 
(5, 0, 'Công trình công cộng', '', 'Cong-trinh-cong-cong', '', '', '', 5, 5, 0, 'viewcat_grid_new', 0, '', 1, 3, '', '', 1352625748, 1352625748, 0, ''), 
(6, 0, 'Quy hoạch dự án', '', 'Quy-hoach-du-an', '', '', '', 6, 6, 0, 'viewcat_grid_new', 0, '', 1, 3, '', '', 1352625762, 1352625762, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_comments`
--

DROP TABLE IF EXISTS `nv3_vi_news_comments`;
CREATE TABLE `nv3_vi_news_comments` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `post_time` (`post_time`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_config_post`
--

DROP TABLE IF EXISTS `nv3_vi_news_config_post`;
CREATE TABLE `nv3_vi_news_config_post` (
  `pid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `member` tinyint(4) NOT NULL,
  `group_id` mediumint(9) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `member` (`member`,`group_id`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_config_post`
--

INSERT INTO `nv3_vi_news_config_post` VALUES
(1, 0, 0, 0, 0, 0, 0), 
(2, 1, 0, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_rows`
--

DROP TABLE IF EXISTS `nv3_vi_news_rows`;
CREATE TABLE `nv3_vi_news_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_rows`
--

INSERT INTO `nv3_vi_news_rows` VALUES
(1, 1, '1', 0, 1, '', 0, 1352698488, 1352698488, 1, 1352698488, 0, 2, 'Một số công trình nhà đẹp mà ADKientruc đã thi công', 'Mot-so-cong-trinh-nha-dep-ma-ADKientruc-da-thi-cong', 'Dưới đây là một số công trình nhà đẹp tiêu biểu mà AD Kiến trúc đã thiết kế và thi công với phương châm mang đến cho khách hàng những thiết kế kiến trúc mang xu hướng kiến trúc đương đại, ứng dụng những thành tựu và kiến thức thiết kế của thế giới hiện đại để tạo ra những thiết kế ấn tượng và nổi bật, nhưng vẫn chú trọng đến yếu tố phong thủy. Chúng tôi quan niệm rằng, kiến trúc sinh ra là để làm cho môi trường sống con người tốt hơn và sâu sắc hơn.', '2012_11/113.jpg', '', 'thumb/113.jpg|block/113.jpg', 1, 2, 1, 1, 0, 0, 0, 'tiêu biểu,kiến trúc,thiết kế,thi công,phương châm,khách hàng,xu hướng,ứng dụng,thành tựu,kiến thức,thế giới,hiện đại,ấn tượng,nổi bật,yếu tố,phong thủy,quan niệm,sinh ra,làm cho,môi trường,sâu sắc'), 
(2, 2, '2', 0, 1, '', 0, 1352698623, 1352698623, 1, 1352698623, 0, 2, 'Mẫu thiết kế phòng khách hiện đại – sang trọng', 'Mau-thiet-ke-phong-khach-hien-dai-sang-trong', 'Cách bài trí đơn giản, màu sắc được phối hợp khéo léo và hài hoà nhưng những mẫu phòng khách mà Kiến trúc Trang Kim giới thiệu sau đây đều toát lên vẻ sang trọng, hiện đại và độc đáo, có thể cung cấp cho các gia đình một số ý tưởng để tạo nên một không gian sống phù hợp trong tương lai.', '2012_11/phong-khach-hien-dai-sang-trong-1.jpg', '', 'thumb/phong-khach-hien-dai-sang-trong-1.jpg|block/phong-khach-hien-dai-sang-trong-1.jpg', 1, 2, 1, 0, 0, 0, 0, 'màu sắc,phối hợp,khéo léo,kiến trúc,trang kim,giới thiệu,sau đây,sang trọng,hiện đại,có thể,gia đình,ý tưởng,không gian,phù hợp'), 
(3, 3, '3', 0, 1, '', 0, 1352698698, 1352698698, 1, 1352698698, 0, 2, 'Khách Sạn Mini Cao Bằng', 'Khach-San-Mini-Cao-Bang', 'Công trình: Khách sạn mini Cao Bằng\r\nChủ đầu tư: Ông Bùi Đình Việt\r\nĐịa điểm: Thị xã Cao Bằng\r\nDiện tích: 1400m2', '2012_11/124.jpg', '', 'thumb/124.jpg|block/124.jpg', 1, 2, 1, 0, 0, 0, 0, 'khách sạn,cao bằng,địa điểm,thị xã,diện tích'), 
(4, 4, '4', 0, 1, '', 0, 1352698760, 1352698760, 1, 1352698760, 0, 2, 'Mẫu nhà vườn đẹp tặng bạn', 'Mau-nha-vuon-dep-tang-ban', 'Cuộc sống nơi làng quê thanh bình đã và đang là những ước mơ của bao người nơi thành thị . Một ngôi nhà vườn nhỏ đẹp thông thường diện tich sàn trên dưới 80m2 với số tầng từ 1 dến 2 tầng với 4 mặt thoáng . Công năng đầy đủ với các phòng chức năng như Phòng khách , Bếp , Phòng ăn , Vệ sinh và một số phòng ngủ nhỏ ở tầng lửng ( tầng áp mái ) hoặc tầng hai . Trong bài viết này chúng tôi chỉ giới thiệu đến bạn đọc những mẫu nhà vườn nhỏ mang tính chất là một nơi nghỉ ngơi của một gia đình trong những ngày cuối tuần hay những kỳ nghỉ trong năm .', '2012_11/139.jpg', '', 'thumb/139.jpg|block/139.jpg', 1, 2, 1, 0, 0, 0, 0, 'thanh bình,ước mơ,thành thị,thông thường,trên dưới,đầy đủ,phòng ăn,vệ sinh,giới thiệu,bạn đọc,tính chất,nghỉ ngơi,gia đình'), 
(5, 5, '5', 0, 1, '', 0, 1352698831, 1352698831, 1, 1352698831, 0, 2, 'Trung tâm game giải trí', 'Trung-tam-game-giai-tri', 'Chủ đầu tư: Mr Trung\r\nĐịa điểm: Thái Nguyên\r\nDiện tích: 250m2', '2012_11/136.jpg', '', 'thumb/136.jpg|block/136.jpg', 1, 2, 1, 0, 0, 0, 0, 'địa điểm,thái nguyên,diện tích'), 
(6, 6, '6', 0, 1, '', 0, 1352698890, 1352698890, 1, 1352698890, 0, 2, 'Công viên Mai Dịch', 'Cong-vien-Mai-Dich', 'Thiết kế: KTS.Ths Hoàng Minh Hiển\r\nĐịa điểm: Mai Dịch, Cầu Giấy (Hà Nội)', '2012_11/4_resize.jpg', '', 'thumb/4_resize.jpg|block/4_resize.jpg', 1, 2, 1, 0, 0, 0, 0, 'thiết kế,địa điểm,mai dịch,cầu giấy');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_sources`
--

DROP TABLE IF EXISTS `nv3_vi_news_sources`;
CREATE TABLE `nv3_vi_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_news_topics`
--

DROP TABLE IF EXISTS `nv3_vi_news_topics`;
CREATE TABLE `nv3_vi_news_topics` (
  `topicid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_referer_stats`
--

DROP TABLE IF EXISTS `nv3_vi_referer_stats`;
CREATE TABLE `nv3_vi_referer_stats` (
  `host` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_searchkeys`
--

DROP TABLE IF EXISTS `nv3_vi_searchkeys`;
CREATE TABLE `nv3_vi_searchkeys` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `keys` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50) NOT NULL,
  KEY `id` (`id`),
  KEY `keys` (`keys`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_tu_van_kien_truc_1`
--

DROP TABLE IF EXISTS `nv3_vi_tu_van_kien_truc_1`;
CREATE TABLE `nv3_vi_tu_van_kien_truc_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_tu_van_kien_truc_1`
--

INSERT INTO `nv3_vi_tu_van_kien_truc_1` VALUES
(1, 1, '1', 0, 1, '', 0, 1352708476, 1352708476, 1, 1352708476, 0, 2, 'Tư vấn xây nhà 3 tầng trên mảnh đất 120m2', 'Tu-van-xay-nha-3-tang-tren-manh-dat-120m2', 'Gia đình tôi có mảnh đất diện tích 8x15m2, dự kiến xây nhà 3 tầng với kích thước 8×10 m.\r\nYêu cầu:\r\nTầng 1: phòng khách, phòng ngủ, bếp ăn, vệ sinh\r\nTầng 2: 3 phòng ngủ, trong đó có 1phong ngủ có vệ sinh khép kín.\r\nTầng 3: phòng thờ, sân phơi', '2012_11/pc.jpg', '', 'thumb/pc.jpg|block/pc.jpg', 1, 2, 1, 0, 0, 0, 0, 'gia đình,diện tích,kích thước,yêu cầu,vệ sinh'), 
(4, 1, '1', 0, 1, '', 0, 1352708952, 1352708952, 1, 1352708952, 0, 2, 'hfgfhgfhfhg', 'hfgfhgfhfhg', 'hghghghghg', '2012_11/house3.jpg', '', 'thumb/house3_2.jpg|block/house3_2.jpg', 1, 2, 1, 0, 0, 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_tu_van_kien_truc_2`
--

DROP TABLE IF EXISTS `nv3_vi_tu_van_kien_truc_2`;
CREATE TABLE `nv3_vi_tu_van_kien_truc_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_tu_van_kien_truc_2`
--

INSERT INTO `nv3_vi_tu_van_kien_truc_2` VALUES
(2, 2, '2', 0, 1, '', 0, 1352708558, 1352708558, 1, 1352708558, 0, 2, 'Tư vấn hóa giải hướng nhà không tốt cho gia chủ', 'Tu-van-hoa-giai-huong-nha-khong-tot-cho-gia-chu', 'Tôi Sinh năm 1977 vợ tôi sinh năm 1986, Nhà quay về hướng nam, nghe nói là hướng đó không tốt cho tuổi của tôi (Bếp hướng Bắc, Bàn thờ hướng Tây). Vậy xin hỏi BBT, gia đình tôi phải làm thế nào để tránh hướng hung này', '2012_11/house3.jpg', '', 'thumb/house3.jpg|block/house3.jpg', 1, 2, 1, 0, 0, 0, 0, 'nghe nói,bàn thờ,gia đình,thế nào');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_tu_van_kien_truc_3`
--

DROP TABLE IF EXISTS `nv3_vi_tu_van_kien_truc_3`;
CREATE TABLE `nv3_vi_tu_van_kien_truc_3` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_tu_van_kien_truc_3`
--

INSERT INTO `nv3_vi_tu_van_kien_truc_3` VALUES
(3, 3, '3', 0, 1, '', 0, 1352708698, 1352708698, 1, 1352708698, 0, 2, 'Giấy tờ để tách thửa', 'Giay-to-de-tach-thua', 'Tôi mua ngôi nhà 4 tầng, giá 800 triệu đồng, đã giao 700 triệu đồng. Phần còn lại, thanh toán sau khi bên bán bàn giao giấy chứng nhận quyền sử dụng đất và hoàn thành nghĩa vụ thuế.', '2012_11/house3.jpg', '', 'thumb/house3_1.jpg|block/house3_1.jpg', 1, 2, 1, 0, 0, 0, 0, 'thanh toán,bàn giao,giấy chứng nhận,sử dụng,hoàn thành,nghĩa vụ');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_tu_van_kien_truc_admins`
--

DROP TABLE IF EXISTS `nv3_vi_tu_van_kien_truc_admins`;
CREATE TABLE `nv3_vi_tu_van_kien_truc_admins` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `comment` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_tu_van_kien_truc_block`
--

DROP TABLE IF EXISTS `nv3_vi_tu_van_kien_truc_block`;
CREATE TABLE `nv3_vi_tu_van_kien_truc_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_tu_van_kien_truc_block_cat`
--

DROP TABLE IF EXISTS `nv3_vi_tu_van_kien_truc_block_cat`;
CREATE TABLE `nv3_vi_tu_van_kien_truc_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `number` mediumint(4) NOT NULL DEFAULT '10',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_tu_van_kien_truc_bodyhtml_1`
--

DROP TABLE IF EXISTS `nv3_vi_tu_van_kien_truc_bodyhtml_1`;
CREATE TABLE `nv3_vi_tu_van_kien_truc_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_tu_van_kien_truc_bodyhtml_1`
--

INSERT INTO `nv3_vi_tu_van_kien_truc_bodyhtml_1` VALUES
(1, '<span class=\"categories\" style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51) !important; font-size: 12px; font-weight: bold !important; font-family: Arial; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\">Chuyên mục:<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/tu-van-kien-truc/tu-van-thiet-ke/\" rel=\"category tag\" style=\"color: rgb(148, 64, 64) !important; text-decoration: initial;\" title=\"View all posts in Tư vấn thiết kế\">Tư vấn thiết kế</a></span><div class=\"post-info\" style=\"color: rgb(51, 51, 51); font-size: 12px; margin: 0px 0px 5px; padding: 0px; font-family: Arial; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <b style=\"font-weight: bold;\">Ngày :<span class=\"Apple-converted-space\">&nbsp;</span></b><span class=\"date time published\" style=\"margin: 0px; padding: 0px;\" title=\"2011-03-21T13:59:50+0000\">21/03/2011</span></div><div class=\"entry-content\" style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> <strong>Gia đình tôi có mảnh đất diện tích 8x15m2, dự kiến xây nhà 3 tầng với kích thước 8×10 m.</strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> <em>Yêu cầu:</em></p> <ul style=\"margin: 0px; padding: 0px 0px 15px;\"> <li style=\"margin: 0px 0px 0px 20px; padding: 0px; list-style-type: square;\"> Tầng 1: phòng khách, phòng ngủ, bếp ăn, vệ sinh</li> <li style=\"margin: 0px 0px 0px 20px; padding: 0px; list-style-type: square;\"> Tầng 2: 3 phòng ngủ, trong đó có 1phong ngủ có vệ sinh khép kín.</li> <li style=\"margin: 0px 0px 0px 20px; padding: 0px; list-style-type: square;\"> Tầng 3: phòng thờ, sân phơi</li> </ul> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Mong các<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\" title=\"Kiến trúc\">Kiến trúc</a><span class=\"Apple-converted-space\">&nbsp;</span>sư tư vấn giúp, xin chân thành cảm ơn!</p> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> <strong>Trả lời:</strong></h2> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Với những yêu cầu của gia đình, Adkientruc xin đưa ra phương án thiết kế như sau:</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Mảnh đất có tổng diện tích 120m2 KTS chia làm hai khu vực, phía trước là sân vườn kết hợp garage (40m2), không gian còn lại dành cho mục đích sinh hoạt, sử dụng (80m2)</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <img align=\"middle\" alt=\"\" border=\"1\" class=\"aligncenter\" height=\"410\" src=\"http://adkientruc.com/wp-content/uploads/2011/03/pc.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"350\" /></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> <strong>Về kiến trúc:</strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Thiết kế ngôi nhà theo loại hình biệt thự nhỏ mang phong cách hiện đại, mái dốc đảm bảo về mặt công năng sử dụng cũng như đáp ứng tính thẩm mỹ của ngôi nhà. Trong đó, cách thể hiện ở mặt tiền khá đơn giản, hình khối tương xứng nhau tạo sự hài hòa, đẹp mắt.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Tầng 1: Theo như yêu cầu của gia chủ, tầng một bố trí gồm phòng ngủ, bếp ăn, phòng khách và vệ sinh chung. Cầu thang đặt phía cuối nhà nhằm tiết kiệm tối đa diện tích sử dụng, vệ sinh đặt dưới gầm.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Phòng khách rộng 16m2 phân chia với bếp ăn bằng vách ngăn tượng trưng (quầy bar hoặc kệ trang trí). Phòng ngủ dành bố trí hai giường nhỏ dành cho gia nhân hoặc khách.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <img align=\"middle\" alt=\"\" border=\"1\" class=\"aligncenter\" height=\"530\" src=\"http://adkientruc.com/wp-content/uploads/2011/03/15.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"432\" /></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Tầng 2: tầng 2 gồm 3 phòng ngủ có thiết kế ban công, cửa kính lấy sáng. Hai vệ sinh chung phục vụ sinh hoạt cá nhân của các thành viên trong gia đình.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <img align=\"middle\" alt=\"\" border=\"1\" class=\"aligncenter\" height=\"378\" src=\"http://adkientruc.com/wp-content/uploads/2011/03/22.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"432\" /></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Tầng 3: tầng 3 với ít chức năng sử dụng nên KTS tạo không gian thêm không gian thư giãn thay vì lãng phí diện tích sân thượng. Trong đó, diện tích phòng thờ là 17m2, phòng giặt nhỏ, chỉ dành một góc cho sân phơi, phần sân thượng còn lại được bố trí tiểu cảnh xanh, tạo vườn khô vừa để giảm bớt sức nóng của của mùa hè. Thiết kế mái dốc để tạo cái nhìn tổng thể đẹp mắt cho ngôi nhà.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <img align=\"middle\" alt=\"\" border=\"1\" class=\"aligncenter\" height=\"378\" src=\"http://adkientruc.com/wp-content/uploads/2011/03/32.jpg\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"432\" /></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> <strong>Về<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/san-pham/noi-that/\" style=\"color: rgb(51, 51, 51); text-decoration: initial;\" target=\"_blank\" title=\"nội thất\">nội thất</a>:</strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Các không gian đều được định hướng theo phong cách hiện đại, trẻ trung nên đồ nội thất trong nhà ưu tiên sử dụng chất liệu hiện đại, màu sắc nhẹ nhàng, sinh động và bắt mắt. Ngoài ra, việc bài trí nội thất tiện nghi còn tạo điều kiện thuận lợi cho việc sinh hoạt của gia đình.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: right;\"> <strong><em>Công ty CP ADkientruc</em></strong></p></div>', '', 1, 0, 1, 1, 1), 
(2, '<span class=\"categories\" style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51) !important; font-size: 12px; font-weight: bold !important; font-family: Arial; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\">Chuyên mục:<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/tu-van-kien-truc/tu-van-phong-thuy/\" rel=\"category tag\" style=\"color: rgb(148, 64, 64) !important; text-decoration: initial;\" title=\"View all posts in Tư vấn phong thủy\">Tư vấn phong thủy</a></span><div class=\"post-info\" style=\"color: rgb(51, 51, 51); font-size: 12px; margin: 0px 0px 5px; padding: 0px; font-family: Arial; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <b style=\"font-weight: bold;\">Ngày :<span class=\"Apple-converted-space\">&nbsp;</span></b><span class=\"date time published\" style=\"margin: 0px; padding: 0px;\" title=\"2012-01-30T14:59:28+0000\">30/01/2012</span></div><div class=\"entry-content\" style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> <strong>Tôi Sinh năm 1977 vợ tôi sinh năm 1986, Nhà quay về hướng nam, nghe nói là hướng đó không tốt cho tuổi của tôi (Bếp hướng Bắc, Bàn thờ hướng Tây). Vậy xin hỏi BBT, gia đình tôi phải làm thế nào để tránh hướng hung này</strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Xin chân thành cảm ơn!</p> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> Trả lời:</h2> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Chúng tôi xin trả lời câu hỏi của bạn như sau:</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Bạn sinh năm 1977, thuộc Tây tứ mệnh, nhà hướng Nam thuộc Đông tứ trạch.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Những hướng tốt là Tây Bắc (Diên Niên); Đông Bắc (Sinh Khí); Tây Nam (Phục Vị); Tây (Thiên Y);</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Hướng xấu: Bắc (Tuyệt Mệnh); Đông (Hoạ Hại); Đông Nam (Ngũ Quỷ); Nam (Lục Sát);</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <img alt=\"Archi - Hóa giải hướng nhà không tốt cho gia chủ\" height=\"375\" src=\"http://adkientruc.com/wp-content/uploads/2012/01/House3.jpg\" style=\"max-width: 100%;\" width=\"432\" /></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <em><span style=\"color: rgb(0, 0, 255);\">Ảnh chỉ mang tính minh họa</span></em></p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Cửa chính nhà bạn quay về hướng Nam tức Lục sát là rất xấu, có thể hóa giải bằng cách tạo thêm cửa phụ hướng Tây nam (Phục vị). Hoặc dùng màu sắc của thảm trải trước cửa để hóa giải tà khí theo quy luật ngũ hành tương sinh, tương khắc. Gia chủ mệnh Thổ nên trải thảm màu nâu, vàng.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Cũng có thể kê bếp hướng Tây bắc (Diên niên) yểm Lục sát của cửa chính.</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Bếp nấu của gia đình cũng không tốt so với tuổi của gia chủ (hướng Bắc – Tuyệt mệnh) có thể chỉnh bếp theo nguyên tắc (tạo hung hướng cát) đặt tại Đông và nhìn về Tây, tức là tọa tại Hoạ Hại nhìn về Thiên Y (bếp lành Thiên Y) hay đặt tại Đông Nam và nhìn về Tây Bắc, tức là tọa tại Ngũ Quỷ nhìn về Diên Niên (bếp lành Diên Niên).</p> <p style=\"margin: 0px; padding: 0px 0px 10px;\"> Hướng bàn thờ nên quay theo hướng hợp với tuổi của bạn.</p></div>', '', 1, 0, 1, 1, 1), 
(3, '<h1 class=\"entry-title\" style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 20px; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> Giấy tờ để tách thửa</h1><span style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); display: inline !important; float: none;\">﻿</span><span class=\"categories\" style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51) !important; font-size: 12px; font-weight: bold !important; font-family: Arial; font-style: normal; font-variant: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\">Chuyên mục:<span class=\"Apple-converted-space\">&nbsp;</span><a href=\"http://adkientruc.com/tu-van-kien-truc/thu-tuc-phap-ly/\" rel=\"category tag\" style=\"color: rgb(148, 64, 64) !important; text-decoration: initial;\" title=\"View all posts in Thủ tục pháp lý\">Thủ tục pháp lý</a></span><div class=\"post-info\" style=\"color: rgb(51, 51, 51); font-size: 12px; margin: 0px 0px 5px; padding: 0px; font-family: Arial; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <b style=\"font-weight: bold;\">Ngày :<span class=\"Apple-converted-space\">&nbsp;</span></b><span class=\"date time published\" style=\"margin: 0px; padding: 0px;\" title=\"2010-12-01T16:49:35+0000\">01/12/2010</span></div><div class=\"entry-content\" style=\"color: rgb(0, 0, 0); font-family: Arial; font-size: 12px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\"> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> <strong>Tôi mua ngôi nhà 4 tầng, giá 800 triệu đồng, đã giao 700 triệu đồng. Phần còn lại, thanh toán sau khi bên bán bàn giao giấy chứng nhận quyền sử dụng đất và hoàn thành nghĩa vụ thuế.<br  /> Năm 2006, tôi mua một ngôi nhà 42 m2 x 4 tầng, giá 800 triệu đồng, hợp đồng viết tay, đã giao bên bán 700 triệu đồng. Phần còn lại, theo thỏa thuận, sẽ thanh toán sau khi bên bán bàn giao giấy chứng nhận quyền sử dụng đất và hoàn thành nghĩa vụ thuế. (Nguyễn Xuân Phương)</strong></p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: center;\"> <img alt=\"\" class=\"aligncenter\" height=\"338\" src=\"http://adkientruc.com/wp-content/uploads/2010/12/tuvannhavuon.bmp\" style=\"display: block; margin: 0px auto 10px; max-width: 100%;\" width=\"451\" /></p> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> Yêu cầu:</h2> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Đây là một trong số 10 nhà phân lô của chủ đất. 10 nhà trên có chung giấy chứng nhận quyền sử dụng đất, đã được bán hết và cũng chưa được được cấp giấy chứng nhận quyền sử dụng đất riêng. Tôi muốn nhờ tư vấn để sớm tách được giấy tờ?</p> <h2 style=\"color: rgb(41, 157, 230); font-family: Arial, Tahoma, Verdana; font-weight: normal; text-decoration: initial; margin: 0px 0px 5px; padding: 0px; font-size: 18px;\"> Trả lời:</h2> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Trong trường hợp này, bạn cần liên hệ với chủ đất để ký kết hợp đồng chuyển nhượng có công chứng và yêu cầu chủ đất hoàn tất thủ tục tách thửa. Nếu thửa đất đó tại Hà Nội, sẽ áp dụng theo quy định tại quyết định số 26/2008/QĐ-UB ngày 28/5/2008 của UBND thành phố. Theo đó, thửa đất có chiều rộng mặt tiền và chiều sâu so với chỉ giới xây dựng (chiều dài của thửa đất tính từ cột mốc được phép xây dựng) từ 3 m trở lên, đồng thời thửa đất còn lại (phần diện tích đất còn lại của người chuyển nhượng cho bạn) sau khi tách thửa đảm bảo đủ các điều kiện sau đây:</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> - Có diện tích không nhỏ hơn 30 m2;</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> - Có chiều rộng mặt tiền và chiều sâu so với chỉ giới xây dựng (chiều dài của thửa đất tính từ cột mốc được phép xây dựng) từ 3 m trở lên.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Theo quy định tại Điều 19 nghị định 84 năm 2007, hồ sơ gồm có:</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> - Đơn xin tách thửa;</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> - Giấy chứng nhận quyền sử dụng đất chung;</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> - Hợp đồng mua bán (có công chứng);</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> - Trích lục thửa đất do đơn vị có chức năng đo đạc địa chính thực hiện;</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> - CMTND và hộ khẩu (bản sao có công chứng hoặc chứng thực) của bên mua và bán.</p> <p style=\"margin: 0px; padding: 0px 0px 10px; text-align: justify;\"> Những hồ sơ này cần được gửi đến Phòng tài nguyên môi trường để xin tách thửa.</p></div>', '', 1, 0, 1, 1, 1), 
(4, 'hghghghghgh', '', 1, 0, 1, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_tu_van_kien_truc_bodytext`
--

DROP TABLE IF EXISTS `nv3_vi_tu_van_kien_truc_bodytext`;
CREATE TABLE `nv3_vi_tu_van_kien_truc_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_tu_van_kien_truc_bodytext`
--

INSERT INTO `nv3_vi_tu_van_kien_truc_bodytext` VALUES
(1, 'Chuyên mục: http://adkientruc.com/tu-van-kien-truc/tu-van-thiet-ke/ Tư vấn thiết kế Ngày : 21/03/2011 Gia đình tôi có mảnh đất diện tích 8x15m2, dự kiến xây nhà 3 tầng với kích thước 8×10 m. Yêu cầu: Tầng 1: phòng khách, phòng ngủ, bếp ăn, vệ sinh Tầng 2: 3 phòng ngủ, trong đó có 1phong ngủ có vệ sinh khép kín. Tầng 3: phòng thờ, sân phơi Mong các http://adkientruc.com/ Kiến trúc sư tư vấn giúp, xin chân thành cảm ơn! Trả lời: Với những yêu cầu của gia đình, Adkientruc xin đưa ra phương án thiết kế như sau: Mảnh đất có tổng diện tích 120m2 KTS chia làm hai khu vực, phía trước là sân vườn kết hợp garage (40m2), không gian còn lại dành cho mục đích sinh hoạt, sử dụng (80m2) http://adkientruc.com/wp-content/uploads/2011/03/pc.jpg Về kiến trúc: Thiết kế ngôi nhà theo loại hình biệt thự nhỏ mang phong cách hiện đại, mái dốc đảm bảo về mặt công năng sử dụng cũng như đáp ứng tính thẩm mỹ của ngôi nhà. Trong đó, cách thể hiện ở mặt tiền khá đơn giản, hình khối tương xứng nhau tạo sự hài hòa, đẹp mắt. Tầng 1: Theo như yêu cầu của gia chủ, tầng một bố trí gồm phòng ngủ, bếp ăn, phòng khách và vệ sinh chung. Cầu thang đặt phía cuối nhà nhằm tiết kiệm tối đa diện tích sử dụng, vệ sinh đặt dưới gầm. Phòng khách rộng 16m2 phân chia với bếp ăn bằng vách ngăn tượng trưng (quầy bar hoặc kệ trang trí). Phòng ngủ dành bố trí hai giường nhỏ dành cho gia nhân hoặc khách. http://adkientruc.com/wp-content/uploads/2011/03/15.jpg Tầng 2: tầng 2 gồm 3 phòng ngủ có thiết kế ban công, cửa kính lấy sáng. Hai vệ sinh chung phục vụ sinh hoạt cá nhân của các thành viên trong gia đình. http://adkientruc.com/wp-content/uploads/2011/03/22.jpg Tầng 3: tầng 3 với ít chức năng sử dụng nên KTS tạo không gian thêm không gian thư giãn thay vì lãng phí diện tích sân thượng. Trong đó, diện tích phòng thờ là 17m2, phòng giặt nhỏ, chỉ dành một góc cho sân phơi, phần sân thượng còn lại được bố trí tiểu cảnh xanh, tạo vườn khô vừa để giảm bớt sức nóng của của mùa hè. Thiết kế mái dốc để tạo cái nhìn tổng thể đẹp mắt cho ngôi nhà. http://adkientruc.com/wp-content/uploads/2011/03/32.jpg Về http://adkientruc.com/san-pham/noi-that/ nội thất: Các không gian đều được định hướng theo phong cách hiện đại, trẻ trung nên đồ nội thất trong nhà ưu tiên sử dụng chất liệu hiện đại, màu sắc nhẹ nhàng, sinh động và bắt mắt. Ngoài ra, việc bài trí nội thất tiện nghi còn tạo điều kiện thuận lợi cho việc sinh hoạt của gia đình. Công ty CP ADkientruc'), 
(2, 'Chuyên mục: http://adkientruc.com/tu-van-kien-truc/tu-van-phong-thuy/ Tư vấn phong thủy Ngày : 30/01/2012 Tôi Sinh năm 1977 vợ tôi sinh năm 1986, Nhà quay về hướng nam, nghe nói là hướng đó không tốt cho tuổi của tôi (Bếp hướng Bắc, Bàn thờ hướng Tây). Vậy xin hỏi BBT, gia đình tôi phải làm thế nào để tránh hướng hung này Xin chân thành cảm ơn! Trả lời: Chúng tôi xin trả lời câu hỏi của bạn như sau: Bạn sinh năm 1977, thuộc Tây tứ mệnh, nhà hướng Nam thuộc Đông tứ trạch. Những hướng tốt là Tây Bắc (Diên Niên); Đông Bắc (Sinh Khí); Tây Nam (Phục Vị); Tây (Thiên Y); Hướng xấu: Bắc (Tuyệt Mệnh); Đông (Hoạ Hại); Đông Nam (Ngũ Quỷ); Nam (Lục Sát); http://adkientruc.com/wp-content/uploads/2012/01/House3.jpg Archi - Hóa giải hướng nhà không tốt cho gia chủ Ảnh chỉ mang tính minh họa Cửa chính nhà bạn quay về hướng Nam tức Lục sát là rất xấu, có thể hóa giải bằng cách tạo thêm cửa phụ hướng Tây nam (Phục vị). Hoặc dùng màu sắc của thảm trải trước cửa để hóa giải tà khí theo quy luật ngũ hành tương sinh, tương khắc. Gia chủ mệnh Thổ nên trải thảm màu nâu, vàng. Cũng có thể kê bếp hướng Tây bắc (Diên niên) yểm Lục sát của cửa chính. Bếp nấu của gia đình cũng không tốt so với tuổi của gia chủ (hướng Bắc – Tuyệt mệnh) có thể chỉnh bếp theo nguyên tắc (tạo hung hướng cát) đặt tại Đông và nhìn về Tây, tức là tọa tại Hoạ Hại nhìn về Thiên Y (bếp lành Thiên Y) hay đặt tại Đông Nam và nhìn về Tây Bắc, tức là tọa tại Ngũ Quỷ nhìn về Diên Niên (bếp lành Diên Niên). Hướng bàn thờ nên quay theo hướng hợp với tuổi của bạn.'), 
(3, ' Giấy tờ để tách thửa﻿Chuyên mục: http://adkientruc.com/tu-van-kien-truc/thu-tuc-phap-ly/ Thủ tục pháp lý Ngày : 01/12/2010 Tôi mua ngôi nhà 4 tầng, giá 800 triệu đồng, đã giao 700 triệu đồng. Phần còn lại, thanh toán sau khi bên bán bàn giao giấy chứng nhận quyền sử dụng đất và hoàn thành nghĩa vụ thuế. Năm 2006, tôi mua một ngôi nhà 42 m2 x 4 tầng, giá 800 triệu đồng, hợp đồng viết tay, đã giao bên bán 700 triệu đồng. Phần còn lại, theo thỏa thuận, sẽ thanh toán sau khi bên bán bàn giao giấy chứng nhận quyền sử dụng đất và hoàn thành nghĩa vụ thuế. (Nguyễn Xuân Phương) http://adkientruc.com/wp-content/uploads/2010/12/tuvannhavuon.bmp Yêu cầu: Đây là một trong số 10 nhà phân lô của chủ đất. 10 nhà trên có chung giấy chứng nhận quyền sử dụng đất, đã được bán hết và cũng chưa được được cấp giấy chứng nhận quyền sử dụng đất riêng. Tôi muốn nhờ tư vấn để sớm tách được giấy tờ? Trả lời: Trong trường hợp này, bạn cần liên hệ với chủ đất để ký kết hợp đồng chuyển nhượng có công chứng và yêu cầu chủ đất hoàn tất thủ tục tách thửa. Nếu thửa đất đó tại Hà Nội, sẽ áp dụng theo quy định tại quyết định số 26/2008/QĐ-UB ngày 28/5/2008 của UBND thành phố. Theo đó, thửa đất có chiều rộng mặt tiền và chiều sâu so với chỉ giới xây dựng (chiều dài của thửa đất tính từ cột mốc được phép xây dựng) từ 3 m trở lên, đồng thời thửa đất còn lại (phần diện tích đất còn lại của người chuyển nhượng cho bạn) sau khi tách thửa đảm bảo đủ các điều kiện sau đây: - Có diện tích không nhỏ hơn 30 m2; - Có chiều rộng mặt tiền và chiều sâu so với chỉ giới xây dựng (chiều dài của thửa đất tính từ cột mốc được phép xây dựng) từ 3 m trở lên. Theo quy định tại Điều 19 nghị định 84 năm 2007, hồ sơ gồm có: - Đơn xin tách thửa; - Giấy chứng nhận quyền sử dụng đất chung; - Hợp đồng mua bán (có công chứng); - Trích lục thửa đất do đơn vị có chức năng đo đạc địa chính thực hiện; - CMTND và hộ khẩu (bản sao có công chứng hoặc chứng thực) của bên mua và bán. Những hồ sơ này cần được gửi đến Phòng tài nguyên môi trường để xin tách thửa.'), 
(4, 'hghghghghgh');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_tu_van_kien_truc_cat`
--

DROP TABLE IF EXISTS `nv3_vi_tu_van_kien_truc_cat`;
CREATE TABLE `nv3_vi_tu_van_kien_truc_cat` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `titlesite` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '',
  `thumbnail` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_tu_van_kien_truc_cat`
--

INSERT INTO `nv3_vi_tu_van_kien_truc_cat` VALUES
(1, 0, 'Tư vấn thiết kế', '', 'Tu-van-thiet-ke', '', '', '', 1, 1, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1352626029, 1352626029, 0, ''), 
(2, 0, 'Tư vấn phong thuỷ', '', 'Tu-van-phong-thuy', '', '', '', 2, 2, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1352626043, 1352626043, 0, ''), 
(3, 0, 'Thủ tục pháp lý', '', 'Thu-tuc-phap-ly', '', '', '', 3, 3, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1352626064, 1352626064, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_tu_van_kien_truc_comments`
--

DROP TABLE IF EXISTS `nv3_vi_tu_van_kien_truc_comments`;
CREATE TABLE `nv3_vi_tu_van_kien_truc_comments` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `post_time` (`post_time`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_tu_van_kien_truc_config_post`
--

DROP TABLE IF EXISTS `nv3_vi_tu_van_kien_truc_config_post`;
CREATE TABLE `nv3_vi_tu_van_kien_truc_config_post` (
  `pid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `member` tinyint(4) NOT NULL,
  `group_id` mediumint(9) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `member` (`member`,`group_id`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_tu_van_kien_truc_config_post`
--

INSERT INTO `nv3_vi_tu_van_kien_truc_config_post` VALUES
(1, 0, 0, 0, 0, 0, 0), 
(2, 1, 0, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_tu_van_kien_truc_rows`
--

DROP TABLE IF EXISTS `nv3_vi_tu_van_kien_truc_rows`;
CREATE TABLE `nv3_vi_tu_van_kien_truc_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_tu_van_kien_truc_rows`
--

INSERT INTO `nv3_vi_tu_van_kien_truc_rows` VALUES
(1, 1, '1', 0, 1, '', 0, 1352708476, 1352708476, 1, 1352708476, 0, 2, 'Tư vấn xây nhà 3 tầng trên mảnh đất 120m2', 'Tu-van-xay-nha-3-tang-tren-manh-dat-120m2', 'Gia đình tôi có mảnh đất diện tích 8x15m2, dự kiến xây nhà 3 tầng với kích thước 8×10 m.\r\nYêu cầu:\r\nTầng 1: phòng khách, phòng ngủ, bếp ăn, vệ sinh\r\nTầng 2: 3 phòng ngủ, trong đó có 1phong ngủ có vệ sinh khép kín.\r\nTầng 3: phòng thờ, sân phơi', '2012_11/pc.jpg', '', 'thumb/pc.jpg|block/pc.jpg', 1, 2, 1, 0, 0, 0, 0, 'gia đình,diện tích,kích thước,yêu cầu,vệ sinh'), 
(2, 2, '2', 0, 1, '', 0, 1352708558, 1352708558, 1, 1352708558, 0, 2, 'Tư vấn hóa giải hướng nhà không tốt cho gia chủ', 'Tu-van-hoa-giai-huong-nha-khong-tot-cho-gia-chu', 'Tôi Sinh năm 1977 vợ tôi sinh năm 1986, Nhà quay về hướng nam, nghe nói là hướng đó không tốt cho tuổi của tôi (Bếp hướng Bắc, Bàn thờ hướng Tây). Vậy xin hỏi BBT, gia đình tôi phải làm thế nào để tránh hướng hung này', '2012_11/house3.jpg', '', 'thumb/house3.jpg|block/house3.jpg', 1, 2, 1, 0, 0, 0, 0, 'nghe nói,bàn thờ,gia đình,thế nào'), 
(3, 3, '3', 0, 1, '', 0, 1352708698, 1352708698, 1, 1352708698, 0, 2, 'Giấy tờ để tách thửa', 'Giay-to-de-tach-thua', 'Tôi mua ngôi nhà 4 tầng, giá 800 triệu đồng, đã giao 700 triệu đồng. Phần còn lại, thanh toán sau khi bên bán bàn giao giấy chứng nhận quyền sử dụng đất và hoàn thành nghĩa vụ thuế.', '2012_11/house3.jpg', '', 'thumb/house3_1.jpg|block/house3_1.jpg', 1, 2, 1, 0, 0, 0, 0, 'thanh toán,bàn giao,giấy chứng nhận,sử dụng,hoàn thành,nghĩa vụ'), 
(4, 1, '1', 0, 1, '', 0, 1352708952, 1352708952, 1, 1352708952, 0, 2, 'hfgfhgfhfhg', 'hfgfhgfhfhg', 'hghghghghg', '2012_11/house3.jpg', '', 'thumb/house3_2.jpg|block/house3_2.jpg', 1, 2, 1, 0, 0, 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_tu_van_kien_truc_sources`
--

DROP TABLE IF EXISTS `nv3_vi_tu_van_kien_truc_sources`;
CREATE TABLE `nv3_vi_tu_van_kien_truc_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_tu_van_kien_truc_topics`
--

DROP TABLE IF EXISTS `nv3_vi_tu_van_kien_truc_topics`;
CREATE TABLE `nv3_vi_tu_van_kien_truc_topics` (
  `topicid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_voting`
--

DROP TABLE IF EXISTS `nv3_vi_voting`;
CREATE TABLE `nv3_vi_voting` (
  `vid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL DEFAULT '',
  `acceptcm` int(2) NOT NULL DEFAULT '1',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL,
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_voting`
--

INSERT INTO `nv3_vi_voting` VALUES
(2, 'Bạn biết gì về NukeViet 3?', '', 1, 1, 0, '0', 1275318563, 0, 1), 
(3, 'Bạn quan tâm gì nhất ở mã nguồn mở?', '', 1, 1, 0, '0', 1275318589, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv3_vi_voting_rows`
--

DROP TABLE IF EXISTS `nv3_vi_voting_rows`;
CREATE TABLE `nv3_vi_voting_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `hitstotal` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_voting_rows`
--

INSERT INTO `nv3_vi_voting_rows` VALUES
(5, 2, 'Một bộ sourcecode cho web hoàn toàn mới.', '', 0), 
(6, 2, 'Mã nguồn mở, sử dụng miễn phí.', '', 0), 
(7, 2, 'Sử dụng xHTML, CSS và hỗ trợ Ajax', '', 0), 
(8, 2, 'Tất cả các ý kiến trên', '', 0), 
(9, 3, 'Liên tục được cải tiến, sửa đổi bởi cả thế giới.', '', 1), 
(10, 3, 'Được sử dụng miễn phí không mất tiền.', '', 0), 
(11, 3, 'Được tự do khám phá, sửa đổi theo ý thích.', '', 0), 
(12, 3, 'Phù hợp để học tập, nghiên cứu vì được tự do sửa đổi theo ý thích.', '', 0), 
(13, 3, 'Tất cả các ý kiến trên', '', 0);